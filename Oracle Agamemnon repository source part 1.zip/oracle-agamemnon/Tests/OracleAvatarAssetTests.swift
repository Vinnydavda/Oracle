import AppKit
import CryptoKit
import Foundation

@main
struct OracleAvatarAssetTests {
    static func main() throws {
        func expect(_ condition: @autoclosure () -> Bool, _ message: String) {
            if !condition() {
                fputs("FAIL: \(message)\n", stderr)
                exit(1)
            }
        }

        let root = URL(fileURLWithPath: FileManager.default.currentDirectoryPath).appendingPathComponent("Resources", isDirectory: true)
        let expected: [(String, String)] = [
            ("OracleCanonicalFront.jpg", "cd42f5f9fd8b80b24084c3cf1f068a0123cdb610c87fc319bb8278db80cd421f"),
            ("OracleCanonicalThreeQuarter.jpg", "09bfa6a6bdde1ae8c9e11cdd0ee4cccb57f3592fa717127fe536ee0d1321f5b9"),
            ("OracleCanonicalSide.jpg", "783c62ec6ef7cc70345fd1850a87118cab14bd15381661ce0c1f8b91c7b1e976"),
            ("OracleCanonicalBack.jpg", "b7b8c82a9d16f2bbb4310d7af1ae5a155541024b9caaf631a8a858b2336a433f"),
            ("OracleCanonicalTurnaround.jpg", "d7bb6ea8eb799e9ced66119622274c64ceb94d63ee972b91f411106ca6eb86af")
        ]
        for (name, expectedHash) in expected {
            let url = root.appendingPathComponent(name)
            expect(FileManager.default.fileExists(atPath: url.path), "\(name) is bundled in source resources")
            let data = try Data(contentsOf: url)
            let digest = SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
            expect(digest == expectedHash, "\(name) matches the owner-supplied original byte-for-byte")
            let image = NSImage(data: data)
            expect(image != nil && (image?.size.width ?? 0) > 0 && (image?.size.height ?? 0) > 0, "\(name) decodes as an image")
        }
        expect(OracleHumanoidPose.allCases.count == 5, "canonical Oracle exposes five interaction states")
        print("PASS Oracle canonical avatar assets: 16 assertions")
    }
}
