import Foundation

@main
struct OracleConversationPerformanceTests {
    static func main() {
        func expect(_ actual: OracleConversationPhase, _ expected: OracleConversationPhase) {
            precondition(actual == expected, "Expected \(expected.rawValue), got \(actual.rawValue)")
        }
        expect(OracleConversationPerformance.phase(.init()), .idle)
        expect(OracleConversationPerformance.phase(.init(microphoneStarting: true)), .awaitingPermission)
        expect(OracleConversationPerformance.phase(.init(microphoneCapturing: true, voicePlaying: true)), .listening)
        expect(OracleConversationPerformance.phase(.init(modelStreaming: true)), .processing)
        expect(OracleConversationPerformance.phase(.init(voicePreparing: true)), .processing)
        expect(OracleConversationPerformance.phase(.init(voicePlaying: true)), .speaking)
        expect(OracleConversationPerformance.phase(.init(interrupted: true)), .interrupted)
        expect(OracleConversationPerformance.phase(.init(failed: true)), .error)
        precondition(OracleConversationPerformance.visualMode(.interrupted) == .idle)
        precondition(OracleConversationPerformance.visualMode(.error) == .idle)
        print("PASS Oracle conversation performance: 10 assertions")
    }
}
