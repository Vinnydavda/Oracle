import Foundation

@main
struct OracleVoicePolicyTests {
    static func main() throws {
        func expect(_ condition: @autoclosure () -> Bool, _ message: String) {
            if !condition() {
                fputs("FAIL: \(message)\n", stderr)
                exit(1)
            }
        }

        let longText = String(repeating: "voice ", count: 1_800)
        let ttsData = try FishAudioRequestBuilder.ttsBody(text: longText, originalVoiceID: "original-voice-id")
        let tts = try JSONSerialization.jsonObject(with: ttsData) as? [String: Any]
        expect(tts?["reference_id"] as? String == "original-voice-id", "Fish TTS uses the configured original voice ID")
        expect((tts?["text"] as? String)?.utf8.count ?? Int.max <= FishAudioRequestBuilder.maximumSpeechBytes, "Fish speech text is bounded")
        expect(tts?["format"] as? String == "mp3", "Fish TTS requests playable MP3 audio")
        expect(tts?["references"] == nil, "Fish TTS does not accept performer recordings as inline clone references")
        expect(FishAudioRequestBuilder.ttsModel == "s2.1-pro-free", "Fish TTS uses the documented free model explicitly")
        expect(FishAudioRequestBuilder.estimatedVoiceDesignUSD == 0.01, "paid Voice Design cost is disclosed in code")

        let designData = try FishAudioRequestBuilder.voiceDesignBody(
            instruction: "Original warm, confident adult voice. No performer reference.",
            referenceText: "I am Oracle."
        )
        let design = try JSONSerialization.jsonObject(with: designData) as? [String: Any]
        expect(design?["instruction"] as? String != nil, "Voice Design sends an original-voice description")
        expect(design?["reference_text"] as? String == "I am Oracle.", "Voice Design includes a short audition script")
        expect(design?["reference_id"] == nil, "Voice Design does not identify or clone an existing performer voice")

        let candidateJSON = """
        {"candidates":[{"id":"candidate","index":0,"audio_base64":"UklGRg==","sample_rate":44100,"duration_ms":1200}]}
        """
        let candidates = try FishAudioRequestBuilder.decodeVoiceCandidates(Data(candidateJSON.utf8))
        expect(candidates.count == 1, "Voice Design decodes a returned candidate")
        expect(candidates.first?.duration_ms == 1_200, "Voice Design candidate metadata is preserved")

        let poses = OracleHumanoidPose.allCases
        expect(poses.count == 5, "humanoid exposes idle, greeting, listening, thinking and speaking poses")
        expect(Set(poses.map(\.accessibilityDescription)).count == 5, "each humanoid pose has a distinct accessible description")
        expect(OracleSpeechMotion.openness(text: "Hello", range: NSRange(location: 0, length: 5)) > 0.2, "local voice opens the cue for a spoken word")
        expect(OracleSpeechMotion.openness(text: "Hello!", range: NSRange(location: 5, length: 1)) < 0.1, "punctuation does not make a full mouth cue")
        expect(OracleSpeechMotion.openness(text: "Hello", range: NSRange(location: 9, length: 2)) == 0, "invalid range fails closed")

        do {
            _ = try FishAudioRequestBuilder.ttsBody(text: "Hello", originalVoiceID: " ")
            expect(false, "Fish TTS fails closed without an original voice ID")
        } catch {
            expect(true, "Fish TTS fails closed without an original voice ID")
        }

        do {
            _ = try FishAudioRequestBuilder.voiceDesignBody(instruction: "   ", referenceText: "Hello")
            expect(false, "Voice Design fails closed without an original-voice description")
        } catch {
            expect(true, "Voice Design fails closed without an original-voice description")
        }

        print("PASS Oracle voice and humanoid policy: 16 assertions")
    }
}
