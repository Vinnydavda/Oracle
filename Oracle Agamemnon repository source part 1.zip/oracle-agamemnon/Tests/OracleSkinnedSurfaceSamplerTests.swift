import Foundation
import SceneKit

@main
struct OracleSkinnedSurfaceSamplerTests {
    static func main() throws {
        guard CommandLine.arguments.count == 2 else { fatalError("Pass exact Oracle USDZ path") }
        let scene = try SCNScene(url: URL(fileURLWithPath: CommandLine.arguments[1]), options: nil)
        guard let mesh = scene.rootNode.childNode(withName: "Mesh_0", recursively: true) else { fatalError("Mesh_0 missing") }
        let sampler = try OracleSkinnedSurfaceSampler(mesh: mesh)
        precondition(sampler.vertexCount == 35_457 && sampler.boneCount == 24)
        let anchors = try sampler.anchors(count: 128)
        precondition(anchors.count == 128 && Set(anchors.map(\.vertexIndex)).count == 128)
        let rest = sampler.worldPositions(for: anchors)
        func distance(_ a: SCNVector3, _ b: SCNVector3) -> Double {
            let x = Double(a.x - b.x), y = Double(a.y - b.y), z = Double(a.z - b.z)
            return sqrt(x*x + y*y + z*z)
        }
        let worst = zip(anchors, rest).map { distance(sampler.restWorldPosition(of: $0.0), $0.1) }.max()!
        precondition(worst < 0.00001, "rest anchors must sit on the actual mesh: \(worst)")
        guard let arm = scene.rootNode.childNode(withName: "LeftArm", recursively: true) else { fatalError("LeftArm missing") }
        arm.eulerAngles.z += 0.55
        let posed = sampler.worldPositions(for: anchors)
        let movement = zip(rest, posed).map(distance).max()!
        precondition(movement > 0.01, "some sampled arm points must follow pose")
        precondition(posed.allSatisfy { $0.x.isFinite && $0.y.isFinite && $0.z.isFinite })
        print("PASS Oracle skinned surface sampler: 5 assertions on exact USDZ; rest max error \(worst) m, posed max movement \(movement) m")
    }
}
