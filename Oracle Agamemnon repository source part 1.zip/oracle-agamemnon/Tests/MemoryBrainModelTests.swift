import Foundation

private func require(_ condition: @autoclosure () -> Bool, _ message: String) {
    guard condition() else {
        fputs("FAIL: \(message)\n", stderr)
        exit(1)
    }
}

@main
struct MemoryBrainModelTests {
    static func main() {
        let now = ISO8601DateFormatter().date(from: "2026-11-07T21:40:00Z")!
        let sources = [
            ObsidianMemorySource(relativePath: "Alpha.md", title: "Alpha", text: "# Alpha\nLinks to [[Beta]] and [[Missing]].", modifiedAt: now),
            ObsidianMemorySource(relativePath: "Projects/Beta.md", title: "Beta", text: "# Beta\nLinks back to [[Alpha]] and forward to [[Gamma]].", modifiedAt: now),
            ObsidianMemorySource(relativePath: "Projects/Gamma.md", title: "Gamma", text: "# Gamma\nNo resolved links.", modifiedAt: now)
        ]

        let graph = MemoryBrainBuilder.build(sources: sources, generatedAt: now, maxNotes: 20, maxEdges: 100)
        require(graph.nodes.count == 4, "memory graph includes one hub and three notes")
        require(graph.nodes.filter { $0.kind == .memoryHub }.count == 1, "memory graph has one central brain hub")
        require(graph.nodes.filter { $0.kind == .note }.count == 3, "memory graph exposes Obsidian notes as nodes")
        require(graph.edges.count == 5, "graph has three hub links and two resolved note links")
        require(!graph.edges.contains(where: { $0.to.contains("missing") || $0.from.contains("missing") }), "unresolved wikilinks are ignored")
        require(Set(graph.edges.map(\.id)).count == graph.edges.count, "edge identifiers are unique")

        let beta = graph.nodes.first { $0.relativePath == "Projects/Beta.md" }
        require(beta?.folder == "Projects", "folder context is retained")
        require(beta?.linkCount == 2, "resolved link count is reported per note")

        let graphAgain = MemoryBrainBuilder.build(sources: sources, generatedAt: now, maxNotes: 20, maxEdges: 100)
        require(graph.nodes.map(\.id) == graphAgain.nodes.map(\.id), "node order is deterministic")
        require(graph.nodes.map(\.position) == graphAgain.nodes.map(\.position), "orbital positions are deterministic")

        let limited = MemoryBrainBuilder.build(sources: sources, generatedAt: now, maxNotes: 2, maxEdges: 100)
        require(limited.nodes.filter { $0.kind == .note }.count == 2, "source-note limit is enforced")
        require(limited.edges.count <= 100, "edge limit is enforced")

        let ambiguousSources = [
            ObsidianMemorySource(relativePath: "Index.md", title: "Index", text: "# Root index", modifiedAt: now),
            ObsidianMemorySource(relativePath: "Archive/Index.md", title: "Index", text: "# Archive index", modifiedAt: now),
            ObsidianMemorySource(relativePath: "Linker.md", title: "Linker", text: "See [[Index]].", modifiedAt: now)
        ]
        let ambiguous = MemoryBrainBuilder.build(sources: ambiguousSources, generatedAt: now, maxNotes: 20, maxEdges: 100)
        require(ambiguous.nodes.filter { $0.kind == .note }.count == 3, "duplicate-title notes remain distinct nodes")
        require(!ambiguous.edges.contains(where: { $0.kind == .noteLink }), "ambiguous title links do not create an arbitrary edge")
        require(ambiguous.edges.count == 3, "ambiguous links leave only hub connections")

        print("PASS memory brain model: 14 assertions")
    }
}
