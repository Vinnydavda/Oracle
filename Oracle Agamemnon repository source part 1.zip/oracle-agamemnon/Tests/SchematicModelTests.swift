import Foundation

private func require(_ condition: @autoclosure () -> Bool, _ message: String) {
    guard condition() else {
        fputs("FAIL: \(message)\n", stderr)
        exit(1)
    }
}

private let observedAt = ISO8601DateFormatter().date(from: "2026-11-07T20:00:00Z")!

@main
struct SchematicModelTests {
    static func main() {
        let healthy = SchematicBuildInput(
            deviceName: "Test Mac",
            osVersion: "macOS 27.2 arm64",
            securityState: "DISARMED",
            securityObservedAt: observedAt,
            cameraName: "FaceTime HD Camera",
            cameraPermission: "AUTHORIZED",
            vpnStates: ["Work VPN:Connected"],
            ollamaAvailable: true,
            installedModels: ["qwen3:4b-instruct", "other:latest"],
            selectedModel: "qwen3:4b-instruct",
            evidenceCount: 2,
            observedAt: observedAt,
            obsidianVaultName: "Research Vault",
            obsidianNoteCount: 2,
            obsidianObservedAt: observedAt,
            memoryBrainNodeCount: 2,
            mttBridgeObserved: true,
            mttBridgeFresh: true
        )

        let graph = SchematicGraphBuilder.build(healthy)

        require(graph.nodes.map(\.id) == [
            "this-mac", "camera-collector", "security-store", "network-context",
            "evidence-store", "obsidian-vault", "memory-brain", "ollama-service", "oracle-workspace",
            "protection-engine", "security-events", "mtt-bridge", "approval-boundary"
        ], "graph exposes the bounded architecture in stable order")

        guard let model = graph.nodes.first(where: { $0.id == "ollama-service" }) else {
            fatalError("missing local model node")
        }
        require(model.state == .observed, "available local runtime is observed")
        require(model.evidence.contains("qwen3:4b-instruct"), "selected installed model is surfaced")
        require(!model.evidence.contains("other:latest"), "unselected installed models are not presented as active")
        require(graph.nodes.first(where: { $0.id == "obsidian-vault" })?.state == .observed,
                "configured Obsidian vault is surfaced as observed")
        require(graph.connections.first(where: { $0.id == "obsidian-to-oracle" })?.state == .configured,
                "Obsidian notes have an explicit user-controlled Oracle context path")
        require(graph.nodes.first(where: { $0.id == "memory-brain" })?.state == .observed,
                "Obsidian-backed memory brain is shown as an observed source")
        require(graph.connections.first(where: { $0.id == "memory-brain-to-oracle" })?.state == .configured,
                "Memory brain has a bounded user-controlled Oracle context path")

        require(graph.nodes.filter { $0.lane == .sources }.count == 6,
                "source lane contains the six observed source nodes")
        require(graph.nodes.filter { $0.lane == .analysis }.count == 6,
                "analysis lane contains the six processing and workspace nodes")
        require(graph.nodes.filter { $0.lane == .approval }.count == 1,
                "approval lane contains the explicit owner gate")
        let oracleFocus = SchematicGraphFocus.relatedConnectionIDs(for: "oracle-workspace", in: graph)
        require(oracleFocus.contains("oracle-to-ollama") && oracleFocus.contains("oracle-to-approval"),
                "selected node resolves its related paths without granting execution authority")
        require(graph.nodes.first(where: { $0.id == "mtt-bridge" })?.state == .observed,
                "fresh MTT sample is observed")
        require(graph.connections.first(where: { $0.id == "mtt-to-events" })?.state == .configured &&
                graph.connections.first(where: { $0.id == "mtt-to-events" })?.evidence.contains("fresh MTT sample") == true,
                "fresh MTT path and evidence agree")

        guard let grounded = graph.connections.first(where: { $0.id == "evidence-to-oracle" }) else {
            fatalError("missing evidence-to-oracle boundary")
        }
        require(grounded.state == .notConnected, "candidate does not claim evidence is already wired into chat")

        guard let approval = graph.nodes.first(where: { $0.id == "approval-boundary" }) else {
            fatalError("missing approval boundary")
        }
        require(approval.state == .observed, "owner-confirmed quarantine boundary is reported without granting model execution")

        let degraded = SchematicBuildInput(
            deviceName: "Test Mac",
            osVersion: "macOS 27.2 arm64",
            securityState: "PERMISSION_REQUIRED",
            securityObservedAt: observedAt.addingTimeInterval(-600),
            cameraName: "Unknown",
            cameraPermission: "DENIED",
            vpnStates: [],
            ollamaAvailable: false,
            installedModels: [],
            selectedModel: "qwen3:4b-instruct",
            evidenceCount: 0,
            observedAt: observedAt
        )
        let degradedGraph = SchematicGraphBuilder.build(degraded)
        require(degradedGraph.nodes.first(where: { $0.id == "camera-collector" })?.state == .denied,
                "denied camera permission is not shown as healthy")
        require(degradedGraph.nodes.first(where: { $0.id == "ollama-service" })?.state == .unavailable,
                "unavailable local runtime is not shown as healthy")
        require(degradedGraph.nodes.first(where: { $0.id == "network-context" })?.state == .unknown,
                "no observed VPN is not converted into a healthy network claim")
        require(degradedGraph.nodes.first(where: { $0.id == "security-store" })?.state == .stale,
                "old security state is shown as stale rather than live")

        let staleMTT = SchematicBuildInput(
            deviceName: "Test Mac",
            osVersion: "macOS 27.2 arm64",
            securityState: "DISARMED",
            securityObservedAt: observedAt,
            cameraName: "Unknown",
            cameraPermission: "NOT_REQUESTED",
            vpnStates: ["Work VPN:Disconnected"],
            ollamaAvailable: true,
            installedModels: ["qwen3:4b-instruct"],
            selectedModel: "qwen3:4b-instruct",
            evidenceCount: 0,
            observedAt: observedAt,
            mttBridgeObserved: true,
            mttBridgeFresh: false
        )
        let staleMTTGraph = SchematicGraphBuilder.build(staleMTT)
        require(staleMTTGraph.nodes.first(where: { $0.id == "mtt-bridge" })?.state == .stale,
                "historical MTT sample is not presented as fresh")
        require(staleMTTGraph.connections.first(where: { $0.id == "mtt-to-events" })?.state == .unavailable,
                "stale MTT bridge path is unavailable until refreshed")

        print("PASS schematic model: 22 assertions")
    }
}
