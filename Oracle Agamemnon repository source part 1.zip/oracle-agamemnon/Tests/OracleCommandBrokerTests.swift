import Foundation

@main
struct OracleCommandBrokerTests {
    static func main() throws {
        func expect(_ condition: @autoclosure () -> Bool, _ message: String) {
            if !condition() { fputs("FAIL: \(message)\n", stderr); exit(1) }
        }
        func refused(_ message: [String: Any], navigation: Bool, behavior: Bool = false) -> Bool {
            do { _ = try OracleCommandBroker.request(from: message, allowNavigation: navigation, allowBehavior: behavior); return false }
            catch { return true }
        }
        func call(_ name: String, _ arguments: [String: Any]) -> [String: Any] {
            ["function": ["name": name, "arguments": arguments]]
        }

        let readOnly = OracleCommandBroker.schemas(allowNavigation: false)
        let withBehavior = OracleCommandBroker.schemas(allowNavigation: false, allowBehavior: true)
        let navigation = OracleCommandBroker.schemas(allowNavigation: true, allowBehavior: true)
        expect(OracleCommandBroker.navigationAllowed(modelToolsEnabled: true, readOnlyToolsOnly: false, hasAttachedContext: false),
               "navigation needs explicit session enablement and no attached context")
        expect(!OracleCommandBroker.navigationAllowed(modelToolsEnabled: true, readOnlyToolsOnly: false, hasAttachedContext: true),
               "untrusted attached context disables navigation")
        expect(!OracleCommandBroker.navigationAllowed(modelToolsEnabled: false, readOnlyToolsOnly: false, hasAttachedContext: false),
               "tool shutdown disables navigation")
        expect(readOnly.count == 1 && withBehavior.count == 2 && navigation.count == 3,
               "speech cue is exposed only for voice-enabled turns; navigation still needs explicit enablement")
        expect((readOnly[0]["function"] as? [String: Any])?["name"] as? String == "get_oracle_status",
               "only the typed status function is available by default")
        let statusMessage: [String: Any] = ["role": "assistant", "content": "", "tool_calls": [call("get_oracle_status", [:])]]
        let parsedStatus = try OracleCommandBroker.request(from: statusMessage, allowNavigation: false)
        expect(parsedStatus == .status,
               "valid status request resolves to the exact local operation")
        let behaviorArgs: [String: Any] = ["gesture": "openPalm", "expression": "calm", "gaze": "center", "intensity": 0.4, "emphasis_text": "next step"]
        let behaviorMessage: [String: Any] = ["role": "assistant", "content": "", "tool_calls": [call("propose_oracle_behavior", behaviorArgs)]]
        expect(refused(behaviorMessage, navigation: false), "silent turns reject behavior calls")
        if case .behavior(let behavior)? = try OracleCommandBroker.request(from: behaviorMessage, allowNavigation: false, allowBehavior: true) {
            expect(behavior.supportedGestureCue == .openPalm, "bounded model behavior tool resolves to supported cue")
        } else { expect(false, "bounded behavior tool") }
        var unsafeBehavior = behaviorArgs; unsafeBehavior["gesture"] = "nod"
        expect(refused(["tool_calls": [call("propose_oracle_behavior", unsafeBehavior)]], navigation: false, behavior: true),
               "unsupported nod is refused without a rig")
        let pageMessage: [String: Any] = ["role": "assistant", "content": "", "tool_calls": [call("open_oracle_section", ["section": "Memory Brain"])]]
        expect(refused(pageMessage, navigation: false), "navigation request is refused without session enablement")
        let parsedPage = try OracleCommandBroker.request(from: pageMessage, allowNavigation: true)
        expect(parsedPage == .openSection("Memory Brain"),
               "allowlisted navigation resolves when enabled")
        expect(refused(["tool_calls": [call("run_shell", ["command": "pwd"])]] , navigation: true),
               "arbitrary command name is refused")
        expect(refused(["tool_calls": [call("get_oracle_status", ["path": "/tmp"])]] , navigation: true),
               "status arguments cannot smuggle a path")
        expect(refused(["tool_calls": [call("open_oracle_section", ["section": "Terminal"])]] , navigation: true),
               "page outside the allowlist is refused")
        expect(refused(["tool_calls": [call("get_oracle_status", [:]), call("get_oracle_status", [:])]], navigation: true),
               "multiple calls are refused")

        let initial = try OracleChatRequestBuilder.prepare(model: "qwen3:4b-instruct", userText: "Status?", note: nil,
            tools: readOnly)
        let followup = try OracleCommandBroker.followupBody(originalRequest: initial.body, assistantMessage: statusMessage,
            request: .status, result: "{\"provider\":\"available\"}")
        let payload = try JSONSerialization.jsonObject(with: followup) as? [String: Any]
        let messages = payload?["messages"] as? [[String: Any]] ?? []
        expect(payload?["tools"] == nil && payload?["stream"] as? Bool == false,
               "follow-up cannot request another tool step")
        expect(messages.suffix(2).map { $0["role"] as? String ?? "" } == ["assistant", "tool"],
               "follow-up preserves the assistant call and exact tool result roles")
        expect(messages.last?["tool_name"] as? String == "get_oracle_status", "tool result names the executed function")
        expect(followup.count <= OracleChatRequestBuilder.maximumBodyBytes, "follow-up fits the hard request budget")
        do {
            _ = try OracleCommandBroker.followupBody(originalRequest: initial.body, assistantMessage: statusMessage,
                request: .status, result: String(repeating: "x", count: OracleCommandBroker.maximumToolResultBytes + 1))
            expect(false, "oversized result is refused")
        } catch { expect(true, "oversized result is refused") }

        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        let url = directory.appendingPathComponent("command-audit.jsonl")
        let receipt = OracleCommandAuditReceipt(id: UUID(), observedAt: Date(), modelID: "qwen3:4b-instruct",
            command: "get_oracle_status", target: "Oracle status", outcome: "executed")
        try OracleCommandAuditStore.append(receipt, to: url)
        let saved = try Data(contentsOf: url)
        let decoded = try JSONDecoder().decode(OracleCommandAuditReceipt.self, from: Data(saved.dropLast()))
        let attributes = try FileManager.default.attributesOfItem(atPath: url.path)
        expect(decoded.id == receipt.id && saved.last == 0x0A, "audit receipt round-trips as JSONL")
        expect((attributes[.posixPermissions] as? NSNumber)?.intValue == 0o600, "audit receipt file is owner-only")
        try? FileManager.default.removeItem(at: directory)
        print("PASS Oracle command broker: bounded tool and behavior checks")
    }
}
