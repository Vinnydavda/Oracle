import AppKit
import Foundation

@main
struct ControlCenterIntegrationTests {
    static func main() throws {
        func expect(_ condition: @autoclosure () -> Bool, _ message: String) {
            if !condition() {
                fputs("FAIL: \(message)\n", stderr)
                exit(1)
            }
        }
        let (version, build) = ControlCenterIntegrationEngine.mttVersion()
        expect(version != "Unknown" && build != "Unknown", "installed MTT metadata is readable")
        expect(FileManager.default.isExecutableFile(atPath: ControlCenterIntegrationEngine.mttExecutable), "fixed MTT executable path exists")

        let sample = try ControlCenterIntegrationEngine.captureMTTSnapshot()
        expect(sample.processStatus == "available", "MTT process telemetry bridge is available")
        expect(sample.processCount > 0, "MTT bridge returns a real process sample")
        expect((sample.memoryPhysical ?? 0) > 0, "MTT bridge returns physical memory")
        expect((sample.memoryUsed ?? 0) > 0, "MTT bridge returns a used-memory estimate")
        expect(!sample.thermalState.isEmpty, "MTT bridge returns OS thermal state")

        let now = Date()
        expect(ControlCenterIntegrationEngine.mttSampleFreshness(lastCapturedAt: nil, now: now) == .noSample, "missing MTT sample is not treated as fresh")
        expect(ControlCenterIntegrationEngine.mttSampleFreshness(lastCapturedAt: now.addingTimeInterval(-300), now: now) == .fresh, "recent MTT sample is classified fresh")
        expect(ControlCenterIntegrationEngine.mttSampleFreshness(lastCapturedAt: now.addingTimeInterval(-901), now: now) == .stale, "old MTT sample is classified stale")

        let session = ControlCenterIntegrationEngine.sessionMetadata()
        expect(session.messageCount >= 0 && session.draftLength >= 0, "MTT session metadata is bounded and non-throwing")
        let inventory = ControlCenterIntegrationEngine.inventory(
            modelAvailable: true,
            modelName: "qwen3:4b-instruct",
            vaultName: "Workspace",
            findingCount: 1
        )
        expect(inventory.contains(where: { $0.id == "device-this-mac" && $0.status == "Connected" }), "local device is shown as connected")
        expect(inventory.contains(where: { $0.id == "app-memory-triage" && $0.name == "Memory Trinity Triage" }), "MTT is inventoried as a separate app")
        expect(inventory.contains(where: { $0.id == "service-qwen" && $0.status == "Connected" }), "local Qwen is shown as connected")
        expect(inventory.contains(where: { $0.id == "device-sukuna" && $0.status == "Not connected" }), "unverified remote device is not presented as connected")
        expect(inventory.contains(where: { $0.kind == "Application" && $0.path?.hasSuffix(".app") == true }), "installed local apps are inventoried for open/reveal only")

        print("PASS Oracle control-center integration: 16 assertions; MTT \(version) build \(build)")
    }
}
