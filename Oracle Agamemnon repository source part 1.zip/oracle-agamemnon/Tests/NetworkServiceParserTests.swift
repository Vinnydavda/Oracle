import Foundation

@main
struct NetworkServiceParserTests {
    static func main() {
        func expect(_ condition: @autoclosure () -> Bool, _ message: String) {
            if !condition() {
                fputs("FAIL: \(message)\n", stderr)
                exit(1)
            }
        }

        let fixture = """
        Available network connection services in the current set (*=enabled):
        * (Disconnected)   6A745AA1-9797-445A-94DB-00F9D35006E1 VPN (ch.protonvpn.mac) "ProtonVPN" [VPN:ch.protonvpn.mac]
        * (Disconnected)   1604FA1A-6F35-4167-A4F0-81C118B648D5 VPN (io.tailscale.ipn.macsys) "Tailscale" [VPN:io.tailscale.ipn.macsys]
        """
        let disconnected = NetworkServiceParser.parse(fixture)
        expect(disconnected.count == 2, "two VPN services are parsed")
        expect(disconnected[0].name == "ProtonVPN", "quoted ProtonVPN name is preserved")
        expect(disconnected[1].name == "Tailscale", "quoted Tailscale name is preserved")
        expect(disconnected[0].state == "Disconnected", "disconnected state is not misread as connected")
        expect(disconnected[1].state == "Disconnected", "second disconnected state is preserved")

        let connected = NetworkServiceParser.parse(
            "* (Connected)   ABC VPN (example.vpn) \"Work VPN\" [VPN:example.vpn]"
        )
        expect(connected.count == 1, "connected VPN is parsed")
        expect(connected.first?.state == "Connected", "connected state is recognized")

        let malformed = NetworkServiceParser.parse("* (Connected) missing quotes [VPN:broken]")
        expect(malformed.isEmpty, "malformed VPN lines are ignored")

        let route = """
           route to: default
        destination: default
               mask: default
            gateway: 192.0.2.1
          interface: en0
              flags: <UP,GATEWAY,DONE,STATIC,PRCLONING,GLOBAL>
        """
        expect(NetworkServiceParser.defaultInterface(from: route) == "en0", "default route interface is parsed without exposing the gateway")
        expect(NetworkServiceParser.defaultInterface(from: "route to: default") == nil, "missing route interface remains unknown")
        let dns = """
        DNS configuration

        resolver #1
          search domain[0]: lan
          nameserver[0] : 192.0.2.53
          flags    : Request A records

        resolver #2
          nameserver[0] : 198.51.100.53
          flags    : Request A records
        """
        expect(NetworkServiceParser.resolverCount(from: dns) == 2, "DNS resolver count is measured without retaining addresses")
        expect(NetworkServiceParser.resolverCount(from: "DNS configuration\nNo resolvers") == nil, "missing DNS resolver state remains unknown")

        print("PASS network service parser: 12 assertions")
    }
}
