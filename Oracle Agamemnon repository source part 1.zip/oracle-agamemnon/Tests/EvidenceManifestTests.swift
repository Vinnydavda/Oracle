import Foundation

private func require(_ condition: @autoclosure () -> Bool, _ message: String) {
    guard condition() else {
        fputs("FAIL: \(message)\n", stderr)
        exit(1)
    }
}

@main
struct EvidenceManifestTests {
    static func main() throws {
        let root = FileManager.default.temporaryDirectory
            .appendingPathComponent("oracle-evidence-manifest-\(UUID().uuidString)", isDirectory: true)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: root) }
        try Data("local-evidence".utf8).write(to: root.appendingPathComponent("snapshot.jpg"))
        try Data("ignore".utf8).write(to: root.appendingPathComponent(".DS_Store"))

        let now = ISO8601DateFormatter().date(from: "2026-11-07T20:00:00Z")!
        let items = EvidenceManifestReader.read(root: root, observedAt: now, limit: 10)

        require(items.count == 1, "hidden metadata is excluded from evidence inventory")
        require(items[0].path.hasSuffix("snapshot.jpg"), "evidence path is retained")
        require(items[0].sha256 == "fd9f56894e0ca4d00852d765d4c4e6b9cc4e0f47d375515f7d188e5895e0c315",
                "content hash is computed from local bytes")
        require(items[0].kind == "jpeg", "evidence kind is derived from the local file")
        require(items[0].observedAt == now, "observation time is explicit")

        print("PASS evidence manifest: 5 assertions")
    }
}
