import Foundation

@main
struct OracleEmbodimentProtocolTests {
    static func main() throws {
        func expect(_ condition: @autoclosure () -> Bool, _ message: String) {
            if !condition() {
                fputs("FAIL: \(message)\n", stderr)
                exit(1)
            }
        }

        let sentAt = Date(timeIntervalSince1970: 1_800_000_000)
        let envelope = OracleEmbodimentEnvelope(sequence: 42, kind: .motion, payload: ["mode": "Runway"], sentAt: sentAt, eventID: UUID(uuidString: "11111111-2222-3333-4444-555555555555")!)
        let data = try OracleEmbodimentCodec.encode(envelope)
        let restored = try OracleEmbodimentCodec.decode(data)
        expect(restored == envelope, "embodiment envelope round-trips exactly")
        expect(restored.schemaVersion == "oracle.embodiment.v1", "embodiment schema is explicitly versioned")
        expect(restored.sequence == 42, "sequence number is retained for ordering")
        expect(restored.kind == .motion, "motion event type is retained")

        let frame = OracleMotionEngine.frame(mode: .runway, phase: 1.2, mouthOpenness: 0, speechProgress: 0, gesture: .wave, reduceMotion: false, sceneActive: true)
        let payload = OracleEmbodimentCodec.motionPayload(frame, mode: .runway)
        expect(payload["mode"] == "Runway", "motion payload identifies runway mode")
        expect(payload["gesture"] == "Wave", "gesture is serializable for a future rig")
        expect(payload["expression"] != nil, "expression is serializable for a future rig")
        expect(payload["foot.left.contact"] != nil && payload["foot.right.contact"] != nil, "both foot contact channels are serialized")
        expect(payload["arm.left.swing"] != nil && payload["arm.right.swing"] != nil, "both arm swing channels are serialized")
        expect(payload["jaw.open"] != nil && payload["blink"] != nil, "speech and blink channels are serialized")

        let badJSON = """
        {"schemaVersion":"oracle.embodiment.v0","eventID":"11111111-2222-3333-4444-555555555555","sequence":1,"sentAt":"2026-11-09T16:00:00Z","kind":"motion","payload":{}}
        """
        do {
            _ = try OracleEmbodimentCodec.decode(Data(badJSON.utf8))
            expect(false, "unsupported protocol version is rejected")
        } catch {
            expect(true, "unsupported protocol version is rejected")
        }

        let oversized = OracleEmbodimentEnvelope(sequence: 43, kind: .motion, payload: ["oversized": String(repeating: "a", count: 513)], sentAt: sentAt)
        do {
            _ = try OracleEmbodimentCodec.decode(OracleEmbodimentCodec.encode(oversized))
            expect(false, "oversized payload values are rejected")
        } catch {
            expect(true, "oversized payload values are rejected")
        }

        let nonfinite = OracleEmbodimentEnvelope(sequence: 44, kind: .motion, payload: ["jaw.open": "nan"], sentAt: sentAt)
        do {
            _ = try OracleEmbodimentCodec.encode(nonfinite)
            expect(false, "non-finite motion channels are rejected")
        } catch {
            expect(true, "non-finite motion channels are rejected")
        }

        let outOfRange = OracleEmbodimentEnvelope(sequence: 45, kind: .motion, payload: ["foot.left.contact": "1.5"], sentAt: sentAt)
        do {
            _ = try OracleEmbodimentCodec.encode(outOfRange)
            expect(false, "out-of-range motion channels are rejected")
        } catch {
            expect(true, "out-of-range motion channels are rejected")
        }

        let largePayload = Dictionary(uniqueKeysWithValues: (0..<40).map { ("field\($0)", String(repeating: "a", count: 500)) })
        let largeEnvelope = OracleEmbodimentEnvelope(sequence: 46, kind: .motion, payload: largePayload, sentAt: sentAt)
        do {
            _ = try OracleEmbodimentCodec.encode(largeEnvelope)
            expect(false, "encoded event size limit is enforced")
        } catch {
            expect(true, "encoded event size limit is enforced")
        }

        expect(OracleEmbodimentReadiness.requiredCapabilities.count == 10, "Raspberry Pi readiness includes expression, hands, updates and offline acceptance")
        expect(OracleEmbodimentReadiness.requiredCapabilities.allSatisfy { !$0.isConnected }, "future embodiment is not represented as connected")
        print("PASS Oracle embodiment protocol: 17 assertions")
    }
}
