import Foundation
import SceneKit

@main
struct Oracle3DMotionControllerTests {
    static func main() throws {
        func expect(_ condition: @autoclosure () -> Bool, _ message: String) {
            if !condition() { fputs("FAIL: \(message)\n", stderr); exit(1) }
        }
        guard CommandLine.arguments.count == 2 else { fatalError("Pass original Oracle USDZ path") }
        let scene = try SCNScene(url: URL(fileURLWithPath: CommandLine.arguments[1]), options: nil)
        let model = SCNNode()
        for child in scene.rootNode.childNodes { child.removeFromParentNode(); model.addChildNode(child) }
        model.eulerAngles.x = -.pi / 2
        let root = SCNNode()
        root.addChildNode(model)
        scene.rootNode.addChildNode(root)
        guard let motion = Oracle3DMotionController(motionRoot: root) else { fatalError("Original Oracle body has missing joints") }
        let idle = motion.apply(at: 0)
        expect(idle.phase == .idle, "starts idle")
        expect(idle.leftFootPlanted && idle.rightFootPlanted, "idle targets both feet as planted")
        let walk = motion.apply(at: 1.4)
        expect(walk.phase == .walking, "enters walking phase")
        expect(!walk.leftFootPlanted && walk.rightFootPlanted, "first step swings one foot")
        expect(walk.leftToeTarget.y > idle.leftToeTarget.y, "swing toe lifts")
        let turn = motion.apply(at: 4.5)
        expect(turn.phase == .turning, "enters controlled turn phase")
        let settled = motion.apply(at: 5.5)
        expect(settled.phase == .settled, "settles after turn")
        expect(settled.leftFootPlanted && settled.rightFootPlanted, "stopped pose plants both toe targets")
        expect(root.position.z > 0.4 && root.position.z < 0.5, "root travel remains bounded")
        let reduced = motion.apply(at: 5.5, reduceMotion: true)
        expect(reduced.phase == .idle, "Reduce Motion freezes the sequence")
        expect(reduced.leftFootPlanted && reduced.rightFootPlanted, "Reduce Motion restores both contacts")
        expect(root.position.z == 0, "Reduce Motion removes root travel")
        let invalid = motion.apply(at: .nan)
        expect(invalid.phase == .idle, "invalid time cannot move the body")
        print("PASS Oracle 3D motion controller: 13 assertions on original skinned USDZ")
    }
}
