import Foundation

@main
struct OracleEnergyFlowTests {
    static func main() {
        let path = OracleEnergyPath(name: "heart to hand", points: [
            SIMD3(0, 0, 0), SIMD3(0.25, 0, 0), SIMD3(0.75, 0, 0)
        ])!
        let start = OracleEnergyFlow.samples(path: path, timeSeconds: 0)
        precondition(start[0] > start[2], "pulse begins near the heart")
        let atHand = OracleEnergyFlow.samples(path: path, timeSeconds: 0.75 / 0.82)
        precondition(atHand[2] > atHand[0], "pulse reaches the hand after travelling")
        precondition(atHand[2] > 0.7, "arrival is visible above baseline")
        let reduced = OracleEnergyFlow.samples(path: path, timeSeconds: 0.75 / 0.82, reduceMotion: true)
        precondition(reduced == [0.12, 0.12, 0.12], "Reduce Motion keeps a quiet static glow")
        precondition(path.distances == [0, 0.25, 0.75], "distance follows path length")
        precondition(OracleEnergyPath(name: "invalid", points: [SIMD3(0, 0, 0)]) == nil)
        var invalid = OracleEnergySettings()
        invalid.intervalSeconds = .nan
        precondition(OracleEnergyFlow.intensity(path: path, distanceMetres: 0, timeSeconds: 1, settings: invalid) == 0)
        let delayed = OracleEnergyPath(name: "secondary", points: path.points, delaySeconds: 0.2, strength: 0.5)!
        let earlySecondary = OracleEnergyFlow.intensity(path: delayed, distanceMetres: 0.75, timeSeconds: 0.75 / 0.82)
        precondition(earlySecondary < atHand[2], "secondary branch is weaker and delayed")
        print("PASS Oracle energy flow: 8 assertions")
    }
}
