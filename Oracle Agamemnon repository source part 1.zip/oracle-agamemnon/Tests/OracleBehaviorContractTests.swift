import Foundation

@main
struct OracleBehaviorContractTests {
    static func main() throws {
        func expect(_ condition: @autoclosure () -> Bool, _ label: String) {
            if !condition() { fputs("FAIL \(label)\n", stderr); exit(1) }
        }
        func raw(_ gesture: String = "openPalm", _ phrase: String = "the next step") -> [String: Any] {
            ["gesture": gesture, "expression": "calm", "gaze": "center",
             "intensity": 0.4, "emphasis_text": phrase]
        }
        let proposal = try OracleBehaviorProposal.parse(raw())
        expect(proposal.supportedGestureCue == .openPalm, "gesture maps to supported cue")
        expect(proposal.emphasisFraction(in: "Here is the next step for Oracle.") != nil,
               "actual reply phrase yields speech position")
        expect(proposal.emphasisFraction(in: "the next step is clear.")! > 0,
               "first-phrase cue waits for an actual word-progress callback")
        expect(proposal.emphasisFraction(in: "I cannot verify that yet.") == nil,
               "unmatched phrase cannot start gesture")
        let emoji = try OracleBehaviorProposal.parse(raw("handToHeart", "Oracle"))
        let fraction = emoji.emphasisFraction(in: "✨ Oracle is here.")!
        expect(fraction > 0 && fraction < 0.3, "speech position uses UTF-16 units")
        for invalid in ["wave", "nod", "run_shell", "point"] {
            do { _ = try OracleBehaviorProposal.parse(raw(invalid)); expect(false, "unsupported \(invalid)") }
            catch { }
        }
        var injected = raw(); injected["command"] = "open /tmp"
        do { _ = try OracleBehaviorProposal.parse(injected); expect(false, "extra argument") } catch { }
        var unsupportedGaze = raw(); unsupportedGaze["gaze"] = "left"
        do { _ = try OracleBehaviorProposal.parse(unsupportedGaze); expect(false, "gaze lacks rig control") } catch { }
        var strong = raw(); strong["intensity"] = 1.0
        do { _ = try OracleBehaviorProposal.parse(strong); expect(false, "excess intensity") } catch { }
        do { _ = try OracleBehaviorProposal.parse(raw("handToHeart", " ")); expect(false, "unanchored gesture") } catch { }
        print("PASS Oracle behavior contract: bounded cue parsing and phrase alignment")
    }
}
