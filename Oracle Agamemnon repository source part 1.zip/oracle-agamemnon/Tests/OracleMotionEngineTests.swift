import Foundation

@main
struct OracleMotionEngineTests {
    static func main() {
        func expect(_ condition: @autoclosure () -> Bool, _ message: String) {
            if !condition() {
                fputs("FAIL: \(message)\n", stderr)
                exit(1)
            }
        }

        let idleA = OracleMotionEngine.frame(mode: .idle, phase: 1.0, mouthOpenness: 0, speechProgress: 0, gesture: .none, reduceMotion: false, sceneActive: true)
        let idleB = OracleMotionEngine.frame(mode: .idle, phase: 2.0, mouthOpenness: 0, speechProgress: 0, gesture: .none, reduceMotion: false, sceneActive: true)
        expect(idleA != idleB, "idle motion changes over time")
        expect(abs(idleA.bodyOffsetX) <= 12 && abs(idleA.bodyRotation) <= 3, "idle body motion stays bounded")

        let runwayA = OracleMotionEngine.frame(mode: .runway, phase: 0.6, mouthOpenness: 0, speechProgress: 0, gesture: .none, reduceMotion: false, sceneActive: true)
        let runwayB = OracleMotionEngine.frame(mode: .runway, phase: 1.1, mouthOpenness: 0, speechProgress: 0, gesture: .none, reduceMotion: false, sceneActive: true)
        expect(runwayA.hipSway != runwayB.hipSway, "runway cadence moves the hip line")
        expect(runwayA.shoulderRoll != runwayB.shoulderRoll, "runway cadence counter-rolls the shoulders")
        expect(runwayA.catwalkPulse >= 0 && runwayA.catwalkPulse <= 1, "catwalk energy remains bounded")
        expect(runwayA.bodyScale >= 0.95 && runwayA.bodyScale <= 1.04, "runway camera scale remains bounded")
        expect(runwayA.leftFootContact != runwayA.rightFootContact, "runway motion exports alternating foot contact")
        expect(runwayA.leftArmSwing == -runwayA.rightArmSwing, "runway arm channels counter-swing")
        expect(abs(runwayA.weightShift) <= 1, "runway weight transfer stays normalized")

        let wave = OracleMotionEngine.frame(mode: .greeting, phase: 0.2, mouthOpenness: 0, speechProgress: 0, gesture: .wave, reduceMotion: false, sceneActive: true)
        expect(wave.rightHandPulse > 0.6, "wave activates right-hand energy")
        let palms = OracleMotionEngine.frame(mode: .greeting, phase: 0.2, mouthOpenness: 0, speechProgress: 0, gesture: .openPalm, reduceMotion: false, sceneActive: true)
        expect(palms.leftHandPulse > 0.5 && palms.rightHandPulse > 0.5, "open-palm gesture activates both hands")
        let heart = OracleMotionEngine.frame(mode: .idle, phase: 0.2, mouthOpenness: 0, speechProgress: 0, gesture: .handToHeart, reduceMotion: false, sceneActive: true)
        expect(heart.leftHandPulse == 1 && heart.maskPulse >= 0.72, "hand-to-heart gesture links hand and mask energy")
        let bow = OracleMotionEngine.frame(mode: .idle, phase: 0.2, mouthOpenness: 0, speechProgress: 0, gesture: .bow, reduceMotion: false, sceneActive: true)
        expect(bow.bodyOffsetY > 0 && bow.headTilt > 0, "bow lowers the body and tips the head line")

        let speaking = OracleMotionEngine.frame(mode: .speaking, phase: 0.7, mouthOpenness: 0.9, speechProgress: 0.4, gesture: .none, reduceMotion: false, sceneActive: true)
        expect(speaking.expression == .speaking, "speech selects the speaking mask expression")
        expect(speaking.maskPulse > 0.7, "speech amplitude drives mask energy")
        expect(speaking.jawOpen == 0.9, "speech cue exports bounded jaw openness")
        expect(speaking.leftHandPulse == 0 && speaking.rightHandPulse == 0, "speech alone does not invent a hand gesture")
        expect(speaking.headTilt == 0 && speaking.bodyRotation == 0, "speech alone does not add a nod or sway")

        let reduced = OracleMotionEngine.frame(mode: .runway, phase: 9.2, mouthOpenness: 0, speechProgress: 0, gesture: .turn, reduceMotion: true, sceneActive: true)
        expect(reduced.bodyOffsetX == 0, "Reduce Motion suppresses timed translation")
        expect(reduced.catwalkPulse == 0, "Reduce Motion suppresses catwalk pulse")
        expect(reduced.leftFootContact == 1 && reduced.rightFootContact == 1, "Reduce Motion removes alternating gait")

        let paused = OracleMotionEngine.frame(mode: .runway, phase: 9.2, mouthOpenness: 0, speechProgress: 0, gesture: .none, reduceMotion: false, sceneActive: false)
        expect(paused.hairDrift == 0, "inactive scene pauses hair motion")
        expect(paused.blink == 0, "inactive scene pauses blink channel")

        let reducedSpeech = OracleMotionEngine.frame(mode: .speaking, phase: 9.2, mouthOpenness: 0.5, speechProgress: 0.5, gesture: .none, reduceMotion: true, sceneActive: true)
        expect(reducedSpeech.bodyRotation == 0 && reducedSpeech.perspective == 0 && reducedSpeech.headTilt == 0, "Reduce Motion suppresses timed speaking sway")

        let invalidTime = OracleMotionEngine.frame(mode: .runway, phase: .infinity, mouthOpenness: 0, speechProgress: 0, gesture: .none, reduceMotion: false, sceneActive: true)
        expect(invalidTime.bodyOffsetX.isFinite && invalidTime.blink.isFinite, "invalid time cannot emit non-finite rig channels")
        let invalidAudio = OracleMotionEngine.frame(mode: .speaking, phase: 0, mouthOpenness: .nan, speechProgress: .infinity, gesture: .none, reduceMotion: false, sceneActive: true)
        expect(invalidAudio.jawOpen == 0 && invalidAudio.maskPulse.isFinite, "invalid audio metrics cannot emit non-finite rig channels")

        expect(OracleGestureCue.allCases.count == 8, "gesture vocabulary includes wave, palm, point, heart, hair, turn and bow")
        expect(OracleMaskExpression.allCases.count == 7, "mask expression vocabulary is complete")
        print("PASS Oracle motion engine: 27 assertions")
    }
}
