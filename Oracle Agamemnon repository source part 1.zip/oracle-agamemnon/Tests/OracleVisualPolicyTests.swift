import Foundation

private func require(_ condition: @autoclosure () -> Bool, _ message: String) {
    guard condition() else {
        fputs("FAIL: \(message)\n", stderr)
        exit(1)
    }
}

@main
struct OracleVisualPolicyTests {
    static func main() {
        let standard = OracleVisualPolicy.make(
            reduceMotion: false,
            reduceTransparency: false,
            increaseContrast: false,
            sceneActive: true
        )
        require(standard.animationEnabled, "active window enables bounded ambient motion")
        require(standard.blurRadius > 0, "standard mode uses native material blur")
        require(standard.glassOpacity < 0.8, "standard glass remains translucent")

        let reducedMotion = OracleVisualPolicy.make(
            reduceMotion: true,
            reduceTransparency: false,
            increaseContrast: false,
            sceneActive: true
        )
        require(!reducedMotion.animationEnabled, "Reduce Motion disables ambient animation")

        let background = OracleVisualPolicy.make(
            reduceMotion: false,
            reduceTransparency: false,
            increaseContrast: false,
            sceneActive: false
        )
        require(!background.animationEnabled, "inactive scene pauses animation")

        let opaque = OracleVisualPolicy.make(
            reduceMotion: false,
            reduceTransparency: true,
            increaseContrast: false,
            sceneActive: true
        )
        require(opaque.blurRadius == 0, "Reduce Transparency removes backdrop blur")
        require(opaque.glassOpacity >= 0.8, "Reduce Transparency uses a readable opaque fallback")

        let contrast = OracleVisualPolicy.make(
            reduceMotion: false,
            reduceTransparency: false,
            increaseContrast: true,
            sceneActive: true
        )
        require(contrast.borderOpacity > standard.borderOpacity, "Increase Contrast strengthens surface edges")
        require(contrast.secondaryTextOpacity > standard.secondaryTextOpacity, "Increase Contrast strengthens secondary text")

        print("PASS Oracle visual policy: 8 assertions")
    }
}
