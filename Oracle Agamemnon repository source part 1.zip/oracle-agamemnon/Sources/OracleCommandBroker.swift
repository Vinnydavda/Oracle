import Foundation

/// The model can request only these exact in-app operations. It never supplies
/// an executable path, shell text, filesystem path, URL, or arbitrary selector.
enum OracleCommandRequest: Equatable {
    case status
    case openSection(String)
    case behavior(OracleBehaviorProposal)

    var name: String {
        switch self {
        case .status: return "get_oracle_status"
        case .openSection: return "open_oracle_section"
        case .behavior: return "propose_oracle_behavior"
        }
    }
}

enum OracleCommandBroker {
    static let navigableSections = ["Overview", "Oracle", "Connections", "Memory Brain", "Schematics", "Settings"]
    static let maximumToolResultBytes = 2_048

    static func navigationAllowed(modelToolsEnabled: Bool, readOnlyToolsOnly: Bool, hasAttachedContext: Bool) -> Bool {
        modelToolsEnabled && !readOnlyToolsOnly && !hasAttachedContext
    }

    static func schemas(allowNavigation: Bool, allowBehavior: Bool = false) -> [[String: Any]] {
        var result: [[String: Any]] = [[
            "type": "function",
            "function": [
                "name": "get_oracle_status",
                "description": "Read Oracle's current in-app provider, security, camera and page status. This does not run a system command.",
                "parameters": ["type": "object", "properties": [:], "additionalProperties": false] as [String: Any]
            ]
        ]]
        if allowBehavior { result.append([
            "type": "function",
            "function": [
                "name": "propose_oracle_behavior",
                "description": "Suggest one restrained speech-timed light cue for the final reply. The emphasis text must appear verbatim in the final spoken reply. This does not move a 3D rig or run code.",
                "parameters": [
                    "type": "object",
                    "required": ["gesture", "expression", "gaze", "intensity", "emphasis_text"],
                    "properties": [
                        "gesture": ["type": "string", "enum": ["none", "openPalm", "handToHeart"]],
                        "expression": ["type": "string", "enum": ["calm", "warm", "curious", "confident"]],
                        "gaze": ["type": "string", "enum": ["center"]],
                        "intensity": ["type": "number", "minimum": 0, "maximum": OracleBehaviorProposal.maximumIntensity],
                        "emphasis_text": ["type": "string", "maxLength": OracleBehaviorProposal.maximumEmphasisCharacters]
                    ],
                    "additionalProperties": false
                ] as [String: Any]
            ]
        ]) }
        if allowNavigation {
            result.append([
                "type": "function",
                "function": [
                    "name": "open_oracle_section",
                    "description": "Navigate the current Oracle window to one named page. This does not change system settings or files.",
                    "parameters": [
                        "type": "object",
                        "required": ["section"],
                        "properties": ["section": ["type": "string", "enum": navigableSections]],
                        "additionalProperties": false
                    ] as [String: Any]
                ]
            ])
        }
        return result
    }

    static func request(from message: [String: Any], allowNavigation: Bool, allowBehavior: Bool = false) throws -> OracleCommandRequest? {
        guard let rawCalls = message["tool_calls"] else { return nil }
        guard let calls = rawCalls as? [[String: Any]], calls.count == 1,
              let function = calls[0]["function"] as? [String: Any],
              let name = function["name"] as? String,
              let arguments = function["arguments"] as? [String: Any] else {
            throw failure("Oracle refused malformed or multiple model tool calls.")
        }
        switch name {
        case "get_oracle_status":
            guard arguments.isEmpty else { throw failure("Oracle status takes no arguments.") }
            return .status
        case "propose_oracle_behavior":
            guard allowBehavior else { throw failure("Oracle refused a behavior cue without active local reply speech.") }
            return .behavior(try OracleBehaviorProposal.parse(arguments))
        case "open_oracle_section":
            guard allowNavigation, arguments.count == 1,
                  let section = arguments["section"] as? String,
                  navigableSections.contains(section) else {
                throw failure("Oracle refused an unapproved page navigation.")
            }
            return .openSection(section)
        default:
            throw failure("Oracle refused an unknown model tool.")
        }
    }

    static func followupBody(originalRequest: Data, assistantMessage: [String: Any], request: OracleCommandRequest,
                             result: String) throws -> Data {
        guard result.utf8.count <= maximumToolResultBytes,
              let calls = assistantMessage["tool_calls"] as? [[String: Any]], calls.count == 1,
              var payload = try JSONSerialization.jsonObject(with: originalRequest) as? [String: Any],
              var messages = payload["messages"] as? [[String: Any]] else {
            throw failure("Oracle tool result could not be bounded or encoded.")
        }
        messages.append(["role": "assistant", "content": assistantMessage["content"] as? String ?? "", "tool_calls": calls])
        messages.append(["role": "tool", "tool_name": request.name, "content": result])
        payload["messages"] = messages
        payload["stream"] = false
        payload.removeValue(forKey: "tools") // At most one tool step per owner request.
        let body = try JSONSerialization.data(withJSONObject: payload)
        guard body.count <= OracleChatRequestBuilder.maximumBodyBytes else {
            throw failure("Oracle tool follow-up exceeded the local request budget.")
        }
        return body
    }

    private static func failure(_ detail: String) -> NSError {
        NSError(domain: "OracleCommand", code: 1, userInfo: [NSLocalizedDescriptionKey: detail])
    }
}

struct OracleCommandAuditReceipt: Codable {
    let id: UUID
    let observedAt: Date
    let modelID: String
    let command: String
    let target: String
    let outcome: String
}

enum OracleCommandAuditStore {
    static func append(_ receipt: OracleCommandAuditReceipt, to url: URL) throws {
        let manager = FileManager.default
        try manager.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
        let line = try JSONEncoder().encode(receipt) + Data([0x0A])
        if !manager.fileExists(atPath: url.path) {
            guard manager.createFile(atPath: url.path, contents: nil, attributes: [.posixPermissions: 0o600]) else {
                throw NSError(domain: "OracleCommandAudit", code: 1, userInfo: [NSLocalizedDescriptionKey: "Could not create command audit file."])
            }
        }
        let handle = try FileHandle(forWritingTo: url)
        defer { try? handle.close() }
        try handle.seekToEnd()
        try handle.write(contentsOf: line)
        try manager.setAttributes([.posixPermissions: 0o600], ofItemAtPath: url.path)
    }
}
