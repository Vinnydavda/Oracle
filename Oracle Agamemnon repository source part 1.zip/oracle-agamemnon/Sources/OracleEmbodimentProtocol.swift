import Foundation

/// Versioned contract for a future owner-authorized local embodiment host,
/// including a Raspberry Pi running Oracle offline. This file performs no
/// network access and contains no pairing secret.
enum OracleEmbodimentProtocolVersion {
    static let current = "oracle.embodiment.v1"
}

enum OracleEmbodimentEventKind: String, Codable, CaseIterable {
    case capabilities
    case heartbeat
    case motion
    case expression
    case speechStart = "speech.start"
    case speechProgress = "speech.progress"
    case speechEnd = "speech.end"
    case gesture
    case stop
    case error
}

struct OracleEmbodimentEnvelope: Codable, Equatable {
    let schemaVersion: String
    let eventID: UUID
    let sequence: UInt64
    let sentAt: Date
    let kind: OracleEmbodimentEventKind
    let payload: [String: String]

    init(sequence: UInt64, kind: OracleEmbodimentEventKind, payload: [String: String] = [:], sentAt: Date = Date(), eventID: UUID = UUID()) {
        self.schemaVersion = OracleEmbodimentProtocolVersion.current
        self.eventID = eventID
        self.sequence = sequence
        self.sentAt = sentAt
        self.kind = kind
        self.payload = payload
    }
}

struct OracleEmbodimentCapabilities: Codable, Equatable {
    let schemaVersion: String
    let hostName: String
    let offlineCapable: Bool
    let transports: [String]
    let supportsMotionRig: Bool
    let supportsLipSync: Bool
    let supportsAudioPlayback: Bool
    let supportsSecurePairing: Bool
    let maxMotionUpdatesPerSecond: Int
    let capabilities: [String]
}

enum OracleEmbodimentCodec {
    private static let maximumEventBytes = 16_384

    static func encode(_ envelope: OracleEmbodimentEnvelope) throws -> Data {
        try validate(envelope)
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        encoder.outputFormatting = [.sortedKeys]
        let data = try encoder.encode(envelope)
        guard data.count <= maximumEventBytes else {
            throw NSError(domain: "OracleEmbodiment", code: 3, userInfo: [NSLocalizedDescriptionKey: "Embodiment event exceeds the local size limit."])
        }
        return data
    }

    static func decode(_ data: Data) throws -> OracleEmbodimentEnvelope {
        guard data.count <= maximumEventBytes else {
            throw NSError(domain: "OracleEmbodiment", code: 3, userInfo: [NSLocalizedDescriptionKey: "Embodiment event exceeds the local size limit."])
        }
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        let envelope = try decoder.decode(OracleEmbodimentEnvelope.self, from: data)
        try validate(envelope)
        return envelope
    }

    private static func validate(_ envelope: OracleEmbodimentEnvelope) throws {
        guard envelope.schemaVersion == OracleEmbodimentProtocolVersion.current else {
            throw NSError(domain: "OracleEmbodiment", code: 1, userInfo: [NSLocalizedDescriptionKey: "Unsupported embodiment protocol version."])
        }
        guard envelope.payload.count <= 64,
              envelope.payload.allSatisfy({ pair in pair.key.count <= 64 && pair.value.utf8.count <= 512 }) else {
            throw NSError(domain: "OracleEmbodiment", code: 2, userInfo: [NSLocalizedDescriptionKey: "Embodiment payload exceeds the bounded schema."])
        }
        if envelope.kind == .motion {
            let ranges: [String: ClosedRange<Double>] = [
                "offset.x": -12...12, "offset.y": -10...18,
                "scale": 0.95...1.04, "rotation": -3...3, "perspective": -12...12,
                "hip": -1...1, "shoulder": -1...1, "head": -5...5, "hair": -1...1,
                "foot.left.contact": 0...1, "foot.right.contact": 0...1,
                "arm.left.swing": -1...1, "arm.right.swing": -1...1,
                "weight.shift": -1...1, "gaze.x": -1...1, "blink": 0...1,
                "jaw.open": 0...1, "finger.left.curl": 0...1, "finger.right.curl": 0...1
            ]
            for (key, bounds) in ranges {
                guard let raw = envelope.payload[key] else { continue }
                guard let value = Double(raw), value.isFinite, bounds.contains(value) else {
                    throw NSError(domain: "OracleEmbodiment", code: 4, userInfo: [NSLocalizedDescriptionKey: "Invalid motion channel: \(key)."])
                }
            }
        }
    }

    static func motionPayload(_ frame: OracleMotionFrame, mode: OracleMotionMode) -> [String: String] {
        [
            "mode": mode.rawValue,
            "offset.x": String(format: "%.4f", frame.bodyOffsetX),
            "offset.y": String(format: "%.4f", frame.bodyOffsetY),
            "scale": String(format: "%.4f", frame.bodyScale),
            "rotation": String(format: "%.4f", frame.bodyRotation),
            "perspective": String(format: "%.4f", frame.perspective),
            "hip": String(format: "%.4f", frame.hipSway),
            "shoulder": String(format: "%.4f", frame.shoulderRoll),
            "head": String(format: "%.4f", frame.headTilt),
            "hair": String(format: "%.4f", frame.hairDrift),
            "foot.left.contact": String(format: "%.4f", frame.leftFootContact),
            "foot.right.contact": String(format: "%.4f", frame.rightFootContact),
            "arm.left.swing": String(format: "%.4f", frame.leftArmSwing),
            "arm.right.swing": String(format: "%.4f", frame.rightArmSwing),
            "weight.shift": String(format: "%.4f", frame.weightShift),
            "gaze.x": String(format: "%.4f", frame.gazeX),
            "blink": String(format: "%.4f", frame.blink),
            "jaw.open": String(format: "%.4f", frame.jawOpen),
            "finger.left.curl": String(format: "%.4f", frame.leftFingerCurl),
            "finger.right.curl": String(format: "%.4f", frame.rightFingerCurl),
            "expression": frame.expression.rawValue,
            "gesture": frame.gesture.rawValue
        ]
    }
}

struct OracleEmbodimentRequirement: Identifiable, Hashable {
    let id: String
    let title: String
    let detail: String
    let isConnected: Bool
}

enum OracleEmbodimentReadiness {
    static let requiredCapabilities = [
        OracleEmbodimentRequirement(id: "offline-local-model", title: "Offline local model", detail: "Versioned, bounded model runtime available without cloud dependency.", isConnected: false),
        OracleEmbodimentRequirement(id: "secure-pairing", title: "Owner pairing", detail: "Per-device credential exchange and revocation; no shared magic token.", isConnected: false),
        OracleEmbodimentRequirement(id: "motion-rig", title: "Motion rig", detail: "Skinned humanoid or approved motion renderer accepting oracle.embodiment.v1 motion frames.", isConnected: false),
        OracleEmbodimentRequirement(id: "lip-sync", title: "Lip synchronization", detail: "Timestamped phoneme/amplitude stream with bounded latency and speech cancellation.", isConnected: false),
        OracleEmbodimentRequirement(id: "audio", title: "Audio endpoint", detail: "Local speaker output with device-specific gain and explicit stop.", isConnected: false),
        OracleEmbodimentRequirement(id: "heartbeat", title: "Heartbeat and recovery", detail: "Sequence validation, stale detection, reconnect and queued-state recovery.", isConnected: false),
        OracleEmbodimentRequirement(id: "facial-rig", title: "Expression channels", detail: "Approved face or mask rig supports gaze, blink, jaw and expression cues without inventing anatomy.", isConnected: false),
        OracleEmbodimentRequirement(id: "hand-rig", title: "Hand articulation", detail: "Both hands support calibrated gesture poses and finger channels.", isConnected: false),
        OracleEmbodimentRequirement(id: "versioned-updates", title: "Signed updates", detail: "Signed model, rig and runtime packages with compatibility checks and rollback.", isConnected: false),
        OracleEmbodimentRequirement(id: "offline-test", title: "Offline acceptance", detail: "Air-gapped speech, stop, recovery and motion tests pass on the target device.", isConnected: false)
    ]
}
