import CryptoKit
import Foundation

struct LocalCommandResult {
    let output: String
    let exitCode: Int32
    let timedOut: Bool
    let error: String?
}

enum LocalCommand {
    static func run(_ executable: String, _ arguments: [String], timeout: TimeInterval = 8) -> LocalCommandResult {
        guard FileManager.default.isExecutableFile(atPath: executable) else {
            return LocalCommandResult(output: "", exitCode: -1, timedOut: false, error: "Executable not found")
        }
        let process = Process()
        process.executableURL = URL(fileURLWithPath: executable)
        process.arguments = arguments
        let pipe = Pipe()
        process.standardOutput = pipe
        process.standardError = pipe
        var output = Data()
        let group = DispatchGroup()
        group.enter()
        DispatchQueue.global(qos: .utility).async {
            do {
                try process.run()
                output = pipe.fileHandleForReading.readDataToEndOfFile()
                process.waitUntilExit()
            } catch {
                output = Data(error.localizedDescription.utf8)
            }
            group.leave()
        }
        if group.wait(timeout: .now() + timeout) == .timedOut {
            process.terminate()
            _ = group.wait(timeout: .now() + 2)
            return LocalCommandResult(output: String(data: output, encoding: .utf8) ?? "", exitCode: -1, timedOut: true, error: "Command timed out")
        }
        return LocalCommandResult(
            output: String(data: output, encoding: .utf8) ?? "",
            exitCode: process.terminationStatus,
            timedOut: false,
            error: nil
        )
    }
}

enum ProtectionEngine {
    static let maintainedEnginePaths = ["/opt/homebrew/bin/clamscan", "/usr/local/bin/clamscan", "/opt/homebrew/bin/yara", "/usr/local/bin/yara"]

    static func collectPosture(now: Date = Date()) -> ProtectionPosture {
        let os = LocalCommand.run("/usr/bin/sw_vers", []).output
        let version = os.split(separator: "\n").first(where: { $0.hasPrefix("ProductVersion:") })?
            .replacingOccurrences(of: "ProductVersion:", with: "").trimmingCharacters(in: .whitespacesAndNewlines) ?? "Unknown"
        let fileVault = normalized(LocalCommand.run("/usr/bin/fdesetup", ["status"]).output, fallback: "Unknown")
        let gatekeeper = normalized(LocalCommand.run("/usr/sbin/spctl", ["--status"]).output, fallback: "Unknown")
        let sip = normalized(LocalCommand.run("/usr/bin/csrutil", ["status"]).output, fallback: "Unknown")
        let firewall = normalized(LocalCommand.run("/usr/libexec/ApplicationFirewall/socketfilterfw", ["--getglobalstate"]).output, fallback: "Unknown")
        let xprotect = LocalCommand.run("/usr/bin/defaults", ["read", "/Library/Apple/System/Library/CoreServices/XProtect.bundle/Contents/Info", "CFBundleShortVersionString"]).output
            .trimmingCharacters(in: .whitespacesAndNewlines)
        let timeMachine = LocalCommand.run("/usr/bin/tmutil", ["destinationinfo"]).output
        return ProtectionPosture(
            observedAt: now,
            macosVersion: version,
            fileVault: fileVault,
            gatekeeper: gatekeeper,
            sip: sip,
            firewall: firewall,
            xprotectVersion: xprotect.isEmpty ? "Unknown" : xprotect,
            timeMachineDestinations: timeMachine.split(separator: "\n").filter { $0.contains("Name:") || $0.contains("ID:") }.count
        )
    }

    static func collectProcesses() -> [ProcessObservation] {
        let result = LocalCommand.run("/bin/ps", ["-axo", "pid=,ppid=,user=,pcpu=,pmem=,comm="], timeout: 6)
        return result.output.split(separator: "\n").compactMap { line in
            let parts = line.split(separator: " ", maxSplits: 5, omittingEmptySubsequences: true)
            guard parts.count == 6,
                  let pid = Int32(parts[0]),
                  let ppid = Int32(parts[1]),
                  let cpu = Double(parts[3]),
                  let memory = Double(parts[4]) else { return nil }
            return ProcessObservation(pid: pid, parentPID: ppid, user: String(parts[2]), cpuPercent: cpu, memoryPercent: memory, executable: String(parts[5]))
        }
    }

    static func collectConnections() -> [ConnectionObservation] {
        let result = LocalCommand.run("/usr/sbin/lsof", ["-nP", "-iTCP", "-sTCP:ESTABLISHED", "-F", "pcn"], timeout: 8)
        var observations: [ConnectionObservation] = []
        var pid: Int32?
        var command = ""
        for line in result.output.split(separator: "\n") {
            guard let first = line.first else { continue }
            let value = String(line.dropFirst())
            switch first {
            case "p": pid = Int32(value)
            case "c": command = value
            case "n":
                if let pid { observations.append(ConnectionObservation(pid: pid, command: command, endpoint: value)) }
            default: break
            }
        }
        return observations
    }

    static func collectPersistence() -> [PersistenceObservation] {
        let roots = [
            URL(fileURLWithPath: NSHomeDirectory()).appendingPathComponent("Library/LaunchAgents"),
            URL(fileURLWithPath: "/Library/LaunchAgents"),
            URL(fileURLWithPath: "/Library/LaunchDaemons")
        ]
        var rows: [PersistenceObservation] = []
        for root in roots {
            guard let urls = try? FileManager.default.contentsOfDirectory(at: root, includingPropertiesForKeys: nil, options: [.skipsHiddenFiles]) else { continue }
            for url in urls where url.pathExtension.lowercased() == "plist" {
                guard let data = try? Data(contentsOf: url),
                      let plist = try? PropertyListSerialization.propertyList(from: data, format: nil) as? [String: Any] else { continue }
                let program = plist["Program"] as? String ?? (plist["ProgramArguments"] as? [String])?.first ?? ""
                let arguments = plist["ProgramArguments"] as? [String] ?? []
                rows.append(PersistenceObservation(
                    name: plist["Label"] as? String ?? url.deletingPathExtension().lastPathComponent,
                    path: url.path,
                    program: program,
                    arguments: arguments,
                    isDaemon: root.path.hasSuffix("LaunchDaemons")
                ))
            }
        }
        return rows
    }

    static func runAudit(now: Date = Date()) -> ProtectionAuditResult {
        let posture = collectPosture(now: now)
        let processes = collectProcesses()
        let connections = collectConnections()
        let persistence = collectPersistence()
        var findings: [ProtectionFinding] = []
        var warnings: [String] = []

        func add(_ key: String, _ title: String, _ severity: ProtectionSeverity, _ source: String, _ resource: String, _ evidence: [String], _ rationale: String, _ confidence: String) {
            findings.append(ProtectionFinding(
                id: UUID(), dedupeKey: key, createdAt: now, lastObservedAt: now, occurrences: 1,
                title: title, severity: severity, source: source, resource: resource,
                evidence: evidence, rationale: rationale, confidence: confidence,
                reviewStatus: .open, canQuarantine: false
            ))
        }

        if !posture.fileVault.lowercased().contains("on") {
            add("config.filevault", "FileVault is not observed as enabled", .high, "fdesetup", "Macintosh HD", [posture.fileVault], "Full-disk encryption may be unavailable when the Mac is powered off.", "High")
        }
        if !posture.sip.lowercased().contains("enabled") {
            add("config.sip", "System Integrity Protection is not observed as enabled", .high, "csrutil", "macOS", [posture.sip], "Core system files may not be protected by SIP.", "High")
        }
        if !posture.firewall.lowercased().contains("enabled") {
            add("config.firewall", "Application firewall is not observed as enabled", .high, "socketfilterfw", "macOS", [posture.firewall], "Unsolicited inbound connections may be less restricted.", "High")
        }
        if !posture.gatekeeper.lowercased().contains("enabled") {
            add("config.gatekeeper", "Gatekeeper assessments are not observed as enabled", .high, "spctl", "macOS", [posture.gatekeeper], "Unsigned or unnotarized software assessment is weakened.", "High")
        }
        if posture.timeMachineDestinations == 0 {
            add("config.backup", "No Time Machine destination is configured", .medium, "tmutil", "Backups", ["No destination reported at \(now.formatted())"], "Ransomware recovery and evidence restoration options are reduced without a verified backup destination.", "High")
        }

        let suspiciousPaths = ["/tmp/", "/private/tmp/", "/Downloads/"]
        let processByPID = Dictionary(uniqueKeysWithValues: processes.map { ($0.pid, $0) })
        for process in processes where suspiciousPaths.contains(where: { process.executable.contains($0) }) {
            add(
                "process.untracked.\(process.pid).\(process.executable)",
                "Executable running from a high-risk user path",
                process.executable.contains("/Downloads/") ? .high : .medium,
                "ps", process.executable,
                ["PID \(process.pid)", "CPU \(String(format: "%.1f", process.cpuPercent))%", "Memory \(String(format: "%.1f", process.memoryPercent))%"],
                "A running executable outside standard application paths can be legitimate, but warrants review.", "Medium"
            )
        }

        for row in persistence {
            let joined = ([row.program] + row.arguments).joined(separator: " ").lowercased()
            if suspiciousPaths.contains(where: { row.program.contains($0) }) || joined.contains("curl ") || joined.contains("wget ") || joined.contains("base64 -d") {
                add(
                    "persistence.\(row.path)", "Suspicious persistence definition requires review", .high,
                    "launchd plist", row.path,
                    ["Label: \(row.name)", "Program: \(row.program)", "Arguments inspected without persistence"],
                    "A login item or launch agent invoking a high-risk path or download pipeline can indicate unwanted persistence.", "Medium"
                )
            }
        }

        for connection in connections {
            guard let process = processByPID[connection.pid],
                  suspiciousPaths.contains(where: { process.executable.contains($0) }),
                  !connection.endpoint.contains("127.0.0.1"), !connection.endpoint.contains("[::1]") else { continue }
            add(
                "network.\(connection.pid).\(connection.endpoint)", "High-risk executable has an outbound connection", .high,
                "lsof", process.executable,
                ["PID \(connection.pid)", "Endpoint \(connection.endpoint)"],
                "A process running from a high-risk path has an established non-loopback TCP connection. This is a heuristic, not proof of compromise.", "Medium"
            )
        }

        if processes.isEmpty { warnings.append("Process inventory unavailable or empty.") }
        if connections.isEmpty { warnings.append("No established TCP connections were observed; this is not proof that none exist.") }
        if persistence.isEmpty { warnings.append("No launch-agent persistence records were readable.") }
        return ProtectionAuditResult(observedAt: now, posture: posture, processes: processes, connections: connections, persistence: persistence, findings: findings, warnings: warnings)
    }

    static func scanFiles(root: URL, snapshotURL: URL, maximumFiles: Int = 5_000, now: Date = Date()) -> ProtectionScanReport {
        let started = now
        let fm = FileManager.default
        let root = root.standardizedFileURL.resolvingSymlinksInPath()
        var findings: [ProtectionFinding] = []
        var warnings: [String] = []
        var inspected = 0
        var bytes: UInt64 = 0
        var snapshot: [String: FileSnapshotEntry] = [:]
        var signatureChecks = 0

        guard let enumerator = fm.enumerator(
            at: root,
            includingPropertiesForKeys: [.isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey, .contentModificationDateKey, .isDirectoryKey],
            options: [.skipsHiddenFiles, .skipsPackageDescendants]
        ) else {
            warnings.append("The selected scan folder could not be enumerated.")
            return ProtectionScanReport(id: UUID(), rootPath: root.path, startedAt: started, completedAt: Date(), filesInspected: 0, bytesInspected: 0, findings: findings, warnings: warnings, engine: "Deterministic local scanner + Apple signing assessment", cancelled: false)
        }

        for case let url as URL in enumerator {
            if Task.isCancelled {
                return ProtectionScanReport(id: UUID(), rootPath: root.path, startedAt: started, completedAt: Date(), filesInspected: inspected, bytesInspected: bytes, findings: findings, warnings: warnings, engine: "Deterministic local scanner + Apple signing assessment", cancelled: true)
            }
            if inspected >= maximumFiles {
                warnings.append("File limit reached at \(maximumFiles); the scan is bounded, not exhaustive.")
                break
            }
            guard let values = try? url.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey, .contentModificationDateKey]),
                  values.isRegularFile == true,
                  values.isSymbolicLink != true else { continue }
            inspected += 1
            let size = UInt64(values.fileSize ?? 0)
            bytes += size
            let modified = values.contentModificationDate ?? now
            snapshot[url.path] = FileSnapshotEntry(size: size, modifiedAt: modified)

            let ext = url.pathExtension.lowercased()
            let suspiciousExtension = ["sh", "command", "scpt", "py", "js", "exe", "scr", "pkg"].contains(ext)
            let inspectLimit: UInt64 = suspiciousExtension || size <= 2_000_000 ? 2_000_000 : 16_384
            guard let handle = try? FileHandle(forReadingFrom: url) else { continue }
            let head = (try? handle.read(upToCount: Int(min(size, inspectLimit)))) ?? Data()
            try? handle.close()

            let eicar = ["X5O!P%@AP[4\\PZX54(P^)7CC)7}$", "EICAR-STANDARD-ANTIVIRUS-TEST-FILE!", "$H+H*"].joined()
            if let text = String(data: head, encoding: .utf8), text.contains(eicar) {
                findings.append(fileFinding(url: url, key: "file.eicar.\(url.path)", title: "Harmless antivirus test signature detected", severity: .critical, evidence: ["EICAR test signature matched in bounded read", "No file content was persisted", "SHA-256: \(sha256(data: head))"], rationale: "This is the industry-standard harmless EICAR test file used to verify scanner plumbing. It is not live malware.", source: "Deterministic EICAR test rule"))
                continue
            }

            if let text = String(data: head, encoding: .utf8).map({ $0.lowercased() }) {
                let scriptExtensions = ["sh", "command", "zsh", "bash", "scpt", "applescript", "py", "js", "rb", "pl"]
                let scriptCandidate = scriptExtensions.contains(ext) || text.hasPrefix("#!")
                if scriptCandidate {
                    let downloadPipe = (text.contains("curl ") || text.contains("wget ")) && (text.contains("| sh") || text.contains("| bash") || text.contains("|sh") || text.contains("|bash"))
                let encodedExecution = (text.contains("base64") && (text.contains("eval") || text.contains("| sh") || text.contains("| bash")))
                let launchFromTemp = text.contains("launchctl") && (text.contains("/tmp/") || text.contains("/private/tmp/"))
                let appleScriptShell = text.contains("do shell script") && (text.contains("curl") || text.contains("wget"))
                if downloadPipe || encodedExecution || launchFromTemp || appleScriptShell {
                    let rule = downloadPipe ? "download-to-shell pipeline" : encodedExecution ? "encoded execution" : launchFromTemp ? "temporary-path persistence" : "AppleScript shell download"
                    findings.append(fileFinding(url: url, key: "file.script-v2.\(url.path)", title: "Suspicious executable-script pattern", severity: .high, evidence: ["Rule: \(rule)", "Bounded text inspection only", "SHA-256: \(sha256(data: head))"], rationale: "The script contains a high-risk execution pattern. It may be legitimate and requires review.", source: "Deterministic script heuristic v2"))
                    continue
                }
                    let executableScript = (ext == "sh" || ext == "command" || ext == "py" || ext == "js") && (text.hasPrefix("#!") || ext == "command")
                    if executableScript && fm.isExecutableFile(atPath: url.path) {
                        findings.append(fileFinding(url: url, key: "file.executable-script.\(url.path)", title: "Executable script requires review", severity: .medium, evidence: ["Executable bit set", "Shebang or command-script extension observed", "SHA-256: \(sha256(data: head))"], rationale: "Executable scripts are common for developers but should be reviewed before trust.", source: "Deterministic file heuristic"))
                    }
                }
            }

            if isMachO(head), signatureChecks < 200 {
                signatureChecks += 1
                let codesign = LocalCommand.run("/usr/bin/codesign", ["--verify", "--strict", url.path])
                if codesign.exitCode != 0 {
                    let downloaded = url.path.contains("/Downloads/")
                    findings.append(fileFinding(url: url, key: "file.unsigned.\(url.path)", title: "Mach-O executable has no valid strict code signature", severity: downloaded ? .high : .medium, evidence: ["codesign failed with exit \(codesign.exitCode)", "SHA-256: \(sha256(data: head))"], rationale: "Unsigned or invalidly signed executables should be reviewed. Ad-hoc development binaries can trigger this rule.", source: "Apple codesign"))
                    continue
                }
                let gatekeeper = LocalCommand.run("/usr/sbin/spctl", ["--assess", "--type", "execute", "--verbose=2", url.path])
                if gatekeeper.exitCode != 0 && url.path.contains("/Downloads/") {
                    findings.append(fileFinding(url: url, key: "file.gatekeeper.\(url.path)", title: "Downloaded executable did not pass Gatekeeper assessment", severity: .medium, evidence: ["spctl exit \(gatekeeper.exitCode)", "Notarization/assessment is not proven", "SHA-256: \(sha256(data: head))"], rationale: "Gatekeeper rejection is not proof of malware, but notarization and source trust are unverified.", source: "Apple Gatekeeper"))
                }
            }
        }

        let previous = FileSnapshot.load(from: snapshotURL)
        let current = FileSnapshot(observedAt: Date(), files: snapshot)
        if let previous {
            let old = previous.files
            let deleted = old.keys.filter { snapshot[$0] == nil }.count
            let modified = snapshot.reduce(0) { partial, entry in
                guard let oldEntry = old[entry.key] else { return partial }
                return partial + ((oldEntry.size != entry.value.size || abs(oldEntry.modifiedAt.timeIntervalSince(entry.value.modifiedAt)) > 2) ? 1 : 0)
            }
            if deleted + modified >= 50 {
                findings.append(ProtectionFinding(
                    id: UUID(), dedupeKey: "file.burst.\(root.path)", createdAt: Date(), lastObservedAt: Date(), occurrences: 1,
                    title: "Ransomware-like file change burst requires review", severity: .high,
                    source: "bounded snapshot comparison", resource: root.path,
                    evidence: ["Deleted: \(deleted)", "Modified: \(modified)", "Files in current snapshot: \(snapshot.count)"],
                    rationale: "A large burst of file changes can indicate bulk encryption, deletion or legitimate bulk work. It is heuristic evidence, not proof of ransomware.",
                    confidence: "Medium", reviewStatus: .open, canQuarantine: false
                ))
            }
        } else {
            warnings.append("First scan for this root created a baseline; ransomware-style change comparison begins on the next scan.")
        }
        FileSnapshot.save(current, to: snapshotURL)
        if !hasMaintainedEngine() {
            warnings.append("No maintained third-party malware engine (ClamAV or YARA) was found. Deterministic heuristics and Apple signing assessment ran; this is not antivirus-equivalent.")
        }
        return ProtectionScanReport(
            id: UUID(), rootPath: root.path, startedAt: started, completedAt: Date(),
            filesInspected: inspected, bytesInspected: bytes, findings: findings, warnings: warnings,
            engine: "Deterministic local scanner + Apple signing assessment", cancelled: false
        )
    }

    static func capabilities(auditVerified: Bool, scanVerified: Bool, quarantineVerified: Bool, scheduledVerified: Bool, scheduledEnabled: Bool = false, modelVerified: Bool = false) -> [ProtectionCapability] {
        let maintained = hasMaintainedEngine()
        return [
            ProtectionCapability(id: "posture", name: "Security configuration posture", layer: "Telemetry", status: auditVerified ? .verified : .implementedUnverified, evidence: "FileVault, SIP, Gatekeeper, firewall, XProtect version and Time Machine state are read without changing settings.", limitations: "Observed state can drift and is not continuous. TCC-protected state may be unavailable."),
            ProtectionCapability(id: "processes", name: "Process activity inventory", layer: "Telemetry", status: auditVerified ? .verified : .implementedUnverified, evidence: "Bounded ps inventory feeds deterministic path and resource heuristics.", limitations: "Cannot establish full command history, parent intent or kernel-level activity."),
            ProtectionCapability(id: "connections", name: "Established TCP connection inventory", layer: "Telemetry", status: auditVerified ? .verified : .implementedUnverified, evidence: "Bounded lsof ESTABLISHED inventory is correlated to observed process PIDs.", limitations: "Moment-in-time only; no packet inspection, DNS history or live blocking."),
            ProtectionCapability(id: "persistence", name: "Launch agent, daemon and login-item review", layer: "Telemetry", status: auditVerified ? .verified : .implementedUnverified, evidence: "LaunchAgents/Daemons plists are parsed without execution; high-risk program paths and download pipelines are flagged.", limitations: "Background task records and privileged locations may be partially unreadable."),
            ProtectionCapability(id: "scan", name: "On-demand file and executable scanning", layer: "Detection", status: scanVerified ? .verified : .implementedUnverified, evidence: "Bounded recursive reads, deterministic script heuristics, EICAR plumbing test, Apple codesign and Gatekeeper assessment.", limitations: "No maintained third-party malware engine is installed; this is not antivirus equivalence."),
            ProtectionCapability(id: "downloads", name: "Downloads scan", layer: "Detection", status: scanVerified ? .verified : .implementedUnverified, evidence: "User-initiated scan targets Downloads with file limits and no execution.", limitations: "Folder permission may be denied; scheduled coverage applies only while Oracle is running."),
            ProtectionCapability(id: "ransomware", name: "Ransomware-like file-change comparison", layer: "Detection", status: scanVerified ? .verified : .implementedUnverified, evidence: "Bounded metadata snapshots compare additions, modifications and deletions between scans.", limitations: "Snapshot comparisons are not real-time FSEvents protection and can produce false positives during bulk legitimate work."),
            ProtectionCapability(id: "scheduled", name: "In-app scheduled scan", layer: "Policy", status: scheduledVerified ? .verified : .implementedUnverified, evidence: scheduledVerified ? (scheduledEnabled ? "A scheduled scan completed on this build; the schedule is currently enabled." : "A scheduled scan completed on this build; the schedule is currently disabled.") : "Interval preference and next-run scheduling are local to Oracle while it is running.", limitations: "Does not run while Oracle is closed and is not a privileged background service."),
            ProtectionCapability(id: "engine", name: "Maintained malware engine and signed rule feed", layer: "Detection", status: maintained ? .implementedUnverified : .missing, evidence: maintained ? "A local engine path was detected but has not been provenance/license/update verified." : "No ClamAV or YARA executable was found. No signatures or rules were downloaded.", limitations: "Installing or updating a third-party engine requires explicit owner approval and provenance/license review."),
            ProtectionCapability(id: "endpoint-security", name: "Endpoint Security event monitoring", layer: "Telemetry", status: .blocked, evidence: "eslogger exists, but Endpoint Security requires Apple-granted entitlement and privileged authorization.", limitations: "Not requested or installed. No process exec, file event or kernel telemetry is claimed."),
            ProtectionCapability(id: "network-extension", name: "Live connection filtering and blocking", layer: "Response", status: .blocked, evidence: "macOS Network Extension requires an Apple-authorized system extension entitlement and user approval.", limitations: "No live blocking, firewall rule mutation or traffic interception is implemented."),
            ProtectionCapability(id: "quarantine", name: "Reversible quarantine and restore", layer: "Response", status: quarantineVerified ? .verified : .implementedUnverified, evidence: "Owner-confirmed move preserves original metadata and SHA-256; restore verifies the destination is absent.", limitations: "No automatic deletion. Files can still be run before quarantine is approved."),
            ProtectionCapability(id: "model", name: "Local model finding explanation", layer: "Intelligence", status: modelVerified ? .verified : .implementedUnverified, evidence: "Explicitly attached, bounded and redacted finding summaries are sent only to loopback Ollama.", limitations: "Model interpretation is not evidence and has no execution authority."),
            ProtectionCapability(id: "xprotect", name: "Apple XProtect background protection", layer: "System", status: .systemManaged, evidence: "XProtect bundle and xprotectd are managed by macOS; current bundle version is observed in posture.", limitations: "No public app API is used. Oracle does not claim it can invoke a full XProtect scan."),
            ProtectionCapability(id: "camera", name: "Opt-in local camera event capture", layer: "Telemetry", status: .blocked, evidence: "Exact activation command plus macOS camera permission are required; current permission is not requested and security mode is disarmed.", limitations: "Capture was not activated in this QA pass. Locked-screen and failed-password triggers are not claimed."),
            ProtectionCapability(id: "remote", name: "Remote camera viewing", layer: "Response", status: .missing, evidence: "No remote stream or network camera endpoint is implemented.", limitations: "Any future remote viewing would require explicit session approval, strong authentication, encryption, revocation and access logging.")
        ]
    }

    static func hasMaintainedEngine() -> Bool {
        maintainedEnginePaths.contains { FileManager.default.isExecutableFile(atPath: $0) }
    }

    private static func normalized(_ value: String, fallback: String) -> String {
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.isEmpty ? fallback : trimmed
    }

    private static func fileFinding(url: URL, key: String, title: String, severity: ProtectionSeverity, evidence: [String], rationale: String, source: String) -> ProtectionFinding {
        ProtectionFinding(
            id: UUID(), dedupeKey: key, createdAt: Date(), lastObservedAt: Date(), occurrences: 1,
            title: title, severity: severity, source: source, resource: url.path,
            evidence: evidence, rationale: rationale, confidence: "Medium",
            reviewStatus: .open, canQuarantine: true
        )
    }

    private static func isMachO(_ data: Data) -> Bool {
        guard data.count >= 4 else { return false }
        let bytes = [UInt8](data.prefix(4))
        let magic = UInt32(bytes[0]) << 24 | UInt32(bytes[1]) << 16 | UInt32(bytes[2]) << 8 | UInt32(bytes[3])
        return magic == 0xfeedfacf || magic == 0xcffaedfe || magic == 0xcafebabe || magic == 0xbebafeca
    }

    static func sha256(data: Data) -> String {
        SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
    }
}

private struct FileSnapshotEntry: Codable, Hashable {
    let size: UInt64
    let modifiedAt: Date
}

private struct FileSnapshot: Codable {
    let observedAt: Date
    let files: [String: FileSnapshotEntry]

    static func load(from url: URL) -> FileSnapshot? {
        guard let data = try? Data(contentsOf: url) else { return nil }
        return try? JSONDecoder().decode(FileSnapshot.self, from: data)
    }

    static func save(_ snapshot: FileSnapshot, to url: URL) {
        try? FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
        guard let data = try? JSONEncoder().encode(snapshot) else { return }
        try? data.write(to: url, options: .atomic)
        try? FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: url.path)
    }
}
