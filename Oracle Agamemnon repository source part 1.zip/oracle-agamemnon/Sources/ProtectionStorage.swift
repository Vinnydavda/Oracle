import CryptoKit
import Foundation

final class ProtectionStorage {
    let baseURL: URL

    init(baseURL: URL) {
        self.baseURL = baseURL
    }

    private var securityDirectory: URL { baseURL.appendingPathComponent("security", isDirectory: true) }
    private var findingsURL: URL { securityDirectory.appendingPathComponent("findings.json") }
    private var eventsURL: URL { securityDirectory.appendingPathComponent("events.jsonl") }
    private var quarantineDirectory: URL { securityDirectory.appendingPathComponent("Quarantine", isDirectory: true) }
    func scanSnapshotURL(for root: URL) -> URL {
        let digest = SHA256.hash(data: Data(root.standardizedFileURL.path.utf8)).map { String(format: "%02x", $0) }.joined()
        return securityDirectory.appendingPathComponent("file-snapshot-\(digest.prefix(16)).json")
    }

    func ensureDirectories() {
        try? FileManager.default.createDirectory(at: quarantineDirectory, withIntermediateDirectories: true)
        try? FileManager.default.setAttributes([.posixPermissions: 0o700], ofItemAtPath: securityDirectory.path)
        try? FileManager.default.setAttributes([.posixPermissions: 0o700], ofItemAtPath: quarantineDirectory.path)
    }

    func loadFindings() -> [ProtectionFinding] {
        guard let data = try? Data(contentsOf: findingsURL) else { return [] }
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return (try? decoder.decode([ProtectionFinding].self, from: data)) ?? []
    }

    func saveFindings(_ findings: [ProtectionFinding]) throws {
        ensureDirectories()
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        let data = try encoder.encode(findings)
        try data.write(to: findingsURL, options: .atomic)
        try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: findingsURL.path)
    }

    func append(_ event: ProtectionEvent) throws {
        ensureDirectories()
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        let data = try encoder.encode(event) + Data("\n".utf8)
        if !FileManager.default.fileExists(atPath: eventsURL.path) {
            FileManager.default.createFile(atPath: eventsURL.path, contents: nil, attributes: [.posixPermissions: 0o600])
        }
        let handle = try FileHandle(forWritingTo: eventsURL)
        defer { try? handle.close() }
        try handle.seekToEnd()
        try handle.write(contentsOf: data)
    }

    func loadEvents(limit: Int = 2_000) -> [ProtectionEvent] {
        guard let text = try? String(contentsOf: eventsURL, encoding: .utf8) else { return [] }
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return text.split(separator: "\n").suffix(limit).compactMap { line in
            try? decoder.decode(ProtectionEvent.self, from: Data(line.utf8))
        }.sorted { $0.observedAt > $1.observedAt }
    }

    func listQuarantine() -> [QuarantineRecord] {
        ensureDirectories()
        guard let directories = try? FileManager.default.contentsOfDirectory(at: quarantineDirectory, includingPropertiesForKeys: nil, options: [.skipsHiddenFiles]) else { return [] }
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return directories.compactMap { directory -> QuarantineRecord? in
            let metadata = directory.appendingPathComponent("metadata.json")
            guard let data = try? Data(contentsOf: metadata) else { return nil }
            return try? decoder.decode(QuarantineRecord.self, from: data)
        }.sorted { $0.quarantinedAt > $1.quarantinedAt }
    }

    func quarantine(fileURL: URL, finding: ProtectionFinding, now: Date = Date()) throws -> QuarantineRecord {
        ensureDirectories()
        let source = fileURL.standardizedFileURL.resolvingSymlinksInPath()
        guard FileManager.default.fileExists(atPath: source.path) else {
            throw NSError(domain: "OracleQuarantine", code: 1, userInfo: [NSLocalizedDescriptionKey: "The file no longer exists."])
        }
        let values = try source.resourceValues(forKeys: [.fileSizeKey, .contentModificationDateKey])
        let id = UUID()
        let itemDirectory = quarantineDirectory.appendingPathComponent(id.uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: itemDirectory, withIntermediateDirectories: false)
        try FileManager.default.setAttributes([.posixPermissions: 0o700], ofItemAtPath: itemDirectory.path)
        let payload = itemDirectory.appendingPathComponent("payload-\(source.lastPathComponent)")
        let digest = try Self.sha256File(source)
        try FileManager.default.moveItem(at: source, to: payload)
        try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: payload.path)
        let record = QuarantineRecord(
            id: id, originalPath: source.path, payloadPath: payload.path,
            sha256: digest, sizeBytes: UInt64(values.fileSize ?? 0),
            modifiedAt: values.contentModificationDate, quarantinedAt: now,
            findingTitle: finding.title, dedupeKey: finding.dedupeKey, restoredAt: nil
        )
        try Self.save(record, to: itemDirectory.appendingPathComponent("metadata.json"))
        return record
    }

    func restore(_ record: QuarantineRecord, now: Date = Date()) throws -> QuarantineRecord {
        let payload = URL(fileURLWithPath: record.payloadPath)
        let destination = URL(fileURLWithPath: record.originalPath)
        guard FileManager.default.fileExists(atPath: payload.path) else {
            throw NSError(domain: "OracleQuarantine", code: 2, userInfo: [NSLocalizedDescriptionKey: "The quarantined payload is missing."])
        }
        guard !FileManager.default.fileExists(atPath: destination.path) else {
            throw NSError(domain: "OracleQuarantine", code: 3, userInfo: [NSLocalizedDescriptionKey: "Restore stopped because a file already exists at the original path."])
        }
        let currentDigest = try Self.sha256File(payload)
        guard currentDigest == record.sha256 else {
            throw NSError(domain: "OracleQuarantine", code: 4, userInfo: [NSLocalizedDescriptionKey: "Restore stopped because the quarantined payload hash changed."])
        }
        try FileManager.default.createDirectory(at: destination.deletingLastPathComponent(), withIntermediateDirectories: true)
        try FileManager.default.moveItem(at: payload, to: destination)
        var restored = record
        restored.restoredAt = now
        try Self.save(restored, to: URL(fileURLWithPath: record.payloadPath).deletingLastPathComponent().appendingPathComponent("metadata.json"))
        return restored
    }

    private static func save(_ record: QuarantineRecord, to url: URL) throws {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        let data = try encoder.encode(record)
        try data.write(to: url, options: .atomic)
        try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: url.path)
    }

    static func sha256File(_ url: URL) throws -> String {
        let handle = try FileHandle(forReadingFrom: url)
        defer { try? handle.close() }
        var hasher = SHA256()
        while autoreleasepool(invoking: {
            let chunk = try? handle.read(upToCount: 1_048_576)
            if let chunk, !chunk.isEmpty { hasher.update(data: chunk); return true }
            return false
        }) {}
        return hasher.finalize().map { String(format: "%02x", $0) }.joined()
    }
}
