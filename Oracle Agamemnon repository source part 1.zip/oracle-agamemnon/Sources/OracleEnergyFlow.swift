import Foundation

/// Timing for a light pulse along measured, deforming-body channel paths.
/// Rendering and the final reference-matched channel geometry are separate.
struct OracleEnergyPath: Equatable {
    let name: String
    let points: [SIMD3<Double>]
    let delaySeconds: Double
    let strength: Double

    init?(name: String, points: [SIMD3<Double>], delaySeconds: Double = 0, strength: Double = 1) {
        guard points.count >= 2,
              points.allSatisfy({ $0.x.isFinite && $0.y.isFinite && $0.z.isFinite }),
              delaySeconds.isFinite, delaySeconds >= 0,
              strength.isFinite, (0...1).contains(strength) else { return nil }
        self.name = name
        self.points = points
        self.delaySeconds = delaySeconds
        self.strength = strength
    }

    var distances: [Double] {
        var result = [0.0]
        for index in 1..<points.count {
            let delta = points[index] - points[index - 1]
            let length = sqrt(delta.x * delta.x + delta.y * delta.y + delta.z * delta.z)
            result.append(result[index - 1] + length)
        }
        return result
    }
}

struct OracleEnergySettings: Equatable {
    var intervalSeconds = 2.8
    var speedMetresPerSecond = 0.82
    var leadingMetres = 0.07
    var trailingMetres = 0.22
    var quietGlow = 0.12
    var pulseGain = 0.68

    var isValid: Bool {
        let values = [intervalSeconds, speedMetresPerSecond, leadingMetres,
                      trailingMetres, quietGlow, pulseGain]
        return values.allSatisfy(\.isFinite) &&
            intervalSeconds >= 0.5 && speedMetresPerSecond > 0 &&
            leadingMetres > 0 && trailingMetres > 0 &&
            (0...1).contains(quietGlow) && (0...1).contains(pulseGain)
    }
}

enum OracleEnergyFlow {
    /// A moving front with a short lead and longer decay. The result is a
    /// bounded intensity value, not a whole-body brightness oscillator.
    static func intensity(
        path: OracleEnergyPath,
        distanceMetres: Double,
        timeSeconds: Double,
        settings: OracleEnergySettings = .init(),
        reduceMotion: Bool = false
    ) -> Double {
        guard settings.isValid, distanceMetres.isFinite, distanceMetres >= 0,
              timeSeconds.isFinite else { return 0 }
        let baseline = settings.quietGlow
        guard !reduceMotion else { return baseline }
        let phase = max(0, timeSeconds - path.delaySeconds)
            .truncatingRemainder(dividingBy: settings.intervalSeconds)
        let front = phase * settings.speedMetresPerSecond
        let behind = front - distanceMetres
        let pulse: Double
        if behind < -settings.leadingMetres {
            pulse = 0
        } else if behind < 0 {
            let advance = 1 + behind / settings.leadingMetres
            pulse = advance * advance * (3 - 2 * advance)
        } else {
            pulse = exp(-behind / settings.trailingMetres)
        }
        return min(1, baseline + settings.pulseGain * path.strength * pulse)
    }

    static func samples(
        path: OracleEnergyPath,
        timeSeconds: Double,
        settings: OracleEnergySettings = .init(),
        reduceMotion: Bool = false
    ) -> [Double] {
        path.distances.map {
            intensity(path: path, distanceMetres: $0, timeSeconds: timeSeconds,
                      settings: settings, reduceMotion: reduceMotion)
        }
    }
}
