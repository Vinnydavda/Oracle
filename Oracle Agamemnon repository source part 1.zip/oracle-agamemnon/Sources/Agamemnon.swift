import AppKit


import SwiftUI
import UniformTypeIdentifiers

import AVFoundation
import CoreImage
import CoreVideo
import CryptoKit
import Foundation
import IOKit.pwr_mgt
import Vision

// Agamemnon: local-only security workspace. Camera authorization is requested only
// for the explicit security-mode flow; microphone authorization is requested only
// when the owner presses Oracle's on-device dictation control.
final class Agamemnon: NSObject, NSApplicationDelegate, AVCaptureVideoDataOutputSampleBufferDelegate, AVCaptureFileOutputRecordingDelegate, NSWindowDelegate {
    private let base = URL(fileURLWithPath: NSHomeDirectory()).appendingPathComponent("Documents/ORACLE/Agamemnon")
    private var evidence: URL { base.appendingPathComponent("Evidence") }
    private var stateURL: URL { base.appendingPathComponent("state.json") }
    private var stopURL: URL { base.appendingPathComponent("control/stop") }
    private let session = AVCaptureSession()
    private let video = AVCaptureVideoDataOutput()
    private let movie = AVCaptureMovieFileOutput()
    private let captureQueue = DispatchQueue(label: "oracle.agamemnon.frames")
    private let ci = CIContext(options: [.useSoftwareRenderer: false])
    private var statusItem: NSStatusItem?
    private var workspaceStore: OracleWorkspaceStore?
    private var window: NSWindow?
    private var sample: [UInt8] = []
    private var lastCheck = Date.distantPast
    private var lastMotion = Date.distantPast
    private var lastEvent = Date.distantPast
    private var movieStart = Date.distantPast
    private var recording = false
    private var clipFinishing = false
    private var assertionID: IOPMAssertionID = 0
    private var stopping = false
    private var permissionGranted = false
    private var currentVideoPath: URL?
    private var currentCamera = ""
    private var motionCount = 0
    private let threshold = 0.045 // fraction of sampled pixels changed substantially
    private let clipSeconds = 12.0
    private let maxClipSeconds = 75.0

    func applicationDidFinishLaunching(_ notification: Notification) {
        try? FileManager.default.createDirectory(at: evidence, withIntermediateDirectories: true)
        try? FileManager.default.createDirectory(at: base.appendingPathComponent("control"), withIntermediateDirectories: true)
        if Array(ProcessInfo.processInfo.arguments.dropFirst()) == ["--check-camera-permission"] {
            let result: String
            switch AVCaptureDevice.authorizationStatus(for: .video) {
            case .authorized: result = "AUTHORIZED"
            case .denied: result = "DENIED"
            case .restricted: result = "RESTRICTED"
            case .notDetermined: result = "NOT_REQUESTED"
            @unknown default: result = "UNKNOWN"
            }
            try? result.write(to: base.appendingPathComponent("camera-permission-status.txt"), atomically: true, encoding: .utf8)
            writeState("DISARMED", "Camera permission: " + result)
            NSApp.terminate(nil)
            return
        }
        try? FileManager.default.removeItem(at: stopURL)
        let menu = NSMenu()
        menu.addItem(NSMenuItem(title: "Agamemnon — starting", action: nil, keyEquivalent: ""))
        menu.addItem(NSMenuItem(title: "Open Oracle Workspace", action: #selector(openWorkspace), keyEquivalent: ""))
        menu.addItem(NSMenuItem(title: "Open Evidence Folder", action: #selector(openEvidence), keyEquivalent: ""))
        menu.addItem(NSMenuItem(title: "Stop Security Mode", action: #selector(stopClicked), keyEquivalent: ""))
        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        statusItem?.button?.title = ""
        statusItem?.button?.image = NSImage(contentsOfFile: Bundle.main.path(forResource: self.statusImageResource(for: "STARTING"), ofType: "png") ?? "")
        statusItem?.button?.image?.size = NSSize(width: 20, height: 20)
        statusItem?.button?.image?.isTemplate = false
        statusItem?.button?.image?.accessibilityDescription = "Oracle Agamemnon — starting"
        statusItem?.button?.toolTip = "Oracle Agamemnon — starting"
        statusItem?.menu = menu
        let store = OracleWorkspaceStore(baseURL: base)
        workspaceStore = store
        let window = NSWindow(contentRect: NSRect(x: 120, y: 120, width: 1200, height: 780), styleMask: [.titled, .closable, .miniaturizable, .resizable], backing: .buffered, defer: false)
        window.title = "Oracle Agamemnon Protocol Overwatch"
        window.titleVisibility = .hidden
        window.titlebarAppearsTransparent = true
        window.styleMask.insert(.fullSizeContentView)
        window.isOpaque = false
        window.backgroundColor = .clear
        window.minSize = NSSize(width: 980, height: 620)
        window.setFrameAutosaveName("OracleAgamemnonWorkspaceWindow")
        window.contentView = NSHostingView(rootView: WorkspaceView(store: store))
        window.delegate = self
        store.bindPresentationWindow(window)
        window.makeKeyAndOrderFront(nil)
        self.window = window
        menu.items[1].target = self
        menu.items[2].target = self
        menu.items[3].target = self
        if Array(ProcessInfo.processInfo.arguments.dropFirst()) == ["--setup-camera-permission"] {
            writeState("DISARMED", "Permission setup only — no recording or monitoring")
            NSApp.activate(ignoringOtherApps: true)
            let status = AVCaptureDevice.authorizationStatus(for: .video)
            switch status {
            case .notDetermined:
                AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
                    DispatchQueue.main.async {
                        self?.writeState("DISARMED", granted ? "Camera permission granted; security mode still OFF" : "Camera permission declined; security mode still OFF")
                        let notice = NSAlert()
                        notice.messageText = granted ? "AGAMEMNON camera permission granted" : "AGAMEMNON camera permission declined"
                        notice.informativeText = "Setup complete. Security mode remains disarmed. The camera was not opened or used."
                        notice.runModal()
                        NSApp.terminate(nil)
                    }
                }
            case .authorized:
                writeState("DISARMED", "Camera permission already granted; monitoring OFF")
                let notice = NSAlert()
                notice.messageText = "Camera permission already granted"
                notice.informativeText = "Security mode remains disarmed."
                notice.runModal()
                NSApp.terminate(nil)
            default:
                writeState("DISARMED", "Permission blocked; check macOS Privacy & Security > Camera")
                let notice = NSAlert()
                notice.messageText = "Camera permission not available"
                notice.informativeText = "Open macOS Privacy & Security > Camera and enable Oracle Agamemnon Security. Security mode is disarmed."
                notice.runModal()
                NSApp.terminate(nil)
            }
            return
        }
        writeState("STARTING", "Checking camera permission")
        guard Array(ProcessInfo.processInfo.arguments.dropFirst()) == ["--arm", "Oracle, activate security mode Agamemnon"] else {
            writeState("DISARMED", "Exact activation command not supplied")
            return
        }
        Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in self?.checkStop() }
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            permissionGranted = true
            configure()
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
                DispatchQueue.main.async {
                    guard let self = self else { return }
                    self.permissionGranted = granted
                    if granted { self.configure() }
                    else { self.writeState("PERMISSION_REQUIRED", "Allow camera access in macOS Privacy & Security > Camera") }
                }
            }
        default:
            writeState("PERMISSION_REQUIRED", "Camera permission denied/restricted; macOS Settings > Privacy & Security > Camera")
        }
    }

    func windowDidEnterFullScreen(_ notification: Notification) {
        workspaceStore?.nativeFullScreenDidChange(true)
    }

    func windowDidExitFullScreen(_ notification: Notification) {
        workspaceStore?.nativeFullScreenDidChange(false)
    }

    private func statusImageResource(for state: String) -> String {
        "AppIcon"
    }

    private func writeState(_ state: String, _ note: String) {
        let obj: [String: Any] = [
            "state": state, "note": note, "camera": currentCamera,
            "at": ISO8601DateFormatter().string(from: Date()),
            "pid": ProcessInfo.processInfo.processIdentifier,
            "events_this_session": motionCount,
            "camera_permission": permissionLabel(),
            "audio_recording": false,
            "off_device_streaming": false
        ]
        if let data = try? JSONSerialization.data(withJSONObject: obj, options: [.prettyPrinted, .sortedKeys]) {
            try? data.write(to: stateURL, options: .atomic)
            try? FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: stateURL.path)
        }
        DispatchQueue.main.async {
            self.statusItem?.menu?.items.first?.title = "Agamemnon — \(state)"
            self.statusItem?.button?.image = NSImage(contentsOfFile: Bundle.main.path(forResource: self.statusImageResource(for: state), ofType: "png") ?? "")
            self.statusItem?.button?.image?.size = NSSize(width: 20, height: 20)
            self.statusItem?.button?.image?.isTemplate = false
            self.statusItem?.button?.image?.accessibilityDescription = "Oracle Agamemnon — \(state)"
            self.statusItem?.button?.toolTip = "Oracle Agamemnon — \(state)"
        }
    }

    private func permissionLabel() -> String {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized: return "AUTHORIZED"
        case .denied: return "DENIED"
        case .restricted: return "RESTRICTED"
        case .notDetermined: return "NOT_REQUESTED"
        @unknown default: return "UNKNOWN"
        }
    }

    private func logEvent(_ event: String, details: [String: Any] = [:]) {
        var payload = details
        payload["type"] = event
        payload["at"] = ISO8601DateFormatter().string(from: Date())
        if let data = try? JSONSerialization.data(withJSONObject: payload),
           let line = String(data: data, encoding: .utf8),
           let bytes = (line + "\n").data(using: .utf8) {
            let log = base.appendingPathComponent("events.jsonl")
            if !FileManager.default.fileExists(atPath: log.path) {
                FileManager.default.createFile(atPath: log.path, contents: nil)
            }
            if let handle = try? FileHandle(forWritingTo: log) {
                handle.seekToEndOfFile()
                handle.write(bytes)
                try? handle.close()
            }
        }
    }

    private func configure() {
        session.beginConfiguration()
        session.sessionPreset = .high
        let cams = AVCaptureDevice.devices(for: .video)
        guard let camera = cams.first(where: { $0.localizedName.localizedCaseInsensitiveContains("MacBook") }) ?? cams.first else {
            session.commitConfiguration()
            writeState("NO_CAMERA", "No built-in or external video camera available")
            return
        }
        currentCamera = camera.localizedName
        do {
            let input = try AVCaptureDeviceInput(device: camera)
            guard session.canAddInput(input) else { throw NSError(domain:"Agamemnon",code:1) }
            session.addInput(input)
            video.alwaysDiscardsLateVideoFrames = true
            video.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]
            video.setSampleBufferDelegate(self, queue: captureQueue)
            if session.canAddOutput(video) { session.addOutput(video) }
            else { throw NSError(domain:"Agamemnon",code:2) }
            if session.canAddOutput(movie) { session.addOutput(movie) }
            else { logEvent("video_clips_unavailable", details: ["reason":"Movie output unsupported"]); }
            session.commitConfiguration()
            DispatchQueue.global(qos: .userInitiated).async {
                self.session.startRunning()
                DispatchQueue.main.async {
                    if self.session.isRunning {
                        self.logEvent("armed", details: ["camera": self.currentCamera])
                        let power = IOPMAssertionCreateWithName(kIOPMAssertionTypePreventUserIdleSystemSleep as CFString, IOPMAssertionLevel(kIOPMAssertionLevelOn), "Agamemnon armed monitoring" as CFString, &self.assertionID)
                        if power != kIOReturnSuccess { self.logEvent("sleep_guard_failed") }
                        self.writeState("ARMED", "Local motion monitoring active")
                    } else { self.writeState("ERROR", "Capture session did not start") }
                }
            }
        } catch {
            session.commitConfiguration()
            writeState("ERROR", "Camera setup: \(error.localizedDescription)")
            logEvent("camera_setup_error", details: ["error":error.localizedDescription])
        }
    }

    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        let now = Date()
        guard now.timeIntervalSince(lastCheck) >= 0.6,
              let pixel = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        lastCheck = now
        CVPixelBufferLockBaseAddress(pixel, .readOnly)
        let width = CVPixelBufferGetWidth(pixel), height = CVPixelBufferGetHeight(pixel)
        let bytesPerRow = CVPixelBufferGetBytesPerRow(pixel)
        guard let basePtr = CVPixelBufferGetBaseAddress(pixel) else {
            CVPixelBufferUnlockBaseAddress(pixel, .readOnly)
            return
        }
        let ptr = basePtr.assumingMemoryBound(to: UInt8.self)
        var current: [UInt8] = []
        let countX = 48, countY = 32
        for y in 0..<countY {
            for x in 0..<countX {
                let yy = min(height-1, (height * (y*2+1)) / (2*countY))
                let xx = min(width-1, (width * (x*2+1)) / (2*countX))
                let i = yy * bytesPerRow + xx*4
                let lum = (Int(ptr[i]) * 11 + Int(ptr[i+1]) * 59 + Int(ptr[i+2]) * 30) / 100
                current.append(UInt8(min(255, lum)))
            }
        }
        CVPixelBufferUnlockBaseAddress(pixel, .readOnly)
        if sample.count == current.count {
            var changed = 0, total = 0
            for i in current.indices {
                let delta = abs(Int(current[i]) - Int(sample[i]))
                if delta > 38 { changed += 1 }
                total += delta
            }
            let ratio = Double(changed) / Double(current.count)
            let average = Double(total) / Double(current.count)
            if ratio > threshold && average < 48 {
                lastMotion = now
                if now.timeIntervalSince(lastEvent) > 12.0 && !stopping {
                    lastEvent = now
                    motionCount += 1
                    saveSnapshot(pixel, ratio: ratio)
                    DispatchQueue.main.async {
                        self.logEvent("motion", details: ["changed_fraction": Double(round(ratio*1000)/1000)])
                        self.writeState("ARMED", "Motion observed — evidence saved")
                        if !self.recording && !self.movie.connections.isEmpty { self.beginClip() }
                    }
                }
            }
        }
        sample = current
        if recording && (now.timeIntervalSince(lastMotion) > clipSeconds || now.timeIntervalSince(movieStart) > maxClipSeconds) {
            DispatchQueue.main.async {
                if self.recording && !self.clipFinishing { self.clipFinishing = true; self.movie.stopRecording() }
            }
        }
    }

    private func dayFolder() -> URL {
        let fmt = DateFormatter()
        fmt.dateFormat = "yyyy-MM-dd"
        let dir = evidence.appendingPathComponent(fmt.string(from: Date()))
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }
    private func stamp() -> String {
        let fmt = DateFormatter()
        fmt.dateFormat = "yyyyMMdd-HHmmss-SSS"
        return fmt.string(from: Date())
    }
    private func saveSnapshot(_ pixel: CVPixelBuffer, ratio: Double) {
        let url = dayFolder().appendingPathComponent("motion-\(stamp()).jpg.enc")
        let picture = CIImage(cvPixelBuffer: pixel)
        let options: [CIImageRepresentationOption: Any] = [:]
        if let data = ci.jpegRepresentation(of: picture, colorSpace: CGColorSpaceCreateDeviceRGB(), options: options) {
            guard let encrypted = try? CameraEvidenceCipher.encrypt(data, key: CameraEvidenceCipher.loadOrCreateKey()) else {
                logEvent("snapshot_encryption_error", details: ["reason":"Keychain or AES-GCM failure"])
                return
            }
            try? encrypted.write(to: url, options: .atomic)
            try? FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: url.path)
            let digest = SHA256.hash(data: encrypted).map { String(format:"%02x", $0) }.joined()
            let humanRequest = VNDetectHumanRectanglesRequest()
            var humanCandidates: Int? = nil
            do {
                try VNImageRequestHandler(ciImage: picture, options: [:]).perform([humanRequest])
                humanCandidates = humanRequest.results?.count ?? 0
            } catch { /* Motion evidence is still retained if Vision cannot classify it. */ }
            let candidates = humanCandidates
            DispatchQueue.main.async {
                var entry: [String: Any] = ["file":url.path, "sha256":digest, "motion_fraction":ratio]
                if let candidates = candidates { entry["human_candidates"] = candidates }
                self.logEvent("snapshot", details: entry)
            }
        }
    }
    private func beginClip() {
        guard !recording && !movie.connections.isEmpty && !stopping else { return }
        clipFinishing = false
        let file = dayFolder().appendingPathComponent("clip-\(stamp()).mov")
        currentVideoPath = file
        recording = true
        movieStart = Date()
        movie.startRecording(to: file, recordingDelegate: self)
    }
    func fileOutput(_ output: AVCaptureFileOutput, didStartRecordingTo fileURL: URL, from connections: [AVCaptureConnection]) {
        logEvent("clip_started", details: ["file":fileURL.path])
    }
    func fileOutput(_ output: AVCaptureFileOutput, didFinishRecordingTo fileURL: URL, from connections: [AVCaptureConnection], error: Error?) {
        recording = false
        clipFinishing = false
        currentVideoPath = nil
        if let error = error {
            logEvent("clip_error", details: ["file":fileURL.path, "error":error.localizedDescription])
        } else {
            let encryptedURL = fileURL.appendingPathExtension("enc")
            if let digest = try? CameraEvidenceCipher.encryptFile(at: fileURL, to: encryptedURL) {
                try? FileManager.default.removeItem(at: fileURL)
                logEvent("clip_saved", details: ["file":encryptedURL.path, "sha256":digest, "encrypted":true])
            } else {
                logEvent("clip_encryption_error", details: ["file":fileURL.path, "reason":"Encrypted copy failed; original staging file retained"])
            }
        }
        if stopping { finishStop() }
    }
    private func checkStop() {
        guard FileManager.default.fileExists(atPath: stopURL.path) else { return }
        try? FileManager.default.removeItem(at: stopURL)
        stopSecurity()
    }
    @objc private func openWorkspace() { presentWorkspace() }
    @objc private func openEvidence() { NSWorkspace.shared.open(evidence) }
    @objc private func stopClicked() { stopSecurity() }
    private func presentWorkspace() {
        guard let window else { return }
        if window.isMiniaturized { window.deminiaturize(nil) }
        window.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
    }
    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool {
        presentWorkspace()
        return true
    }
    private func stopSecurity() {
        guard !stopping else { return }
        stopping = true
        writeState("STOPPING", "Finalizing camera recording")
        logEvent("disarm_requested")
        if recording { if !clipFinishing { clipFinishing = true; movie.stopRecording() } }
        else { finishStop() }
    }
    private func finishStop() {
        if session.isRunning { session.stopRunning() }
        if assertionID != 0 { IOPMAssertionRelease(assertionID); assertionID = 0 }
        logEvent("disarmed")
        writeState("DISARMED", "Security mode stopped")
        NSApp.terminate(nil)
    }
    func applicationWillTerminate(_ notification: Notification) {
        workspaceStore?.persistNow()
        if session.isRunning { session.stopRunning() }
        writeState("DISARMED", "Application stopped")
    }
}
// MARK: - Shared security domain types\
enum Confidence: String, CaseIterable, Codable, Hashable, Identifiable {
    case low, medium, high, unknown
    var id: String { rawValue }
    var label: String { switch self { case .low: return "Low"; case .medium: return "Medium"; case .high: return "High"; case .unknown: return "Unknown" } }
}

enum SecuritySeverity: String, CaseIterable, Codable, Hashable, Identifiable {
    case info, caution, elevated, critical, unknown
    var id: String { rawValue }
}

enum FindingStatus: String, CaseIterable, Codable, Hashable, Identifiable {
    case open, acknowledged, resolved, dismissed, unknown
    var id: String { rawValue }
}

enum ToolRequestStatus: String, CaseIterable, Codable, Hashable, Identifiable {
    case proposed, approved, rejected, executed, failed, expired, unavailable
    var id: String { rawValue }
    var label: String { rawValue.capitalized }
}

enum ProviderAvailability: String, CaseIterable, Codable, Hashable, Identifiable {
    case available, unavailable, unconfigured, checking, unknown
    var id: String { rawValue }
    var label: String { rawValue.capitalized }
}

enum ModelRequestStatus: String, CaseIterable, Codable, Hashable, Identifiable {
    case idle, streaming, done, failed, cancelled, timeout, unavailable
    var id: String { rawValue }
    var label: String { rawValue.capitalized }
}

struct NetworkProtectionStatus: Identifiable, Hashable, Codable {
    let id: UUID
    let kind: String
    let name: String
    let method: String
    let state: String
    let observedAt: Date
    let source: String
    let defaultRouteInterface: String?
    let dnsResolverCount: Int?
    let limitations: [String]
}

struct PermissionState: Identifiable, Hashable, Codable {
    let id: UUID
    let name: String
    let detail: String
    let status: String
    let confidence: Confidence
    let observedAt: Date
}

struct SecurityEvent: Identifiable, Hashable, Codable {
    let id: UUID
    let occurredAt: Date
    let kind: String
    let summary: String
    let source: String
}

struct EvidenceRecord: Identifiable, Hashable, Codable {
    let id: UUID
    let path: String
    let sha256: String
    let observedAt: Date
    let kind: String
}

struct SecurityFinding: Identifiable, Hashable, Codable {
    let id: UUID
    let title: String
    let severity: SecuritySeverity
    let observedAt: Date
    let rationale: String
    let evidence: [String]
    let confidence: Confidence
    let status: FindingStatus
}

struct SecuritySettings: Codable {
    var displayTitle: String = "Oracle Agamemnon Protocol Overwatch"
    var modelProviderID: String = "ollama"
    var modelID: String = "qwen3:4b-instruct"
    var allowModelToolRequests: Bool = false
    var readOnlyToolsOnly: Bool = true
}

struct ConversationMessage: Identifiable, Hashable {
    let id: UUID
    let createdAt: Date
    let role: String
    let text: String
    let state: ModelRequestStatus
    let providerID: String?
    let modelID: String?
}
struct SourceFile {
    let name: String
    let section: String
    let sha256: String
    let summary: String
}

@MainActor
final class OracleWorkspaceStore: ObservableObject {
    @Published var section: String = "Overview"
    @Published var title: String = "Oracle Agamemnon Protocol Overwatch"
    @Published var securityState: String = "DISARMED"
    @Published var cameraState: String = "DISARMED"
    @Published var cameraName: String = "Unknown"
    @Published var permissionState: String = "UNKNOWN"
    @Published var collectorState: String = "READY"
    @Published var networkProtection: [NetworkProtectionStatus] = []
    @Published var permissionStates: [PermissionState] = []
    @Published var findings: [SecurityFinding] = []
    @Published var timeline: [SecurityEvent] = []
    @Published var evidence: [EvidenceRecord] = []
    @Published var messages: [ConversationMessage] = []
    @Published var draft: String = ""
    @Published var chatSessionError: String?
    @Published var settings: SecuritySettings = SecuritySettings()
    @Published var voiceConversationEnabled = false
    @Published var presentationMode: OraclePresentationMode = .workspace
    @Published private(set) var nativeFullScreenActive = false
    @Published private(set) var companionAlwaysOnTop = false
    @Published var motionMode: OracleMotionMode = .idle
    @Published var gestureCue: OracleGestureCue = .none
    @Published var maskExpression: OracleMaskExpression?
    @Published private(set) var modelBehaviorExpression: OracleMaskExpression?
    @Published var show3DCandidate = false
    @Published var transcriptCollapsed = false
    @Published var lastCommandReceipt = "No Qwen in-app tool has run this session."
    @Published var providerState: ProviderAvailability = .unavailable
    @Published var providerDetail: String = "Ollama not available"
    @Published var modelState: ModelRequestStatus = .idle
    @Published var installedModels: [String] = []
    @Published var stateObservedAt: Date?
    @Published var schematicGraph = SchematicGraph(generatedAt: .distantPast, nodes: [], connections: [])
    @Published var memoryBrainGraph = MemoryBrainGraph(generatedAt: .distantPast, nodes: [], edges: [])
    @Published var memoryBrainLoading = false
    @Published var memoryBrainRepresentedNoteCount = 0
    @Published var memoryBrainSkippedNoteCount = 0
    @Published var obsidianIndex = ObsidianVaultIndex.notConfigured()
    @Published var obsidianVaultPath: String?
    @Published var obsidianSelectedNote: ObsidianNote?
    @Published var obsidianPreview: ObsidianNoteContent?
    @Published var obsidianContext: ObsidianNoteContent?
    @Published var obsidianError: String?
    @Published var protectionCapabilities: [ProtectionCapability] = []
    @Published var protectionFindings: [ProtectionFinding] = []
    @Published var protectionEvents: [ProtectionEvent] = []
    @Published var quarantineRecords: [QuarantineRecord] = []
    @Published var protectionPosture: ProtectionPosture?
    @Published var lastScanReport: ProtectionScanReport?
    @Published var protectionBusy = false
    @Published var protectionScanInProgress = false
    @Published var lastProtectionError: String?
    @Published var protectionPreferences = ProtectionPreferences()
    @Published var scheduledScanDetail = "Disabled"
    @Published var securityContext: SecurityPromptContext?
    @Published var cameraRetentionDays = 7
    @Published var expiredCameraEvidenceCount = 0
    @Published var connectedResources: [ConnectedResource] = []
    @Published var mttBridgeMetadata: MTTBridgeMetadata?
    @Published var integrationBusy = false
    @Published var lastIntegrationError: String?

    private(set) var baseURL: URL
    let voiceController: OracleVoiceController
    let dictationController: OracleDictationController
    private let windowPresentation = OracleWindowPresentation()
    private let obsidianVaultDefaultsKey = "app.oracle.agamemnon.security.obsidianVaultPath"
    private let modelSettingsKey = "app.oracle.agamemnon.security.modelSettings"
    private var memoryBuildTask: Task<Void, Never>?
    private var sessionSaveTask: Task<Void, Never>?
    private var protectionTask: Task<Void, Never>?
    private var scanWorkTask: Task<ProtectionScanReport, Never>?
    private var integrationTask: Task<Void, Never>?
    private var sessionWriteBlocked = false
    private var timer: Timer?
    private var activeAssistantMessageID: UUID?
    private var pendingBehaviorProposal: OracleBehaviorProposal?
    private var modelBehaviorTask: Task<Void, Never>?
    private var modelBehaviorGesture: OracleGestureCue?
    private var lastModelGestureAt = Date.distantPast
    private lazy var protectionStorage = ProtectionStorage(baseURL: baseURL)
    private let protectionPreferencesKey = "app.oracle.agamemnon.security.protectionPreferences"
    private let protectionAuditVerifiedKey = "app.oracle.agamemnon.security.protectionAuditVerified"
    private let protectionScanVerifiedKey = "app.oracle.agamemnon.security.protectionScanVerified"
    private let protectionQuarantineVerifiedKey = "app.oracle.agamemnon.security.protectionQuarantineVerified"
    private let protectionScheduledVerifiedKey = "app.oracle.agamemnon.security.protectionScheduledVerified"
    private let protectionModelVerifiedKey = "app.oracle.agamemnon.security.protectionModelVerified"
    private let cameraRetentionDaysKey = "app.oracle.agamemnon.security.cameraRetentionDays"
    private let integrationStateKey = "app.oracle.agamemnon.security.controlCenterIntegration"

    private var chatSessionURL: URL { baseURL.appendingPathComponent("chat-session.json") }

    init(baseURL: URL) {
        self.baseURL = baseURL
        self.voiceController = OracleVoiceController()
        self.dictationController = OracleDictationController()
        self.title = "Oracle Agamemnon Protocol Overwatch"
        protectionStorage.ensureDirectories()
        protectionFindings = protectionStorage.loadFindings()
        migrateProtectionFindings()
        protectionEvents = protectionStorage.loadEvents()
        quarantineRecords = protectionStorage.listQuarantine()
        restoreProtectionPreferences()
        refreshProtectionCapabilities()
        let savedRetention = UserDefaults.standard.integer(forKey: cameraRetentionDaysKey)
        cameraRetentionDays = savedRetention > 0 ? savedRetention : 7
        refreshExpiredCameraEvidenceCount()
        restoreChatSession()
        restoreObsidianVault()
        restoreModelSettings()
        refreshRuntimeState()
        refreshControlCenterInventory()
        startTimer()
        Task { [weak self] in self?.runProtectionAudit() }
    }

    deinit {
        timer?.invalidate()
        requestTask?.cancel()
        memoryBuildTask?.cancel()
        sessionSaveTask?.cancel()
        protectionTask?.cancel()
        scanWorkTask?.cancel()
        integrationTask?.cancel()
        modelBehaviorTask?.cancel()
    }

    func bindPresentationWindow(_ window: NSWindow) {
        windowPresentation.attach(window)
    }

    var isNativeFullScreen: Bool { nativeFullScreenActive }

    func nativeFullScreenDidChange(_ active: Bool) {
        nativeFullScreenActive = active
    }

    func setCompanionAlwaysOnTop(_ enabled: Bool) {
        companionAlwaysOnTop = enabled
        windowPresentation.setAlwaysOnTop(enabled && presentationMode == .compact)
    }

    func toggleNativeFullScreen() {
        windowPresentation.toggleNativeFullScreen()
    }

    func setPresentationMode(_ mode: OraclePresentationMode) {
        guard mode != presentationMode else { return }
        guard windowPresentation.apply(mode, previous: presentationMode) else { return }
        if mode != .workspace { section = "Oracle" }
        presentationMode = mode
        windowPresentation.setAlwaysOnTop(companionAlwaysOnTop && mode == .compact)
    }

    private func startTimer() {
        timer = Timer.scheduledTimer(withTimeInterval: 2.0, repeats: true) { [weak self] _ in
            DispatchQueue.main.async { self?.refreshRuntimeState() }
        }
    }

    func refreshRuntimeState() {
        let stateURL = baseURL.appendingPathComponent("state.json")
        if let data = try? Data(contentsOf: stateURL),
           let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
            securityState = obj["state"] as? String ?? "UNKNOWN"
            cameraName = obj["camera"] as? String ?? "Unknown"
            permissionState = obj["camera_permission"] as? String ?? "UNKNOWN"
            collectorState = obj["note"] as? String ?? "No note"
            cameraState = securityState
            stateObservedAt = (obj["at"] as? String).flatMap { ISO8601DateFormatter().date(from: $0) }
        } else {
            securityState = "DISARMED"
            cameraState = "DISARMED"
            cameraName = "Unknown"
            permissionState = "UNKNOWN"
            collectorState = "No state file"
            stateObservedAt = nil
        }
        networkProtection = scanNetworkProtection()
        permissionStates = scanPermissions()
        timeline = readTimeline()
        evidence = readEvidenceManifest()
        let nextProviderState = probeOllama()
        let providerChanged = nextProviderState != providerState
        if nextProviderState != providerState,
           modelState != .streaming,
           nextProviderState == .available {
            providerDetail = "Local Ollama connected. \(installedModels.count) installed local model\(installedModels.count == 1 ? "" : "s") available."
        } else if nextProviderState == .unavailable, modelState != .streaming {
            providerDetail = "Ollama is offline at 127.0.0.1:11434. Start the local service, then refresh."
        }
        providerState = nextProviderState
        if providerChanged { refreshControlCenterInventory() }
        schematicGraph = buildSchematicGraph()
        maybeRunScheduledProtectionScan()
    }
    private func scanNetworkProtection() -> [NetworkProtectionStatus] {
        let vpnText = shellRead("/usr/sbin/scutil", ["--nc", "list"])
        let routeText = shellRead("/sbin/route", ["-n", "get", "default"])
        let dnsText = shellRead("/usr/sbin/scutil", ["--dns"])
        let defaultInterface = NetworkServiceParser.defaultInterface(from: routeText)
        let dnsResolverCount = NetworkServiceParser.resolverCount(from: dnsText)
        let now = Date()
        return NetworkServiceParser.parse(vpnText).map { service in
            NetworkProtectionStatus(
                id: UUID(),
                kind: "vpn",
                name: service.name,
                method: "scutil --nc",
                state: service.state,
                observedAt: now,
                source: "macOS network extension",
                defaultRouteInterface: defaultInterface,
                dnsResolverCount: dnsResolverCount,
                limitations: ["VPN service state does not prove traffic routes through the tunnel.", "DNS resolver count does not prove leak protection or VPN ownership."]
            )
        }
    }
    private func scanPermissions() -> [PermissionState] {
        let now = Date()
        let map = ["AUTHORIZED": ("Authorized", Confidence.high), "DENIED": ("Denied", Confidence.high), "RESTRICTED": ("Restricted", Confidence.high), "NOT_REQUESTED": ("Not requested", Confidence.medium), "UNKNOWN": ("Unknown", Confidence.unknown)]
        var rows: [PermissionState] = []
        if let data = try? Data(contentsOf: baseURL.appendingPathComponent("camera-permission-status.txt")),
           let raw = String(data: data, encoding: .utf8)?.trimmingCharacters(in: .whitespacesAndNewlines) {
            let pair = map[raw] ?? ("Unknown", Confidence.unknown)
            rows.append(PermissionState(id: UUID(), name: "Camera", detail: pair.0, status: raw, confidence: pair.1, observedAt: now))
        }
        for permission in dictationController.permissionObservations() {
            let confidence: Confidence = permission.confidence == "high" ? .high : .unknown
            rows.append(PermissionState(id: UUID(), name: permission.name, detail: permission.detail, status: permission.status, confidence: confidence, observedAt: now))
        }
        return rows
    }
    private func readTimeline() -> [SecurityEvent] {
        var rows: [SecurityEvent] = []
        let logs = baseURL.appendingPathComponent("events.jsonl")
        guard FileManager.default.fileExists(atPath: logs.path) else { return rows }
        let text = (try? String(contentsOf: logs, encoding: .utf8)) ?? ""
        for line in text.split(separator: "\n") {
            guard let data = line.data(using: .utf8),
                  let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let type = obj["type"] as? String else { continue }
            var summary = type
            if let note = obj["note"] as? String { summary = note }
            rows.append(SecurityEvent(id: UUID(), occurredAt: (obj["at"] as? String).flatMap { ISO8601DateFormatter().date(from: $0) } ?? Date(), kind: type, summary: summary, source: "local-camera"))
        }
        return rows.sorted { $0.occurredAt > $1.occurredAt }
    }
    private func readEvidenceManifest() -> [EvidenceRecord] {
        EvidenceManifestReader.read(root: baseURL.appendingPathComponent("Evidence"), observedAt: Date()).map {
            EvidenceRecord(id: UUID(), path: $0.path, sha256: $0.sha256, observedAt: $0.observedAt, kind: $0.kind)
        }
    }
    private func probeOllama() -> ProviderAvailability {
        guard let data = try? Data(contentsOf: URL(string: "http://127.0.0.1:11434/api/tags")!),
              let tags = try? JSONDecoder().decode(OllamaTags.self, from: data) else {
            installedModels = []
            return .unavailable
        }
        installedModels = tags.models.map(\.name).filter { !$0.lowercased().contains(":cloud") }.sorted()
        return installedModels.isEmpty ? .unconfigured : .available
    }
    private func buildSchematicGraph() -> SchematicGraph {
        let permission = permissionStates.first(where: { $0.name == "Camera" })?.status ?? "UNKNOWN"
        let vpnStates = networkProtection.map { "\($0.name):\($0.state)" }
        let mttFreshness = ControlCenterIntegrationEngine.mttSampleFreshness(lastCapturedAt: mttBridgeMetadata?.lastCapturedAt)
        return SchematicGraphBuilder.build(SchematicBuildInput(
            deviceName: ProcessInfo.processInfo.hostName,
            osVersion: ProcessInfo.processInfo.operatingSystemVersionString,
            securityState: securityState,
            securityObservedAt: stateObservedAt,
            cameraName: cameraName,
            cameraPermission: permission,
            vpnStates: vpnStates,
            ollamaAvailable: providerState == .available,
            installedModels: installedModels,
            selectedModel: settings.modelID,
            evidenceCount: evidence.count,
            observedAt: Date(),
            obsidianVaultName: obsidianVaultURL?.lastPathComponent,
            obsidianNoteCount: obsidianIndex.notes.count,
            obsidianObservedAt: obsidianIndex.vaultURL == nil ? nil : obsidianIndex.scannedAt,
            memoryBrainNodeCount: memoryBrainGraph.nodes.filter { $0.kind == .note }.count,
            protectionFindingCount: protectionFindings.filter { $0.reviewStatus == .open || $0.reviewStatus == .acknowledged }.count,
            maintainedEngineAvailable: ProtectionEngine.hasMaintainedEngine(),
            mttBridgeObserved: mttBridgeMetadata?.lastCapturedAt != nil,
            mttBridgeFresh: mttFreshness == .fresh
        ))
    }

    private var obsidianVaultURL: URL? {
        obsidianVaultPath.map { URL(fileURLWithPath: $0, isDirectory: true) }
    }

    private func restoreObsidianVault() {
        guard let path = UserDefaults.standard.string(forKey: obsidianVaultDefaultsKey), !path.isEmpty else { return }
        obsidianVaultPath = path
        refreshObsidianVault()
    }

    private func restoreModelSettings() {
        guard let data = UserDefaults.standard.data(forKey: modelSettingsKey),
              let saved = try? JSONDecoder().decode(SecuritySettings.self, from: data) else { return }
        settings = saved
        // Earlier builds displayed these fields without implementing tools.
        // Never activate newly implemented tools from an old saved flag.
        settings.allowModelToolRequests = false
        settings.readOnlyToolsOnly = true
    }

    func setModelToolsEnabled(_ enabled: Bool) {
        settings.allowModelToolRequests = enabled
        if !enabled { settings.readOnlyToolsOnly = true }
    }

    func setInAppNavigationEnabled(_ enabled: Bool) {
        guard settings.allowModelToolRequests || !enabled else { return }
        settings.readOnlyToolsOnly = !enabled
    }

    func selectModel(_ model: String) {
        guard installedModels.contains(model), !model.lowercased().contains(":cloud") else { return }
        settings.modelProviderID = "ollama"
        settings.modelID = model
        if let data = try? JSONEncoder().encode(settings) {
            UserDefaults.standard.set(data, forKey: modelSettingsKey)
        }
        providerDetail = "Selected installed local model \(model). Oracle will verify it again before each request."
        refreshControlCenterInventory()
        schematicGraph = buildSchematicGraph()
    }

    func refreshModels() {
        providerState = probeOllama()
        providerDetail = providerState == .available
            ? "Ollama connected. \(installedModels.count) installed local model(s) available."
            : "Ollama is offline at 127.0.0.1:11434. No inference request was made."
        refreshControlCenterInventory()
        schematicGraph = buildSchematicGraph()
    }

    func chooseObsidianVault() {
        let panel = NSOpenPanel()
        panel.title = "Choose Obsidian Vault"
        panel.prompt = "Connect Vault"
        panel.message = "Select the folder containing your Obsidian vault and its .obsidian directory. Oracle will index Markdown notes read-only."
        panel.canChooseDirectories = true
        panel.canChooseFiles = false
        panel.allowsMultipleSelection = false
        panel.canCreateDirectories = false
        if let current = obsidianVaultURL { panel.directoryURL = current.deletingLastPathComponent() }
        guard panel.runModal() == .OK, let url = panel.url else { return }
        setObsidianVault(url)
    }

    func setObsidianVault(_ url: URL) {
        let result = ObsidianVaultReader.scan(vaultURL: url, limit: 500)
        guard result.state != .invalid("Select a folder containing an .obsidian directory.") else {
            obsidianIndex = result
            obsidianError = "The selected folder is not an Obsidian vault."
            return
        }
        obsidianVaultPath = url.path
        UserDefaults.standard.set(url.path, forKey: obsidianVaultDefaultsKey)
        obsidianIndex = result
        obsidianSelectedNote = nil
        obsidianPreview = nil
        obsidianContext = nil
        obsidianError = nil
        refreshMemoryBrain()
        schematicGraph = buildSchematicGraph()
        refreshControlCenterInventory()
    }

    func refreshObsidianVault() {
        guard let obsidianVaultURL else {
            obsidianIndex = .notConfigured()
            obsidianSelectedNote = nil
            obsidianPreview = nil
            obsidianError = nil
            memoryBuildTask?.cancel()
            memoryBrainGraph = MemoryBrainGraph(generatedAt: .distantPast, nodes: [], edges: [])
            memoryBrainLoading = false
            memoryBrainRepresentedNoteCount = 0
            memoryBrainSkippedNoteCount = 0
            schematicGraph = buildSchematicGraph()
            return
        }
        let result = ObsidianVaultReader.scan(vaultURL: obsidianVaultURL, limit: 500)
        obsidianIndex = result
        if !result.notes.contains(where: { $0.relativePath == obsidianSelectedNote?.relativePath }) {
            obsidianSelectedNote = nil
            obsidianPreview = nil
        }
        if case .invalid(let message) = result.state {
            obsidianError = message
        } else if case .error(let message) = result.state {
            obsidianError = message
        } else {
            obsidianError = nil
        }
        refreshMemoryBrain()
        schematicGraph = buildSchematicGraph()
        refreshControlCenterInventory()
    }

    func refreshMemoryBrain() {
        memoryBuildTask?.cancel()
        guard let vaultURL = obsidianVaultURL,
              case .ready = obsidianIndex.state else {
            memoryBrainLoading = false
            memoryBrainRepresentedNoteCount = 0
            memoryBrainSkippedNoteCount = 0
            memoryBrainGraph = MemoryBrainGraph(generatedAt: .distantPast, nodes: [], edges: [])
            return
        }
        let notes = Array(obsidianIndex.notes.prefix(160))
        let indexedTotal = obsidianIndex.notes.count
        memoryBrainLoading = true
        memoryBuildTask = Task { [weak self] in
            let sources: [ObsidianMemorySource] = await Task.detached(priority: .userInitiated) { () -> [ObsidianMemorySource] in
                var result: [ObsidianMemorySource] = []
                for note in notes {
                    if Task.isCancelled { return [] }
                    guard let content = try? ObsidianVaultReader.readNote(vaultURL: vaultURL, relativePath: note.relativePath, maxCharacters: 2_400) else { continue }
                    result.append(ObsidianMemorySource(relativePath: note.relativePath, title: note.title, text: content.text, modifiedAt: note.modifiedAt))
                }
                return result
            }.value
            guard !Task.isCancelled, let self else { return }
            let graph = MemoryBrainBuilder.build(sources: sources, generatedAt: Date(), maxNotes: 160, maxEdges: 420)
            self.memoryBrainGraph = graph
            self.memoryBrainRepresentedNoteCount = graph.nodes.filter { $0.kind == .note }.count
            self.memoryBrainSkippedNoteCount = max(0, indexedTotal - self.memoryBrainRepresentedNoteCount)
            self.memoryBrainLoading = false
            self.schematicGraph = self.buildSchematicGraph()
        }
    }

    func inspectMemoryBrainNote(_ node: MemoryBrainNode) {
        guard let path = node.relativePath,
              let note = obsidianIndex.notes.first(where: { $0.relativePath == path }) else { return }
        selectObsidianNote(note)
    }

    func selectObsidianNote(_ note: ObsidianNote) {
        guard let obsidianVaultURL else { return }
        obsidianSelectedNote = note
        do {
            obsidianPreview = try ObsidianVaultReader.readNote(vaultURL: obsidianVaultURL, relativePath: note.relativePath)
            obsidianError = nil
        } catch {
            obsidianPreview = nil
            obsidianError = error.localizedDescription
        }
    }

    func attachObsidianPreviewToOracle() {
        guard let obsidianPreview else { return }
        obsidianContext = obsidianPreview
    }

    func clearObsidianContext() {
        obsidianContext = nil
    }

    func disconnectObsidianVault() {
        UserDefaults.standard.removeObject(forKey: obsidianVaultDefaultsKey)
        obsidianVaultPath = nil
        obsidianIndex = .notConfigured()
        obsidianSelectedNote = nil
        obsidianPreview = nil
        obsidianContext = nil
        obsidianError = nil
        memoryBuildTask?.cancel()
        memoryBrainGraph = MemoryBrainGraph(generatedAt: .distantPast, nodes: [], edges: [])
        memoryBrainLoading = false
        memoryBrainRepresentedNoteCount = 0
        memoryBrainSkippedNoteCount = 0
        schematicGraph = buildSchematicGraph()
        refreshControlCenterInventory()
    }

    private func restoreProtectionPreferences() {
        if let data = UserDefaults.standard.data(forKey: protectionPreferencesKey),
           let decoded = try? JSONDecoder().decode(ProtectionPreferences.self, from: data) {
            protectionPreferences = decoded
        }
        updateScheduledScanDetail()
    }

    private func migrateProtectionFindings() {
        var changed = false
        for index in protectionFindings.indices {
            if protectionFindings[index].dedupeKey.hasPrefix("file.script.")
                && !protectionFindings[index].dedupeKey.hasPrefix("file.script-v2.") {
                protectionFindings[index].reviewStatus = .falsePositive
                if !protectionFindings[index].evidence.contains(where: { $0.contains("Rule v2 narrowed matching to script files") }) {
                    protectionFindings[index].evidence.append("Rule v2 narrowed matching to script files; this v1 heuristic overmatched documentation and schema files.")
                }
                changed = true
            }
            if protectionFindings[index].title.contains("Ransomware-like")
                && protectionFindings[index].resource.contains("OracleEICARQA-") {
                protectionFindings[index].reviewStatus = .falsePositive
                if !protectionFindings[index].evidence.contains(where: { $0.contains("Per-root snapshot isolation") }) {
                    protectionFindings[index].evidence.append("Per-root snapshot isolation replaced the shared QA baseline that caused this false burst.")
                }
                changed = true
            }
        }
        if changed { try? protectionStorage.saveFindings(protectionFindings) }
    }

    private func saveProtectionPreferences() {
        if let data = try? JSONEncoder().encode(protectionPreferences) {
            UserDefaults.standard.set(data, forKey: protectionPreferencesKey)
        }
        updateScheduledScanDetail()
    }

    private func updateScheduledScanDetail() {
        guard protectionPreferences.scheduledScanEnabled else {
            scheduledScanDetail = "Disabled"
            return
        }
        if let last = protectionPreferences.lastScheduledScanAt {
            let next = last.addingTimeInterval(Double(protectionPreferences.scheduledIntervalHours) * 3_600)
            scheduledScanDetail = "Last \(last.formatted(date: .abbreviated, time: .shortened)) • next \(next.formatted(date: .abbreviated, time: .shortened))"
        } else {
            scheduledScanDetail = "Waiting for next Oracle refresh"
        }
    }

    func setScheduledScanEnabled(_ enabled: Bool) {
        protectionPreferences.scheduledScanEnabled = enabled
        saveProtectionPreferences()
        refreshProtectionCapabilities()
        if enabled { maybeRunScheduledProtectionScan() }
        updateScheduledScanDetail()
    }

    func setScheduledScanInterval(_ hours: Int) {
        protectionPreferences.scheduledIntervalHours = max(1, hours)
        saveProtectionPreferences()
        updateScheduledScanDetail()
    }

    private func refreshProtectionCapabilities() {
        protectionCapabilities = ProtectionEngine.capabilities(
            auditVerified: UserDefaults.standard.bool(forKey: protectionAuditVerifiedKey),
            scanVerified: UserDefaults.standard.bool(forKey: protectionScanVerifiedKey),
            quarantineVerified: UserDefaults.standard.bool(forKey: protectionQuarantineVerifiedKey),
            scheduledVerified: UserDefaults.standard.bool(forKey: protectionScheduledVerifiedKey),
            scheduledEnabled: protectionPreferences.scheduledScanEnabled,
            modelVerified: UserDefaults.standard.bool(forKey: protectionModelVerifiedKey)
        )
    }

    func runProtectionAudit() {
        guard protectionTask == nil else { return }
        protectionBusy = true
        lastProtectionError = nil
        protectionTask = Task { [weak self] in
            let result = await Task.detached(priority: .utility) { ProtectionEngine.runAudit() }.value
            guard let self else { return }
            self.protectionPosture = result.posture
            self.mergeProtectionFindings(result.findings)
            self.appendProtectionEvent(ProtectionEvent(
                id: UUID(), observedAt: result.observedAt, kind: "security_audit", severity: result.findings.isEmpty ? .info : .high,
                source: "Oracle deterministic audit", summary: "Security audit completed with \(result.findings.count) finding(s)",
                resource: ProcessInfo.processInfo.hostName,
                evidence: ["Processes: \(result.processes.count)", "Established TCP connections: \(result.connections.count)", "Persistence definitions: \(result.persistence.count)"] + result.warnings,
                dedupeKey: "audit.\(Int(result.observedAt.timeIntervalSince1970))"
            ))
            UserDefaults.standard.set(true, forKey: self.protectionAuditVerifiedKey)
            self.refreshProtectionCapabilities()
            self.protectionBusy = false
            self.protectionTask = nil
        }
    }

    func scanDownloads() {
        scanProtectionFolder(URL(fileURLWithPath: NSHomeDirectory()).appendingPathComponent("Downloads", isDirectory: true), scheduled: false)
    }

    func chooseProtectionScanFolder() {
        let panel = NSOpenPanel()
        panel.title = "Choose Folder to Scan"
        panel.prompt = "Scan Folder"
        panel.message = "Oracle will read files locally with bounded limits. It will not execute, upload or delete them."
        panel.canChooseDirectories = true
        panel.canChooseFiles = false
        panel.allowsMultipleSelection = false
        panel.canCreateDirectories = false
        guard panel.runModal() == .OK, let url = panel.url else { return }
        scanProtectionFolder(url, scheduled: false)
    }

    private func scanProtectionFolder(_ url: URL, scheduled: Bool) {
        guard protectionTask == nil else { return }
        protectionBusy = true
        protectionScanInProgress = true
        lastProtectionError = nil
        appendProtectionEvent(ProtectionEvent(
            id: UUID(), observedAt: Date(), kind: "scan_started", severity: .info,
            source: scheduled ? "Scheduled scan" : "Manual scan", summary: scheduled ? "Scheduled local scan started" : "Local scan started",
            resource: url.path, evidence: ["Bounded reads only", "No execution", "No upload"], dedupeKey: "scan.started.\(Int(Date().timeIntervalSince1970))"
        ))
        let snapshotURL = protectionStorage.scanSnapshotURL(for: url)
        let workTask = Task.detached(priority: .utility) {
            ProtectionEngine.scanFiles(root: url, snapshotURL: snapshotURL)
        }
        scanWorkTask = workTask
        protectionTask = Task { [weak self] in
            let report = await workTask.value
            guard let self else { return }
            self.lastScanReport = report
            self.mergeProtectionFindings(report.findings)
            let completion = report.cancelled
                ? "Scan cancelled after checking \(report.filesInspected) file(s)"
                : "Scanned \(report.filesInspected) files with \(report.findings.count) finding(s)"
            self.appendProtectionEvent(ProtectionEvent(
                id: UUID(), observedAt: report.completedAt, kind: "scan_completed", severity: report.findings.isEmpty ? .info : .high,
                source: report.engine, summary: completion,
                resource: report.rootPath,
                evidence: ["Bytes inspected: \(report.bytesInspected)", "Cancelled: \(report.cancelled)"] + report.warnings,
                dedupeKey: "scan.completed.\(Int(report.completedAt.timeIntervalSince1970))"
            ))
            if scheduled && !report.cancelled {
                self.protectionPreferences.lastScheduledScanAt = report.completedAt
                self.saveProtectionPreferences()
                UserDefaults.standard.set(true, forKey: self.protectionScheduledVerifiedKey)
            }
            UserDefaults.standard.set(true, forKey: self.protectionScanVerifiedKey)
            self.refreshProtectionCapabilities()
            self.protectionBusy = false
            self.protectionScanInProgress = false
            self.protectionTask = nil
            self.scanWorkTask = nil
        }
    }

    func cancelProtectionScan() {
        guard protectionScanInProgress else { return }
        scanWorkTask?.cancel()
    }

    private func maybeRunScheduledProtectionScan() {
        guard protectionPreferences.scheduledScanEnabled, !protectionBusy else { return }
        let now = Date()
        let due = protectionPreferences.lastScheduledScanAt.map {
            now.timeIntervalSince($0) >= Double(protectionPreferences.scheduledIntervalHours) * 3_600
        } ?? true
        guard due else { updateScheduledScanDetail(); return }
        scanProtectionFolder(URL(fileURLWithPath: NSHomeDirectory()).appendingPathComponent("Downloads", isDirectory: true), scheduled: true)
    }

    private func mergeProtectionFindings(_ incoming: [ProtectionFinding]) {
        guard !incoming.isEmpty else { return }
        var byKey = Dictionary(uniqueKeysWithValues: protectionFindings.map { ($0.dedupeKey, $0) })
        for finding in incoming {
            if let existing = byKey[finding.dedupeKey] {
                if existing.reviewStatus == .falsePositive { continue }
                var merged = existing
                merged.lastObservedAt = finding.lastObservedAt
                merged.occurrences += 1
                merged.severity = max(existing.severity, finding.severity)
                merged.evidence = Array(Set(existing.evidence + finding.evidence)).sorted()
                merged.rationale = finding.rationale
                merged.confidence = finding.confidence
                merged.reviewStatus = existing.reviewStatus == .resolved ? .open : existing.reviewStatus
                byKey[finding.dedupeKey] = merged
            } else {
                byKey[finding.dedupeKey] = finding
            }
        }
        protectionFindings = byKey.values.sorted {
            if $0.severity != $1.severity { return $0.severity > $1.severity }
            return $0.lastObservedAt > $1.lastObservedAt
        }
        try? protectionStorage.saveFindings(protectionFindings)
    }

    private func appendProtectionEvent(_ event: ProtectionEvent) {
        try? protectionStorage.append(event)
        protectionEvents = ([event] + protectionEvents).prefix(2_000).map { $0 }
    }

    func markFindingFalsePositive(_ finding: ProtectionFinding) {
        guard let index = protectionFindings.firstIndex(where: { $0.id == finding.id }) else { return }
        protectionFindings[index].reviewStatus = .falsePositive
        try? protectionStorage.saveFindings(protectionFindings)
        appendProtectionEvent(ProtectionEvent(
            id: UUID(), observedAt: Date(), kind: "finding_false_positive", severity: .info,
            source: "Owner review", summary: "Marked finding as false positive: \(finding.title)",
            resource: finding.resource, evidence: ["Dedupe key \(finding.dedupeKey)"], dedupeKey: "review.fp.\(finding.dedupeKey)"
        ))
    }

    func attachFindingToOracle(_ finding: ProtectionFinding) {
        let content = """
        Severity: \(finding.severity.rawValue)
        Source: \(finding.source)
        Resource: \(finding.resource)
        Observed: \(finding.lastObservedAt.formatted(date: .abbreviated, time: .standard))
        Occurrences: \(finding.occurrences)
        Confidence: \(finding.confidence)
        Review status: \(finding.reviewStatus.label)
        Rationale: \(finding.rationale)
        Evidence: \(finding.evidence.joined(separator: " | "))
        Available response: \(finding.canQuarantine ? "Owner-approved reversible quarantine may be available" : "No typed response is available")
        """
        securityContext = SecurityPromptContext(title: finding.title, content: String(content.prefix(4_000)))
        section = "Oracle"
    }

    func quarantine(_ finding: ProtectionFinding) {
        guard finding.canQuarantine else { return }
        do {
            let record = try protectionStorage.quarantine(fileURL: URL(fileURLWithPath: finding.resource), finding: finding)
            quarantineRecords = protectionStorage.listQuarantine()
            if let index = protectionFindings.firstIndex(where: { $0.id == finding.id }) {
                protectionFindings[index].reviewStatus = .resolved
                try? protectionStorage.saveFindings(protectionFindings)
            }
            UserDefaults.standard.set(true, forKey: protectionQuarantineVerifiedKey)
            refreshProtectionCapabilities()
            appendProtectionEvent(ProtectionEvent(
                id: UUID(), observedAt: Date(), kind: "quarantine", severity: .medium,
                source: "Owner-approved response", summary: "Quarantined \(URL(fileURLWithPath: record.originalPath).lastPathComponent)",
                resource: record.originalPath, evidence: ["SHA-256 \(record.sha256)", "Restore metadata retained", "No deletion"], dedupeKey: "quarantine.\(record.id.uuidString)"
            ))
        } catch {
            lastProtectionError = error.localizedDescription
        }
    }

    func restore(_ record: QuarantineRecord) {
        do {
            _ = try protectionStorage.restore(record)
            quarantineRecords = protectionStorage.listQuarantine()
            appendProtectionEvent(ProtectionEvent(
                id: UUID(), observedAt: Date(), kind: "quarantine_restore", severity: .info,
                source: "Owner-approved response", summary: "Restored \(URL(fileURLWithPath: record.originalPath).lastPathComponent)",
                resource: record.originalPath, evidence: ["SHA-256 verified before restore"], dedupeKey: "restore.\(record.id.uuidString)"
            ))
        } catch {
            lastProtectionError = error.localizedDescription
        }
    }

    func setCameraRetentionDays(_ days: Int) {
        cameraRetentionDays = max(1, days)
        UserDefaults.standard.set(cameraRetentionDays, forKey: cameraRetentionDaysKey)
        refreshExpiredCameraEvidenceCount()
    }

    func refreshExpiredCameraEvidenceCount() {
        expiredCameraEvidenceCount = CameraEvidenceCipher.expiredEvidence(
            in: baseURL.appendingPathComponent("Evidence", isDirectory: true),
            olderThanDays: cameraRetentionDays
        ).count
    }

    func clearExpiredCameraEvidenceToTrash() {
        let expired = CameraEvidenceCipher.expiredEvidence(
            in: baseURL.appendingPathComponent("Evidence", isDirectory: true),
            olderThanDays: cameraRetentionDays
        )
        for url in expired { try? FileManager.default.trashItem(at: url, resultingItemURL: nil) }
        refreshExpiredCameraEvidenceCount()
    }

    private func loadIntegrationState() -> ControlCenterIntegrationState {
        guard let data = UserDefaults.standard.data(forKey: integrationStateKey),
              let state = try? JSONDecoder().decode(ControlCenterIntegrationState.self, from: data) else {
            return ControlCenterIntegrationState()
        }
        return state
    }

    private func saveIntegrationState(_ state: ControlCenterIntegrationState) {
        if let data = try? JSONEncoder().encode(state) {
            UserDefaults.standard.set(data, forKey: integrationStateKey)
        }
    }

    func refreshControlCenterInventory() {
        let state = loadIntegrationState()
        let session = ControlCenterIntegrationEngine.sessionMetadata()
        let (version, build) = ControlCenterIntegrationEngine.mttVersion()
        let storedSnapshot = state.mttLastSnapshot.map {
            MTTMonitorSnapshot(timestamp: $0.timestamp, cpuTotal: $0.cpuTotal, memoryPhysical: $0.memoryPhysical, memoryUsed: $0.memoryUsed, compressed: $0.compressed, thermalState: $0.thermalState, thermalRank: $0.thermalRank, networkStatus: $0.networkStatus, processStatus: $0.processStatus, processCount: $0.processCount)
        }
        mttBridgeMetadata = MTTBridgeMetadata(
            appPath: ControlCenterIntegrationEngine.mttPath,
            version: version,
            build: build,
            isRunning: ControlCenterIntegrationEngine.isMTTRunning(),
            sessionSavedAt: session.savedAt,
            sessionMessageCount: session.messageCount,
            draftLength: session.draftLength,
            monitorEventsBytes: ControlCenterIntegrationEngine.monitorEventsBytes(),
            lastSnapshot: storedSnapshot,
            lastCapturedAt: state.mttLastCapturedAt
        )
        connectedResources = ControlCenterIntegrationEngine.inventory(
            modelAvailable: providerState == .available,
            modelName: settings.modelID,
            vaultName: obsidianVaultURL?.lastPathComponent,
            findingCount: protectionFindings.count
        )
        connectedResources.append(ConnectedResource(
            id: "service-on-device-dictation",
            name: "On-device Oracle dictation",
            kind: "Voice input",
            status: dictationController.isListening ? "Listening" : "Available on request",
            detail: "Apple on-device speech recognition; no server-recognizer fallback. Permission is requested only when Listen is pressed.",
            path: nil,
            isRunning: dictationController.isListening,
            capabilities: ["Speech-to-text into the Oracle draft", "Explicit stop", "No automatic send"],
            limitations: ["Locale support varies.", "Microphone and speech permissions are not requested during launch."]
        ))
        connectedResources.append(ConnectedResource(
            id: "service-fish-audio",
            name: "Fish Audio original voice",
            kind: "Voice output",
            status: voiceController.fishReady ? "Configured • external, not tested live" : "Not configured",
            detail: voiceController.fishReady
                ? "Keychain credential and original voice ID present. No request is sent without disclosure acceptance."
                : "No API key/original voice ID configured; no external voice request was made.",
            path: voiceController.lastVoiceDesignPath,
            isRunning: voiceController.isSpeaking && voiceController.sourceLabel.contains("Fish Audio"),
            capabilities: ["Original Voice Design audition", "Bounded external TTS", "Amplitude-driven mask-light cue"],
            limitations: ["No phoneme/viseme alignment or facial rig", "Third-party service", "Free-model privacy/data-improvement terms", "No TTFA, DPA or SLA assumption", "No performer cloning"]
        ))
        connectedResources.append(ConnectedResource(
            id: "device-raspberry-pi-embodiment",
            name: "Raspberry Pi embodiment",
            kind: "Future local device",
            status: "Not configured",
            detail: "\(OracleEmbodimentProtocolVersion.current) contract prepared; 0 of \(OracleEmbodimentReadiness.requiredCapabilities.count) host capabilities verified.",
            path: nil,
            isRunning: false,
            capabilities: ["Offline motion-frame protocol", "Speech start/progress/end events", "Gesture and expression events", "Sequence and heartbeat schema"],
            limitations: ["No pairing credential, endpoint or device identity exists.", "No network connection or command delivery is implemented or claimed."]
        ))
    }

    func captureMTTSnapshot() {
        guard integrationTask == nil else { return }
        integrationBusy = true
        lastIntegrationError = nil
        integrationTask = Task { [weak self] in
            do {
                let snapshot = try await Task.detached(priority: .utility) {
                    try ControlCenterIntegrationEngine.captureMTTSnapshot()
                }.value
                guard let self else { return }
                var state = self.loadIntegrationState()
                state.mttLastCapturedAt = Date()
                state.mttLastSnapshot = StoredMTTSnapshot(
                    timestamp: snapshot.timestamp, cpuTotal: snapshot.cpuTotal,
                    memoryPhysical: snapshot.memoryPhysical, memoryUsed: snapshot.memoryUsed,
                    compressed: snapshot.compressed, thermalState: snapshot.thermalState,
                    thermalRank: snapshot.thermalRank, networkStatus: snapshot.networkStatus,
                    processStatus: snapshot.processStatus, processCount: snapshot.processCount
                )
                self.saveIntegrationState(state)
                self.appendProtectionEvent(ProtectionEvent(
                    id: UUID(), observedAt: snapshot.timestamp, kind: "mtt_sample", severity: .info,
                    source: "Memory Trinity Triage monitor bridge",
                    summary: "Read-only MTT sample captured",
                    resource: "Memory Trinity Triage",
                    evidence: ["Used-memory estimate: \(snapshot.memoryUsed ?? 0)", "Compressed: \(snapshot.compressed ?? 0)", "Thermal: \(snapshot.thermalState)", "Network: \(snapshot.networkStatus)", "Processes: \(snapshot.processCount)"],
                    dedupeKey: "mtt.sample.\(Int(snapshot.timestamp.timeIntervalSince1970))"
                ))
                self.refreshControlCenterInventory()
            } catch {
                self?.lastIntegrationError = error.localizedDescription
            }
            self?.integrationBusy = false
            self?.integrationTask = nil
        }
    }

    func attachMTTSampleToOracle() {
        guard let snapshot = mttBridgeMetadata?.lastSnapshot else { return }
        let content = """
        Source: Memory Trinity Triage one-shot --monitor-record bridge
        Observed: \(snapshot.timestamp.formatted(date: .abbreviated, time: .standard))
        CPU: \(snapshot.cpuTotal.map { String(format: "%.1f%%", $0) } ?? "warming up / unavailable")
        CPU limitation: warming up means this one-shot run lacked the baseline needed for a CPU reading; it is not evidence of throttling.
        Physical memory: \(snapshot.memoryPhysical.map(String.init) ?? "unavailable") bytes
        Used-memory estimate: \(snapshot.memoryUsed.map(String.init) ?? "unavailable") bytes
        Compressed memory: \(snapshot.compressed.map(String.init) ?? "unavailable") bytes
        Thermal state: \(snapshot.thermalState) (OS category, not temperature)
        Network telemetry: \(snapshot.networkStatus)
        Process telemetry: \(snapshot.processStatus), \(snapshot.processCount) readable process(es)
        Limit: This is one read-only MTT sample. It does not establish causation, complete hardware health, or authorization for process actions.
        """
        securityContext = SecurityPromptContext(title: "Memory Trinity Triage monitor sample", content: String(content.prefix(4_000)))
        section = "Oracle"
    }

    func openConnectedResource(_ resource: ConnectedResource) {
        guard let path = resource.path else { return }
        let url = URL(fileURLWithPath: path)
        if url.pathExtension.lowercased() == "app" {
            if let running = NSRunningApplication.runningApplications(withBundleIdentifier: resource.detail.split(separator: "•").last?.trimmingCharacters(in: .whitespaces) ?? "").first {
                running.activate(options: [.activateAllWindows])
                return
            }
            let configuration = NSWorkspace.OpenConfiguration()
            configuration.activates = true
            NSWorkspace.shared.openApplication(at: url, configuration: configuration) { [weak self] _, error in
                if let error { DispatchQueue.main.async { self?.lastIntegrationError = error.localizedDescription } }
            }
        } else {
            NSWorkspace.shared.open(url)
        }
    }

    func revealConnectedResource(_ resource: ConnectedResource) {
        guard let path = resource.path else { return }
        NSWorkspace.shared.activateFileViewerSelecting([URL(fileURLWithPath: path)])
    }

    private func shellRead(_ path: String, _ args: [String]) -> String {
        let p = Process()
        p.executableURL = URL(fileURLWithPath: path)
        p.arguments = args
        let pipe = Pipe()
        p.standardOutput = pipe
        p.standardError = FileHandle.nullDevice
        do {
            try p.run()
            p.waitUntilExit()
            let data = pipe.fileHandleForReading.readDataToEndOfFile()
            return String(data: data, encoding: .utf8) ?? ""
        } catch {
            return ""
        }
    }

    private func executeOracleTool(_ command: OracleCommandRequest, model: String) throws -> String {
        guard settings.allowModelToolRequests else {
            throw NSError(domain: "OracleCommand", code: 4, userInfo: [NSLocalizedDescriptionKey: "Qwen in-app tools were turned off before execution."])
        }
        let target: String
        let result: [String: String]
        switch command {
        case .status:
            target = "Oracle status"
            result = [
                "model": settings.modelID,
                "provider": providerState.rawValue,
                "current_section": section,
                "security_state": securityState,
                "security_observed_at": stateObservedAt.map { ISO8601DateFormatter().string(from: $0) } ?? "unknown",
                "camera_state": cameraState
            ]
        case .behavior(let proposal):
            guard voiceConversationEnabled, !voiceController.isMuted else {
                throw NSError(domain: "OracleCommand", code: 8, userInfo: [NSLocalizedDescriptionKey: "Oracle local reply speech is not active for this cue."])
            }
            target = "Speech-timed Oracle light cue"
            result = ["proposal": "held pending a matching phrase in the final spoken reply",
                      "gesture": proposal.gesture.rawValue]
        case .openSection(let requestedSection):
            guard !settings.readOnlyToolsOnly,
                  OracleCommandBroker.navigableSections.contains(requestedSection) else {
                throw NSError(domain: "OracleCommand", code: 5, userInfo: [NSLocalizedDescriptionKey: "In-app navigation is not enabled for Qwen."])
            }
            target = requestedSection
            result = ["previous_section": section, "opened_section": requestedSection]
        }
        let data = try JSONSerialization.data(withJSONObject: result)
        guard let resultText = String(data: data, encoding: .utf8) else {
            throw NSError(domain: "OracleCommand", code: 6, userInfo: [NSLocalizedDescriptionKey: "Oracle could not encode the bounded tool result."])
        }
        let outcome = command.name == "propose_oracle_behavior" ? "proposed; awaiting matching speech" : "executed"
        let receipt = OracleCommandAuditReceipt(id: UUID(), observedAt: Date(), modelID: model,
            command: command.name, target: target, outcome: outcome)
        try OracleCommandAuditStore.append(receipt, to: baseURL.appendingPathComponent("command-audit.jsonl"))
        if case .openSection(let requestedSection) = command { section = requestedSection }
        if case .behavior(let proposal) = command { pendingBehaviorProposal = proposal }
        lastCommandReceipt = "\(command.name) • \(target) • \(outcome) • \(receipt.id.uuidString)"
        return resultText
    }

    func messageText(_ id: UUID) -> String {
        messages.first(where: { $0.id == id })?.text ?? ""
    }

    private var requestTask: Task<Void, Never>?

    func setDraft(_ text: String) {
        draft = text
        scheduleSessionSave()
    }

    func persistNow() {
        sessionSaveTask?.cancel()
        saveChatSession()
    }

    private func restoreChatSession() {
        guard FileManager.default.fileExists(atPath: chatSessionURL.path) else { return }
        do {
            let saved = try OracleChatSessionStore.load(from: chatSessionURL)
            draft = saved.draft
            messages = saved.messages.map { stored in
                let state = ModelRequestStatus(rawValue: stored.state) ?? .failed
                let restoredState: ModelRequestStatus = state == .streaming ? .cancelled : state
                return ConversationMessage(
                    id: stored.id,
                    createdAt: stored.createdAt,
                    role: stored.role,
                    text: stored.text,
                    state: restoredState,
                    providerID: stored.providerID,
                    modelID: stored.modelID
                )
            }
            chatSessionError = nil
        } catch {
            sessionWriteBlocked = true
            chatSessionError = "The saved Oracle session could not be read. The existing file was preserved and new chat writes are paused."
        }
    }

    private func scheduleSessionSave() {
        guard !sessionWriteBlocked else { return }
        sessionSaveTask?.cancel()
        sessionSaveTask = Task { [weak self] in
            try? await Task.sleep(for: .milliseconds(250))
            guard !Task.isCancelled, let self else { return }
            self.saveChatSession()
        }
    }

    private func saveChatSession() {
        guard !sessionWriteBlocked else { return }
        let storedMessages = messages.map {
            OracleChatStoredMessage(
                id: $0.id,
                createdAt: $0.createdAt,
                role: $0.role,
                text: $0.text,
                state: $0.state.rawValue,
                providerID: $0.providerID,
                modelID: $0.modelID
            )
        }
        do {
            try OracleChatSessionStore.save(
                OracleChatSession(draft: draft, messages: storedMessages, savedAt: Date()),
                to: chatSessionURL
            )
            chatSessionError = nil
        } catch {
            chatSessionError = "The Oracle conversation could not be saved locally. Nothing was deleted."
        }
    }

    private func appendMessage(_ message: ConversationMessage) {
        messages.append(message)
        scheduleSessionSave()
    }

    private func updateMessage(id: UUID, text: String, state: ModelRequestStatus) {
        guard let index = messages.firstIndex(where: { $0.id == id }) else { return }
        let old = messages[index]
        messages[index] = ConversationMessage(
            id: old.id,
            createdAt: old.createdAt,
            role: old.role,
            text: text,
            state: state,
            providerID: old.providerID,
            modelID: old.modelID
        )
        scheduleSessionSave()
    }

    func cancelModelBehavior() {
        modelBehaviorTask?.cancel()
        modelBehaviorTask = nil
        pendingBehaviorProposal = nil
        if let cue = modelBehaviorGesture, gestureCue == cue { gestureCue = .none }
        modelBehaviorGesture = nil
        modelBehaviorExpression = nil
    }

    private func scheduleModelBehavior(_ proposal: OracleBehaviorProposal, spokenText: String, speechID: UUID) {
        guard let fraction = proposal.emphasisFraction(in: spokenText),
              proposal.intensity > 0, motionMode == .idle,
              gestureCue == .none else { return }
        let cue = proposal.supportedGestureCue
        if cue != .none && Date().timeIntervalSince(lastModelGestureAt) < 6 { return }
        modelBehaviorTask?.cancel()
        modelBehaviorTask = Task { @MainActor [weak self] in
            for _ in 0..<600 { // At most 30 seconds while actual local speech progresses.
                guard !Task.isCancelled, let self else { return }
                let voice = self.voiceController
                guard voice.localSpeechSessionID == speechID else { return }
                if voice.isMuted || voice.state == .cancelled || voice.state == .failed || voice.state == .finished { return }
                if voice.state == .speaking && voice.speechProgress > 0 && voice.speechProgress >= fraction {
                    guard self.motionMode == .idle, self.gestureCue == .none else { return }
                    self.modelBehaviorGesture = cue
                    self.modelBehaviorExpression = proposal.supportedMaskExpression
                    if cue != .none {
                        self.gestureCue = cue
                        self.lastModelGestureAt = Date()
                    }
                    let duration = Int(600 + proposal.intensity * 1_000)
                    try? await Task.sleep(for: .milliseconds(duration))
                    if !Task.isCancelled { self.cancelModelBehavior() }
                    return
                }
                try? await Task.sleep(for: .milliseconds(50))
            }
        }
    }

    func cancelRequest() {
        guard modelState == .streaming else { return }
        cancelModelBehavior()
        requestTask?.cancel()
        if let id = activeAssistantMessageID {
            updateMessage(id: id, text: messageText(id), state: .cancelled)
        }
        activeAssistantMessageID = nil
        modelState = .cancelled
        providerDetail = "Local request cancelled. Your message and conversation are preserved."
        persistNow()
    }

    func send(_ text: String) {
        guard requestTask == nil else {
            providerDetail = "Previous local request is still closing. Try again in a moment."
            return
        }
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        guard trimmed.utf8.count <= OracleChatRequestBuilder.maximumMessageBytes else {
            providerDetail = "Message is too long. Please split it into shorter messages (8 KB maximum)."
            modelState = .failed
            return
        }
        guard settings.modelProviderID == "ollama", !settings.modelID.isEmpty,
              !settings.modelID.lowercased().contains(":cloud") else {
            providerDetail = "Select an installed local Ollama model. Cloud routing is disabled."
            modelState = .unavailable
            return
        }
        let model = settings.modelID
        guard installedModels.contains(model) else {
            providerDetail = "Configured model \(model) is not currently installed in Ollama. No inference request was made."
            modelState = .unavailable
            return
        }
        cancelModelBehavior()
        let attachedNote = obsidianContext
        let attachedSecurity = securityContext
        let priorTurns = messages.compactMap { message -> OracleChatHistoryTurn? in
            guard message.state == .done, (message.role == "user" || message.role == "assistant"),
                  !message.text.isEmpty else { return nil }
            return OracleChatHistoryTurn(role: message.role, text: message.text)
        }
        let navigationAllowedForRequest = OracleCommandBroker.navigationAllowed(
            modelToolsEnabled: settings.allowModelToolRequests,
            readOnlyToolsOnly: settings.readOnlyToolsOnly,
            hasAttachedContext: attachedNote != nil || attachedSecurity != nil)
        let behaviorAllowedForRequest = voiceConversationEnabled && !voiceController.isMuted
        let enabledTools = settings.allowModelToolRequests
            ? OracleCommandBroker.schemas(allowNavigation: navigationAllowedForRequest, allowBehavior: behaviorAllowedForRequest) : []
        obsidianContext = nil
        securityContext = nil
        appendMessage(ConversationMessage(id: UUID(), createdAt: Date(), role: "user", text: trimmed,
            state: .done, providerID: "ollama", modelID: model))
        let assistantID = UUID()
        activeAssistantMessageID = assistantID
        messages.append(ConversationMessage(id: assistantID, createdAt: Date(), role: "assistant", text: "",
            state: .streaming, providerID: "ollama", modelID: model))
        draft = ""
        persistNow()
        modelState = .streaming
        providerDetail = attachedNote == nil
            ? (attachedSecurity == nil
                ? "Waiting for local model response. This message and bounded prior conversation are sent; no files or security records are included."
                : "Waiting for local model response. Bounded prior conversation and one explicitly attached redacted security finding are sent; no other files or logs are included.")
            : "Waiting for local model response. Bounded prior conversation and the explicitly attached one-shot context are sent; no other files, notes or security records are included."
        requestTask = Task { [weak self] in
            guard let self else { return }
            defer {
                self.requestTask = nil
                self.activeAssistantMessageID = nil
            }
            do {
                let prepared = try OracleChatRequestBuilder.prepare(model: model, userText: trimmed, note: attachedNote,
                    securityContext: attachedSecurity, history: priorTurns, tools: enabledTools)
                var request = URLRequest(url: URL(string: "http://127.0.0.1:11434/api/chat")!)
                request.httpMethod = "POST"
                request.timeoutInterval = 120
                request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                request.httpBody = prepared.body
                let config = URLSessionConfiguration.ephemeral
                config.timeoutIntervalForRequest = 120
                config.timeoutIntervalForResource = 180
                let session = URLSession(configuration: config)
                defer { session.invalidateAndCancel() }
                let (bytes, response) = try await session.bytes(for: request)
                guard let http = response as? HTTPURLResponse, http.statusCode == 200 else {
                    let code = (response as? HTTPURLResponse)?.statusCode ?? 0
                    var detail = ""
                    var errorBytes: [UInt8] = []
                    for try await byte in bytes {
                        errorBytes.append(byte)
                        if errorBytes.count >= 2_048 { break }
                    }
                    if let object = try? JSONSerialization.jsonObject(with: Data(errorBytes)) as? [String: Any],
                       let message = object["error"] as? String {
                        detail = " " + message
                    }
                    throw NSError(domain: "OracleChat", code: code, userInfo: [NSLocalizedDescriptionKey: "Local model request failed (HTTP \(code)).\(detail)"])
                }
                self.providerDetail = prepared.noteWasTruncated
                    ? "Receiving from local Ollama. The attached Obsidian note was clipped only for this request to stay within the local request budget; the saved note was not changed."
                    : "Receiving from local Ollama."

                var reply = ""
                var completed = false
                var requestedToolMessage: [String: Any]?
                for try await line in bytes.lines {
                    if Task.isCancelled { throw CancellationError() }
                    guard !line.isEmpty,
                          let data = line.data(using: .utf8),
                          let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { continue }
                    if let error = obj["error"] as? String {
                        throw NSError(domain: "OracleChat", code: 3, userInfo: [NSLocalizedDescriptionKey: error])
                    }
                    if let message = obj["message"] as? [String: Any] {
                        if message["tool_calls"] != nil {
                            requestedToolMessage = message
                        } else if let piece = message["content"] as? String, !piece.isEmpty {
                            reply += piece
                            self.updateMessage(id: assistantID, text: reply, state: .streaming)
                        }
                    }
                    if obj["done"] as? Bool == true {
                        completed = true
                        break
                    }
                }
                if let toolMessage = requestedToolMessage {
                    if Task.isCancelled { throw CancellationError() }
                    guard completed else {
                        throw NSError(domain: "OracleCommand", code: 7, userInfo: [NSLocalizedDescriptionKey: "Incomplete Qwen tool response; no command ran."])
                    }
                    guard let toolRequest = try OracleCommandBroker.request(from: toolMessage,
                        allowNavigation: navigationAllowedForRequest && !self.settings.readOnlyToolsOnly,
                        allowBehavior: behaviorAllowedForRequest && self.voiceConversationEnabled && !self.voiceController.isMuted) else {
                        throw NSError(domain: "OracleCommand", code: 2, userInfo: [NSLocalizedDescriptionKey: "No valid Oracle tool request was returned."])
                    }
                    let toolResult = try self.executeOracleTool(toolRequest, model: model)
                    let followupBody = try OracleCommandBroker.followupBody(originalRequest: prepared.body,
                        assistantMessage: toolMessage, request: toolRequest, result: toolResult)
                    var followupRequest = request
                    followupRequest.httpBody = followupBody
                    let (followupData, followupResponse) = try await session.data(for: followupRequest)
                    guard (followupResponse as? HTTPURLResponse)?.statusCode == 200,
                          followupData.count <= 65_536,
                          let followup = try JSONSerialization.jsonObject(with: followupData) as? [String: Any],
                          followup["done"] as? Bool == true,
                          let finalMessage = followup["message"] as? [String: Any],
                          finalMessage["tool_calls"] == nil,
                          let finalText = finalMessage["content"] as? String else {
                        throw NSError(domain: "OracleCommand", code: 3, userInfo: [NSLocalizedDescriptionKey: "The local model did not return a bounded final answer after the tool result."])
                    }
                    reply = finalText
                }
                guard completed, !reply.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
                    throw NSError(domain: "OracleChat", code: 2, userInfo: [NSLocalizedDescriptionKey: "Local model returned an incomplete or empty response."])
                }
                self.updateMessage(id: assistantID, text: reply, state: .done)
                if attachedSecurity != nil {
                    UserDefaults.standard.set(true, forKey: self.protectionModelVerifiedKey)
                    self.refreshProtectionCapabilities()
                }
                self.modelState = .done
                self.providerDetail = prepared.historyWasTruncated
                    ? "Local response complete. Older conversation context was clipped to the request budget; the saved conversation was not changed."
                    : "Local response complete. The conversation and draft are saved locally under Documents/ORACLE/Agamemnon."
                self.persistNow()
                let proposedBehavior = self.pendingBehaviorProposal
                self.pendingBehaviorProposal = nil
                if self.voiceConversationEnabled, !Task.isCancelled, !self.voiceController.isMuted {
                    self.voiceController.speakLocal(reply)
                    if let proposedBehavior,
                       let spokenText = self.voiceController.currentLocalSpeechText,
                       let speechID = self.voiceController.localSpeechSessionID {
                        self.scheduleModelBehavior(proposedBehavior, spokenText: spokenText, speechID: speechID)
                    }
                }
            } catch {
                self.cancelModelBehavior()
                if error is CancellationError || Task.isCancelled {
                    self.modelState = .cancelled
                    self.updateMessage(id: assistantID, text: self.messageText(assistantID), state: .cancelled)
                    self.providerDetail = "Local request cancelled. Your message and conversation are preserved."
                } else {
                    self.modelState = (error as? URLError)?.code == .timedOut ? .timeout : .failed
                    self.updateMessage(id: assistantID, text: self.messageText(assistantID), state: self.modelState)
                    let failure = error.localizedDescription
                    if failure.lowercased().contains("request body too long") ||
                        failure.contains("HTTP 413") ||
                        failure.lowercased().contains("too large") {
                        self.providerDetail = "The local model rejected an oversized request. Oracle's 16 KB body budget and explicit note clipping should prevent recurrence. No conversation, message, draft or attachment was deleted; no automatic retry was attempted. Start a fresh shorter request if needed."
                    } else {
                        self.providerDetail = "Response failed: " + failure + " Your message and completed reply text are preserved. No automatic retry."
                    }
                }
                self.persistNow()
            }
        }
    }

}
struct WorkspaceView: View {
    @ObservedObject var store: OracleWorkspaceStore
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    private let sections = ["Overview", "Connections", "Protection", "Oracle", "Findings", "Timeline", "Evidence", "Quarantine", "Obsidian", "Memory Brain", "Schematics", "Permissions", "Network", "Settings"]

    var body: some View {
        ZStack {
            OracleBackdrop(paused: store.section == "Memory Brain")
            if store.presentationMode == .workspace {
            NavigationSplitView {
                VStack(spacing: 0) {
                    OracleSidebarBrand()
                    List(selection: $store.section) {
                        ForEach(sections, id: \.self) { section in
                            Label(section, systemImage: sectionIcon(section))
                                .font(.body.weight(store.section == section ? .semibold : .regular))
                                .foregroundStyle(store.section == section ? OraclePalette.lavender : OraclePalette.coolText.opacity(0.82))
                                .tag(section)
                                .listRowBackground(
                                    store.section == section
                                        ? OraclePalette.violet.opacity(0.24)
                                        : Color.clear
                                )
                        }
                    }
                    .scrollContentBackground(.hidden)
                    .listStyle(.sidebar)
                    .background(Color.clear)
                }
                .background(OraclePalette.void.opacity(0.74))
                .overlay(alignment: .trailing) {
                    Rectangle().fill(OraclePalette.lavender.opacity(0.09)).frame(width: 1)
                }
            } detail: {
                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        OracleBrandHeader(title: store.title)
                        Group {
                            switch store.section {
                            case "Overview": SecurityOverviewView(store: store)
                            case "Connections": ConnectionsView(store: store)
                            case "Protection": ProtectionCenterView(store: store)
                            case "Oracle": OracleAssistantView(store: store)
                            case "Findings": ProtectionFindingsView(store: store)
                            case "Timeline": TimelineView(store: store)
                            case "Evidence": EvidenceView(store: store)
                            case "Quarantine": QuarantineView(store: store)
                            case "Obsidian": ObsidianVaultView(store: store)
                            case "Memory Brain": MemoryBrainView(store: store)
                            case "Schematics": SchematicsView(store: store)
                            case "Permissions": PermissionsView(store: store)
                            case "Network": NetworkView(store: store)
                            case "Settings": SettingsView(store: store)
                            default:
                                Text("Unavailable")
                            }
                        }
                        .id(store.section)
                        .transition(.opacity.combined(with: .scale(scale: 0.995)))
                    }
                    .padding(24)
                }
                .background(Color.clear)
                .animation(reduceMotion ? nil : .easeOut(duration: 0.2), value: store.section)
            }
            .navigationSplitViewStyle(.balanced)
            .background(Color.clear)
            } else {
                OraclePresenceView(store: store)
            }
        }
        .preferredColorScheme(.dark)
        .tint(OraclePalette.magenta)
        .frame(minWidth: store.presentationMode == .compact ? 360 : 900,
               minHeight: store.presentationMode == .compact ? 440 : 620)
    }

    private func sectionIcon(_ name: String) -> String {
        switch name {
        case "Overview": return "shield.lefthalf.filled"
        case "Connections": return "point.3.connected.trianglepath.dotted"
        case "Protection": return "checkmark.shield.fill"
        case "Oracle": return "person.crop.circle.badge.sparkles"
        case "Findings": return "exclamationmark.triangle"
        case "Timeline": return "clock.arrow.circlepath"
        case "Evidence": return "externaldrive.badge.checkmark"
        case "Quarantine": return "archivebox.fill"
        case "Obsidian": return "books.vertical"
        case "Memory Brain": return "brain.head.profile"
        case "Schematics": return "point.3.connected.trianglepath.dotted"
        case "Permissions": return "lock.shield"
        case "Network": return "network"
        case "Settings": return "gearshape.2"
        default: return "circle"
        }
    }
}

struct InfoRow: View {
    let key: String
    let value: String
    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Text(key)
                .font(.caption.weight(.bold)).tracking(0.5)
                .foregroundStyle(OraclePalette.gold)
                .frame(width: 140, alignment: .leading)
            Text(value)
                .font(.body)
                .foregroundStyle(OraclePalette.coolText.opacity(0.82))
                .multilineTextAlignment(.leading)
                .textSelection(.enabled)
        }
        .padding(.vertical, 7)
        .frame(maxWidth: .infinity, alignment: .leading)
        .overlay(alignment: .bottom) { Rectangle().fill(OraclePalette.lavender.opacity(0.08)).frame(height: 1) }
    }
}

struct SecurityOverviewView: View {
    @ObservedObject var store: OracleWorkspaceStore
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            OracleSectionHeading(
                eyebrow: "Live security posture",
                title: store.securityState,
                detail: store.collectorState
            )
            HStack(spacing: 8) {
                OracleStatusPill(
                    title: store.securityState,
                    color: store.securityState == "ARMED" ? OraclePalette.good : OraclePalette.warning,
                    symbol: store.securityState == "ARMED" ? "shield.fill" : "shield.slash"
                )
                OracleStatusPill(
                    title: store.cameraName == "Unknown" ? "Camera unknown" : store.cameraName,
                    color: store.cameraName == "Unknown" ? .secondary : OraclePalette.electricPurple,
                    symbol: "video"
                )
                Spacer()
                Text(store.providerState.label)
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(OraclePalette.lavender.opacity(0.78))
            }
            VStack(spacing: 0) {
                InfoRow(key: "Camera", value: store.cameraName)
                InfoRow(key: "Camera state", value: store.cameraState)
                InfoRow(key: "Permission", value: store.permissionState)
            }
            VStack(alignment: .leading, spacing: 10) {
                Text("Safety posture").font(.headline).foregroundStyle(OraclePalette.lavender)
                Text("VPN, firewall, and route state are read-only indicators, not a guarantee of protection. Route and DNS are not yet verified.")
                    .font(.footnote).foregroundStyle(OraclePalette.coolText.opacity(0.7))
                ForEach(store.networkProtection) { item in
                    VStack(alignment: .leading, spacing: 5) {
                        HStack {
                            Image(systemName: item.state == "Connected" ? "checkmark.circle.fill" : "circle.dashed")
                                .foregroundStyle(item.state == "Connected" ? OraclePalette.good : OraclePalette.warning)
                            Text(item.name).font(.headline).foregroundStyle(OraclePalette.lavender)
                            Spacer()
                            Text(item.state).font(.caption.weight(.semibold)).foregroundStyle(OraclePalette.coolText.opacity(0.72))
                        }
                        Text("\(item.method) • service state observed \(item.observedAt.formatted(date: .abbreviated, time: .standard))")
                            .font(.caption).foregroundStyle(OraclePalette.coolText.opacity(0.65))
                        Text("Default route \(item.defaultRouteInterface ?? "unknown") • \(item.dnsResolverCount.map(String.init) ?? "unknown") DNS resolver(s) • tunnel ownership and leak protection unknown")
                            .font(.caption).foregroundStyle(OraclePalette.coolText.opacity(0.65))
                        Text(item.limitations.joined(separator: " ")).font(.footnote).foregroundStyle(OraclePalette.coolText.opacity(0.58))
                    }
                    .padding(12)
                    .background(OraclePalette.void.opacity(0.38), in: RoundedRectangle(cornerRadius: 12))
                }
            }
        }
        .oraclePageSurface()
    }
}

struct OracleAssistantView: View {
    @ObservedObject var store: OracleWorkspaceStore
    @ObservedObject private var voice: OracleVoiceController
    @ObservedObject private var dictation: OracleDictationController
    @State private var interruptionToken: UUID?

    init(store: OracleWorkspaceStore) {
        self.store = store
        _voice = ObservedObject(wrappedValue: store.voiceController)
        _dictation = ObservedObject(wrappedValue: store.dictationController)
    }

    private var conversationPhase: OracleConversationPhase {
        OracleConversationPerformance.phase(.init(
            microphoneStarting: dictation.isStarting,
            microphoneCapturing: dictation.isListening,
            modelStreaming: store.modelState == .streaming,
            voicePreparing: voice.state == .preparing,
            voicePlaying: voice.isSpeaking,
            interrupted: interruptionToken != nil,
            failed: voice.state == .failed || dictation.lastError != nil ||
                store.modelState == .failed || store.modelState == .timeout || store.modelState == .unavailable
        ))
    }

    private var humanoidPose: OracleHumanoidPose {
        switch OracleConversationPerformance.visualMode(conversationPhase) {
        case .listening: return .listening
        case .thinking: return .thinking
        case .speaking: return .speaking
        default: return .idle
        }
    }

    private var latestAssistantText: String {
        store.messages.last(where: { $0.role == "assistant" && !$0.text.isEmpty })?.text
            ?? "Hello. I am Oracle. This is a local speech audition using the macOS system voice, not the Fish Audio voice."
    }

    private var effectiveMaskExpression: OracleMaskExpression? {
        if conversationPhase == .speaking { return store.modelBehaviorExpression ?? .speaking }
        if conversationPhase == .listening { return .attentive }
        if conversationPhase == .processing { return .curious }
        return store.maskExpression
    }

    private var expressionLabel: String {
        effectiveMaskExpression?.rawValue ?? OracleMotionEngine.expression(for: store.motionMode).rawValue
    }

    private func triggerGesture(_ cue: OracleGestureCue) {
        store.gestureCue = cue
        Task { @MainActor in
            try? await Task.sleep(for: .seconds(4))
            if store.gestureCue == cue { store.gestureCue = .none }
        }
    }

    private func markInterrupted() {
        let token = UUID()
        interruptionToken = token
        Task { @MainActor in
            try? await Task.sleep(for: .milliseconds(450))
            if interruptionToken == token { interruptionToken = nil }
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(alignment: .top, spacing: 12) {
                OracleSectionHeading(
                    eyebrow: "Local intelligence",
                    title: "Oracle workspace",
                    detail: "Bounded local conversation with explicit evidence context."
                )
                Spacer(minLength: 8)
                Button("Immersive") { store.setPresentationMode(.immersive) }
                    .accessibilityLabel("Enter immersive Oracle")
                Button("Compact") { store.setPresentationMode(.compact) }
                    .accessibilityLabel("Open compact Oracle companion in the same window")
            }
            .buttonStyle(.bordered)
            HSplitView {
                VStack(spacing: 10) {
                    Group {
                        if store.show3DCandidate {
                            Oracle3DCandidateView()
                        } else {
                            OracleHumanoidView(
                                pose: humanoidPose,
                                measuredVoiceAmplitude: voice.measuredAmplitude,
                                speechProgress: voice.speechProgress,
                                motionMode: store.motionMode,
                                gesture: store.gestureCue,
                                expressionOverride: effectiveMaskExpression
                            )
                        }
                    }
                    .frame(minWidth: 360, idealWidth: 600, maxWidth: .infinity, minHeight: 620, maxHeight: 900)

                    Button(store.show3DCandidate ? "Show approved reference" : "View 3D mesh candidate") {
                        store.show3DCandidate.toggle()
                    }
                    .buttonStyle(.bordered)
                    Button("Play ElevenLabs voice sample") {
                        dictation.stop()
                        voice.playElevenLabsAudition()
                    }
                    .buttonStyle(.bordered)

                    HStack(spacing: 8) {
                        Button("Greet") {
                            triggerGesture(.wave)
                            voice.speakLocal("Hello. I am Oracle, your local security and operations workspace.")
                        }
                        .buttonStyle(.bordered).tint(OraclePalette.gold)
                        Button(dictation.isStarting ? "Cancel dictation check" :
                            (dictation.isListening ? (store.voiceConversationEnabled ? "Send voice" : "Stop listening") : "Listen on-device")) {
                            if dictation.isStarting {
                                dictation.stop()
                                markInterrupted()
                            } else if dictation.isListening {
                                let finalTranscript = dictation.transcript
                                dictation.stop()
                                if store.voiceConversationEnabled { store.send(finalTranscript) }
                            } else {
                                voice.stop() // Prevent local reply audio from becoming microphone input.
                                dictation.start { transcript in store.setDraft(transcript) }
                            }
                        }
                        .buttonStyle(.bordered)
                        Spacer()
                    }

                    HStack(spacing: 8) {
                        Button(store.motionMode == .runway ? "Stop image sway study" : "Image sway study") {
                            store.motionMode = store.motionMode == .runway ? .idle : .runway
                        }
                        .buttonStyle(.bordered).tint(OraclePalette.gold)
                        Menu("Hand light cue: \(store.gestureCue.rawValue)") {
                            ForEach(OracleGestureCue.allCases) { cue in
                                Button(cue.rawValue) { triggerGesture(cue) }
                            }
                        }
                        Menu("Mask light cue: \(expressionLabel)") {
                            Button("Automatic") { store.maskExpression = nil }
                            ForEach(OracleMaskExpression.allCases) { expression in
                                Button(expression.rawValue) { store.maskExpression = expression }
                            }
                        }
                        Spacer()
                    }

                    VStack(alignment: .leading, spacing: 3) {
                        Text("Conversation state: \(conversationPhase.rawValue)")
                            .font(.caption2.monospaced())
                            .foregroundStyle(OraclePalette.coolText.opacity(0.7))
                        Text("Voice: \(voice.state.label) • \(voice.sourceLabel)")
                            .font(.caption2.weight(.semibold))
                            .foregroundStyle(voice.state == .failed ? OraclePalette.danger : OraclePalette.coolText.opacity(0.7))
                        Text(dictation.statusDetail)
                            .font(.caption2)
                            .foregroundStyle(OraclePalette.coolText.opacity(0.6))
                        if let error = voice.lastError ?? dictation.lastError {
                            Text(error)
                                .font(.caption2)
                                .foregroundStyle(OraclePalette.warning)
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)

                    Toggle("Voice conversation • local speech for completed Qwen replies", isOn: $store.voiceConversationEnabled)
                        .font(.caption)
                    Toggle("Mute Oracle output", isOn: Binding(
                        get: { voice.isMuted },
                        set: { voice.setMuted($0); if $0 { store.cancelModelBehavior() } }
                    ))
                    .font(.caption)
                    .accessibilityHint("Stops Oracle audio and pending voice requests; microphone listening is controlled separately")
                    Text("Push to talk, then Send voice. The microphone stays off between turns. Replies use the labeled macOS voice; Fish remains a separate audition.")
                        .font(.caption2)
                        .foregroundStyle(OraclePalette.coolText.opacity(0.62))
                    Button("Stop conversation") {
                        dictation.stop()
                        store.cancelRequest()
                        voice.stop()
                        store.cancelModelBehavior()
                        store.voiceConversationEnabled = false
                        markInterrupted()
                    }
                    .buttonStyle(.bordered)
                    .disabled(!dictation.isStarting && !dictation.isListening && store.modelState != .streaming && !voice.isSpeaking && voice.state != .preparing)
                }

                VStack(alignment: .leading, spacing: 12) {
                    HStack {
                        Text("Conversation").font(.headline).foregroundStyle(OraclePalette.lavender)
                        Spacer()
                        Button(store.transcriptCollapsed ? "Show transcript" : "Hide transcript") {
                            store.transcriptCollapsed.toggle()
                        }
                        .buttonStyle(.bordered)
                        .accessibilityLabel(store.transcriptCollapsed ? "Expand Oracle transcript" : "Collapse Oracle transcript")
                    }
                    HStack {
                        OracleStatusPill(
                            title: store.providerState.label,
                            color: store.providerState == .available ? OraclePalette.good : OraclePalette.warning,
                            symbol: store.providerState == .available ? "bolt.horizontal.circle.fill" : "bolt.slash"
                        )
                        Spacer()
                        Button {
                            store.refreshModels()
                        } label: {
                            Image(systemName: "arrow.clockwise")
                        }
                        .buttonStyle(.borderless)
                        .help("Re-query installed local Ollama models")
                        Text(store.settings.modelID)
                            .font(.caption.monospaced())
                            .foregroundStyle(OraclePalette.coolText.opacity(0.72))
                            .lineLimit(1)
                    }
                    Text(store.providerDetail)
                        .font(.footnote)
                        .foregroundStyle(OraclePalette.coolText.opacity(0.7))

                    Toggle("Allow Qwen in-app tools this session", isOn: Binding(
                        get: { store.settings.allowModelToolRequests },
                        set: { store.setModelToolsEnabled($0) }
                    ))
                    .font(.caption)
                    Toggle("Also allow Qwen to navigate Oracle pages", isOn: Binding(
                        get: { store.settings.allowModelToolRequests && !store.settings.readOnlyToolsOnly },
                        set: { store.setInAppNavigationEnabled($0) }
                    ))
                    .font(.caption)
                    .disabled(!store.settings.allowModelToolRequests)
                    Text("Qwen receives typed status and optional page-navigation tools. A bounded speech-cue tool is offered only when automatic local reply speech is on and output unmuted. A cue requires a matching phrase in the spoken reply and drives only the current reference's light; articulated 3D gestures remain unavailable. Attached notes or findings disable navigation for that request. It cannot run shell commands, change files or approve system actions. Tool access resets when Oracle restarts.")
                        .font(.caption2)
                        .foregroundStyle(OraclePalette.coolText.opacity(0.62))
                    Text(store.lastCommandReceipt)
                        .font(.caption2.monospaced())
                        .foregroundStyle(OraclePalette.coolText.opacity(0.7))

                    if let sessionError = store.chatSessionError {
                        Text(sessionError)
                            .font(.caption)
                            .foregroundStyle(OraclePalette.warning)
                    }

                    if let security = store.securityContext {
                        HStack(spacing: 8) {
                            Image(systemName: "shield.lefthalf.filled").foregroundStyle(OraclePalette.warning)
                            VStack(alignment: .leading, spacing: 2) {
                                Text("Redacted security finding attached").font(.caption.weight(.semibold))
                                Text(security.title).font(.caption2).foregroundStyle(.secondary).lineLimit(1)
                            }
                            Spacer()
                            Button("Clear") { store.securityContext = nil }
                                .buttonStyle(.borderless)
                                .controlSize(.small)
                        }
                        .padding(9)
                        .background(OraclePalette.warning.opacity(0.12), in: RoundedRectangle(cornerRadius: 9))
                        .overlay(RoundedRectangle(cornerRadius: 9).stroke(OraclePalette.warning.opacity(0.35)))
                        .accessibilityLabel("Attached security finding \(security.title). Model has no execution authority.")
                    }

                    if let context = store.obsidianContext {
                        HStack(spacing: 8) {
                            Image(systemName: "books.vertical.fill").foregroundStyle(OraclePalette.magenta)
                            VStack(alignment: .leading, spacing: 2) {
                                Text("Obsidian context attached").font(.caption.weight(.semibold))
                                Text(context.relativePath).font(.caption2).foregroundStyle(.secondary).lineLimit(1)
                            }
                            Spacer()
                            Button("Clear") { store.clearObsidianContext() }
                                .buttonStyle(.borderless)
                                .controlSize(.small)
                        }
                        .padding(9)
                        .background(OraclePalette.violet.opacity(0.18), in: RoundedRectangle(cornerRadius: 9))
                        .overlay(RoundedRectangle(cornerRadius: 9).stroke(OraclePalette.magenta.opacity(0.34)))
                        .accessibilityLabel("Attached Obsidian note \(context.relativePath). Untrusted read-only context.")
                    }

                    Divider().overlay(OraclePalette.lavender.opacity(0.12))

                    if !store.transcriptCollapsed {
                    VStack(alignment: .leading, spacing: 10) {
                        if store.messages.isEmpty {
                            Text("Ask Oracle about the current security posture or an explicitly attached Obsidian note.")
                                .font(.footnote)
                                .foregroundStyle(OraclePalette.coolText.opacity(0.62))
                                .padding(.vertical, 8)
                        }
                        ForEach(store.messages) { message in
                            VStack(alignment: .leading, spacing: 5) {
                                HStack {
                                    Text(message.role.uppercased())
                                        .font(.caption2.weight(.bold)).tracking(1)
                                        .foregroundStyle(message.role == "assistant" ? OraclePalette.ember : OraclePalette.magenta)
                                    Spacer()
                                    if let provider = message.providerID, let model = message.modelID {
                                        Text("\(provider) • \(model)").font(.caption2).foregroundStyle(.secondary)
                                    }
                                }
                                if message.text.isEmpty && message.state == .streaming {
                                    HStack(spacing: 8) {
                                        ProgressView().controlSize(.small)
                                        Text("Oracle is responding locally…")
                                    }
                                    .font(.body)
                                    .foregroundStyle(OraclePalette.coolText.opacity(0.7))
                                } else if message.text.isEmpty && message.state == .cancelled {
                                    Text("Request cancelled. Your message is preserved.")
                                        .font(.body)
                                        .foregroundStyle(OraclePalette.warning)
                                } else {
                                    Text(message.text)
                                        .font(.body)
                                        .foregroundStyle(OraclePalette.coolText.opacity(0.88))
                                        .textSelection(.enabled)
                                }
                            }
                            .padding(12)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(
                                message.role == "assistant"
                                    ? OraclePalette.deepPurple.opacity(0.42)
                                    : OraclePalette.violet.opacity(0.22),
                                in: RoundedRectangle(cornerRadius: 12)
                            )
                            .overlay(RoundedRectangle(cornerRadius: 12).stroke(OraclePalette.lavender.opacity(0.1)))
                        }
                    }
                    }

                    HStack(spacing: 8) {
                        TextField(
                            "Ask Oracle for a bounded local read-only summary",
                            text: Binding(get: { store.draft }, set: { store.setDraft($0) })
                        )
                            .textFieldStyle(.plain)
                            .padding(.horizontal, 12).padding(.vertical, 9)
                            .background(OraclePalette.void.opacity(0.5), in: RoundedRectangle(cornerRadius: 10))
                            .overlay(RoundedRectangle(cornerRadius: 10).stroke(OraclePalette.lavender.opacity(0.16)))
                        if store.modelState == .streaming {
                            Button("Cancel") {
                                store.cancelRequest()
                                markInterrupted()
                            }
                                .buttonStyle(.bordered)
                                .tint(OraclePalette.warning)
                        } else {
                            Button("Send") {
                                dictation.stop()
                                store.send(store.draft)
                            }
                                .buttonStyle(.borderedProminent)
                                .tint(OraclePalette.violet)
                                .disabled(store.draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                        }
                    }

                    HStack(spacing: 8) {
                        Button("Local audition") {
                            voice.speakLocal(latestAssistantText)
                        }
                        .buttonStyle(.bordered)
                        Button("Fish audition") {
                            voice.speakFish(latestAssistantText)
                        }
                        .buttonStyle(.bordered)
                        .disabled(!voice.fishReady || !voice.fishDisclosureAccepted)
                        Button("Stop voice") {
                            voice.stop()
                            store.cancelModelBehavior()
                            markInterrupted()
                        }
                            .buttonStyle(.borderless)
                            .disabled(!voice.isSpeaking && voice.state != .preparing)
                        Spacer()
                    }
                    Toggle("External Fish Audio disclosure accepted for this app session", isOn: $voice.fishDisclosureAccepted)
                        .font(.caption)
                    Text("Fish Audio is a third-party service. Its free model may use requests to improve quality; no TTFA, DPA, or SLA is assumed. Private text is never sent unless you accept this disclosure and press Fish audition. The voice model must be original Voice Design output, never a cloned performer.")
                        .font(.caption2)
                        .foregroundStyle(OraclePalette.coolText.opacity(0.58))
                }
                .padding(16)
                .background(OraclePalette.void.opacity(0.34), in: RoundedRectangle(cornerRadius: 16))
                .overlay(RoundedRectangle(cornerRadius: 16).stroke(OraclePalette.lavender.opacity(0.1)))
                .frame(minWidth: 300, idealWidth: 390, maxWidth: .infinity)
            }
        }
        .oraclePageSurface()
    }
}

struct FindingsView: View {
    @ObservedObject var store: OracleWorkspaceStore
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            OracleSectionHeading(eyebrow: "Evidence-backed findings", title: "Findings", detail: "Only findings with observed supporting evidence belong here.")
            if store.findings.isEmpty {
                ContentUnavailableView("No open findings", systemImage: "checkmark.shield", description: Text("No current finding is asserted. Absence of a finding is not proof of protection."))
                    .frame(maxWidth: .infinity, minHeight: 240)
            } else {
                ForEach(store.findings) { finding in
                    VStack(alignment: .leading, spacing: 6) {
                        Text(finding.title).font(.headline).foregroundStyle(OraclePalette.lavender)
                        Text(finding.rationale).font(.footnote).foregroundStyle(OraclePalette.coolText.opacity(0.72))
                        Text("\(finding.severity.rawValue.uppercased()) • \(finding.status.rawValue.capitalized)")
                            .font(.caption.weight(.semibold)).foregroundStyle(OraclePalette.ember)
                    }
                    .padding(13)
                    .background(OraclePalette.void.opacity(0.38), in: RoundedRectangle(cornerRadius: 12))
                }
            }
        }
        .oraclePageSurface()
    }
}

struct TimelineView: View {
    @ObservedObject var store: OracleWorkspaceStore
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            OracleSectionHeading(eyebrow: "Observed chronology", title: "Timeline", detail: "Timestamped local events with source attribution.")
            if store.timeline.isEmpty && store.protectionEvents.isEmpty {
                ContentUnavailableView("No events observed", systemImage: "clock.badge.questionmark", description: Text("No timeline events are currently available."))
                    .frame(maxWidth: .infinity, minHeight: 220)
            } else {
                VStack(spacing: 0) {
                    ForEach(store.protectionEvents) { event in
                        HStack(alignment: .top, spacing: 12) {
                            Circle().fill(event.severity == .info ? OraclePalette.electricPurple : OraclePalette.warning).frame(width: 8, height: 8).padding(.top, 6)
                            VStack(alignment: .leading, spacing: 3) {
                                Text(event.kind.replacingOccurrences(of: "_", with: " ").capitalized)
                                    .font(.headline).foregroundStyle(OraclePalette.lavender)
                                Text(event.observedAt.formatted(date: .abbreviated, time: .standard))
                                    .font(.caption).foregroundStyle(OraclePalette.coolText.opacity(0.58))
                                Text(event.summary).font(.footnote).foregroundStyle(OraclePalette.coolText.opacity(0.78))
                                Text("\(event.source) • \(event.resource)").font(.caption2).foregroundStyle(OraclePalette.coolText.opacity(0.52)).textSelection(.enabled)
                            }
                            Spacer()
                        }
                        .padding(.vertical, 10)
                        .overlay(alignment: .bottom) { Rectangle().fill(OraclePalette.lavender.opacity(0.08)).frame(height: 1) }
                    }
                    ForEach(store.timeline) { event in
                        HStack(alignment: .top, spacing: 12) {
                            Circle().fill(OraclePalette.electricPurple).frame(width: 8, height: 8).padding(.top, 6)
                            VStack(alignment: .leading, spacing: 3) {
                                Text(event.kind.replacingOccurrences(of: "_", with: " ").capitalized)
                                    .font(.headline).foregroundStyle(OraclePalette.lavender)
                                Text(event.occurredAt.formatted(date: .abbreviated, time: .standard))
                                    .font(.caption).foregroundStyle(OraclePalette.coolText.opacity(0.58))
                                Text(event.summary).font(.footnote).foregroundStyle(OraclePalette.coolText.opacity(0.78))
                            }
                            Spacer()
                        }
                        .padding(.vertical, 10)
                        .overlay(alignment: .bottom) { Rectangle().fill(OraclePalette.lavender.opacity(0.08)).frame(height: 1) }
                    }
                }
            }
        }
        .oraclePageSurface()
    }
}

struct EvidenceView: View {
    @ObservedObject var store: OracleWorkspaceStore
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            OracleSectionHeading(eyebrow: "Local integrity", title: "Evidence", detail: "Evidence is preserved locally and indexed with SHA-256 values.")
            if store.evidence.isEmpty {
                ContentUnavailableView("No evidence indexed", systemImage: "externaldrive.badge.questionmark", description: Text("No local evidence files are present in the current evidence folder."))
                    .frame(maxWidth: .infinity, minHeight: 220)
            } else {
                ForEach(store.evidence) { item in
                    VStack(alignment: .leading, spacing: 5) {
                        Text(URL(fileURLWithPath: item.path).lastPathComponent).font(.headline).foregroundStyle(OraclePalette.lavender)
                        Text(item.path).font(.caption).foregroundStyle(OraclePalette.coolText.opacity(0.6)).textSelection(.enabled)
                        Text(item.sha256).font(.caption2.monospaced()).foregroundStyle(OraclePalette.ember.opacity(0.8)).textSelection(.enabled)
                        Text("\(item.kind) • \(item.observedAt.formatted())")
                            .font(.caption2).foregroundStyle(OraclePalette.coolText.opacity(0.58))
                    }
                    .padding(12)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(OraclePalette.void.opacity(0.38), in: RoundedRectangle(cornerRadius: 12))
                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(OraclePalette.lavender.opacity(0.1)))
                }
            }
        }
        .oraclePageSurface()
    }
}

struct PermissionsView: View {
    @ObservedObject var store: OracleWorkspaceStore
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            OracleSectionHeading(eyebrow: "Coverage boundaries", title: "Permissions", detail: "Observed authorization state and confidence limits.")
            if store.permissionStates.isEmpty {
                ContentUnavailableView("Permission state unknown", systemImage: "lock.badge.questionmark", description: Text("No permission observation is available."))
                    .frame(maxWidth: .infinity, minHeight: 220)
            } else {
                ForEach(store.permissionStates) { item in
                    HStack(alignment: .top, spacing: 12) {
                        Image(systemName: item.status == "AUTHORIZED" ? "checkmark.shield.fill" : "lock.trianglebadge.exclamationmark")
                            .font(.title3)
                            .foregroundStyle(item.status == "AUTHORIZED" ? OraclePalette.good : OraclePalette.warning)
                        VStack(alignment: .leading, spacing: 4) {
                            Text(item.name).font(.headline).foregroundStyle(OraclePalette.lavender)
                            Text("\(item.status) • \(item.detail)").font(.footnote).foregroundStyle(OraclePalette.coolText.opacity(0.78))
                            Text("Confidence: \(item.confidence.label) • \(item.observedAt.formatted())")
                                .font(.caption).foregroundStyle(OraclePalette.coolText.opacity(0.56))
                        }
                        Spacer()
                    }
                    .padding(13)
                    .background(OraclePalette.void.opacity(0.38), in: RoundedRectangle(cornerRadius: 12))
                }
            }
        }
        .oraclePageSurface()
    }
}

struct NetworkView: View {
    @ObservedObject var store: OracleWorkspaceStore
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
                OracleSectionHeading(eyebrow: "Read-only observation", title: "Network", detail: "VPN service, default-route interface, and DNS resolver count are observed; tunnel ownership, leak protection, and packet filtering are not inferred.")
            if store.networkProtection.isEmpty {
                ContentUnavailableView("No VPN service observed", systemImage: "network.slash", description: Text("No connected or configured VPN service is asserted."))
                    .frame(maxWidth: .infinity, minHeight: 220)
            } else {
                ForEach(store.networkProtection) { item in
                    VStack(alignment: .leading, spacing: 5) {
                        HStack {
                            Text(item.name).font(.headline).foregroundStyle(OraclePalette.lavender)
                            Spacer()
                            OracleStatusPill(
                                title: item.state,
                                color: item.state == "Connected" ? OraclePalette.good : .secondary,
                                symbol: item.state == "Connected" ? "link.circle.fill" : "link.circle"
                            )
                        }
                        Text("\(item.kind) • \(item.method) • observed \(item.observedAt.formatted(date: .abbreviated, time: .standard))")
                            .font(.caption).foregroundStyle(OraclePalette.coolText.opacity(0.62))
                        Text("Default-route interface: \(item.defaultRouteInterface ?? "unknown") • DNS resolvers observed: \(item.dnsResolverCount.map(String.init) ?? "unknown")")
                            .font(.caption).foregroundStyle(OraclePalette.coolText.opacity(0.62))
                        ForEach(item.limitations, id: \.self) { limitation in
                            Text("• \(limitation)").font(.caption).foregroundStyle(OraclePalette.coolText.opacity(0.54))
                        }
                    }
                    .padding(13)
                    .background(OraclePalette.void.opacity(0.38), in: RoundedRectangle(cornerRadius: 12))
                }
            }
        }
        .oraclePageSurface()
    }
}

struct SettingsView: View {
    @ObservedObject var store: OracleWorkspaceStore
    @ObservedObject private var voice: OracleVoiceController
    @State private var confirmExpiredCleanup = false
    @State private var confirmVoiceDesign = false
    @State private var fishKeyInput = ""
    @State private var voiceIDInput = ""
    @State private var voiceDescription = "A warm, confident original adult feminine voice with a subtle silver-rimmed brightness, natural pacing, precise diction, and restrained emotional range."
    @State private var voicePreview = "I am Oracle. Systems are observed, evidence is preserved, and consequential actions remain under your control."
    @State private var configurationMessage: String?

    init(store: OracleWorkspaceStore) {
        self.store = store
        _voice = ObservedObject(wrappedValue: store.voiceController)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            OracleSectionHeading(eyebrow: "Local configuration", title: "Settings", detail: "Current supported provider, model, and authority boundaries.")
            VStack(spacing: 0) {
                InfoRow(key: "Model provider", value: store.settings.modelProviderID)
                InfoRow(key: "Model", value: store.settings.modelID)
                InfoRow(key: "Model availability", value: store.installedModels.contains(store.settings.modelID) ? "Installed and selectable" : "Configured but not currently installed")
                InfoRow(key: "Cloud fallback", value: "Disabled")
                InfoRow(key: "Tools", value: store.settings.allowModelToolRequests ? "Allowed" : "Disabled")
                InfoRow(key: "Read-only tools", value: store.settings.readOnlyToolsOnly ? "Yes" : "No")
                InfoRow(key: "Obsidian vault", value: store.obsidianVaultPath == nil ? "Not configured" : URL(fileURLWithPath: store.obsidianVaultPath!).lastPathComponent)
                InfoRow(key: "Scan engine", value: ProtectionEngine.hasMaintainedEngine() ? "Local engine found; provenance unverified" : "Deterministic scanner only; maintained engine missing")
                InfoRow(key: "Camera storage", value: "AES-GCM encrypted; key held in Keychain")
                InfoRow(key: "Camera state", value: store.securityState)
                InfoRow(key: "Embodiment protocol", value: OracleEmbodimentProtocolVersion.current)
                InfoRow(key: "Raspberry Pi embodiment", value: "Not paired • 0 of \(OracleEmbodimentReadiness.requiredCapabilities.count) capabilities verified")
            }
            HStack(spacing: 10) {
                Text("Local reasoning model").font(.caption.weight(.semibold)).foregroundStyle(OraclePalette.coolText.opacity(0.76))
                Picker("", selection: Binding(get: { store.settings.modelID }, set: { store.selectModel($0) })) {
                    if store.installedModels.isEmpty {
                        Text("\(store.settings.modelID) (not currently available)").tag(store.settings.modelID)
                    } else {
                        ForEach(store.installedModels, id: \.self) { model in
                            Text(model).tag(model)
                        }
                    }
                }
                .labelsHidden()
                .frame(minWidth: 220, maxWidth: 360)
                Button("Refresh models") { store.refreshModels() }
                    .buttonStyle(.bordered)
                Spacer()
                Text(store.providerDetail)
                    .font(.caption2)
                    .foregroundStyle(OraclePalette.coolText.opacity(0.58))
                    .lineLimit(2)
            }
            HStack {
                Text("Camera evidence retention").font(.caption).foregroundStyle(OraclePalette.coolText.opacity(0.72))
                Picker("", selection: Binding(get: { store.cameraRetentionDays }, set: { store.setCameraRetentionDays($0) })) {
                    Text("1 day").tag(1)
                    Text("3 days").tag(3)
                    Text("7 days").tag(7)
                    Text("14 days").tag(14)
                    Text("30 days").tag(30)
                }
                .labelsHidden().frame(width: 130)
                Spacer()
                Text("\(store.expiredCameraEvidenceCount) expired").font(.caption2).foregroundStyle(OraclePalette.coolText.opacity(0.55))
                Button("Move expired to Trash…") { confirmExpiredCleanup = true }
                    .buttonStyle(.bordered)
                    .disabled(store.expiredCameraEvidenceCount == 0)
            }
            Divider().overlay(OraclePalette.lavender.opacity(0.12))
            VStack(alignment: .leading, spacing: 10) {
                Text("Oracle voice").font(.headline).foregroundStyle(OraclePalette.lavender)
                Text("Reasoning and voice are separate. Qwen reasons over text; Fish Audio, when configured and explicitly used, synthesizes the original voice. Local macOS speech is available as a clearly labeled audition fallback and is not presented as the Fish voice.")
                    .font(.footnote).foregroundStyle(OraclePalette.coolText.opacity(0.64))
                InfoRow(key: "Fish configured", value: voice.fishKeyConfigured ? "API key found in Keychain" : "Not configured")
                InfoRow(key: "Original voice ID", value: voice.fishVoiceID.isEmpty ? "Not configured" : voice.fishVoiceID)
                InfoRow(key: "Fish TTS model", value: FishAudioRequestBuilder.ttsModel)
                InfoRow(key: "Voice design model", value: FishAudioRequestBuilder.voiceDesignModel)

                HStack(spacing: 10) {
                    SecureField("Fish API key (write-only; stored in Keychain)", text: $fishKeyInput)
                        .textFieldStyle(.roundedBorder)
                    TextField("Original Fish voice model ID", text: $voiceIDInput)
                        .textFieldStyle(.roundedBorder)
                    Button("Save secure config") {
                        do {
                            if !fishKeyInput.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                                try voice.saveFishKey(fishKeyInput)
                                fishKeyInput = ""
                            }
                            voice.saveFishVoiceID(voiceIDInput)
                            configurationMessage = "Fish configuration updated. The API key value is not displayed or logged."
                        } catch {
                            configurationMessage = error.localizedDescription
                        }
                    }
                    .buttonStyle(.borderedProminent).tint(OraclePalette.violet)
                }
                if voice.fishKeyConfigured {
                    Button("Remove Fish API key from Keychain") {
                        do {
                            try voice.removeFishKey()
                            configurationMessage = "Fish API key removed from Keychain."
                        } catch {
                            configurationMessage = error.localizedDescription
                        }
                    }
                    .buttonStyle(.borderless)
                    .foregroundStyle(OraclePalette.warning)
                }
                Toggle("I authorize external Fish Audio text transmission for this app session", isOn: $voice.fishDisclosureAccepted)
                    .font(.caption)
                TextEditor(text: $voiceDescription)
                    .frame(minHeight: 58, maxHeight: 82)
                    .font(.caption)
                    .padding(5)
                    .background(OraclePalette.void.opacity(0.38), in: RoundedRectangle(cornerRadius: 8))
                TextEditor(text: $voicePreview)
                    .frame(minHeight: 42, maxHeight: 60)
                    .font(.caption)
                    .padding(5)
                    .background(OraclePalette.void.opacity(0.38), in: RoundedRectangle(cornerRadius: 8))
                HStack(spacing: 9) {
                    Button("Create original Voice Design audition…") { confirmVoiceDesign = true }
                        .buttonStyle(.bordered)
                        .disabled(!voice.fishKeyConfigured || !voice.fishDisclosureAccepted)
                    Button("Local speech audition") {
                        voice.speakLocal(voicePreview.isEmpty ? latestFallbackAudition : voicePreview)
                    }
                    .buttonStyle(.bordered)
                    Button("Fish speech audition") {
                        voice.speakFish(voicePreview.isEmpty ? latestFallbackAudition : voicePreview)
                    }
                    .buttonStyle(.bordered)
                    .disabled(!voice.fishReady || !voice.fishDisclosureAccepted)
                    Button("Stop") { voice.stop() }
                        .buttonStyle(.borderless)
                    Spacer()
                }
                Text("Voice Design is an external paid request (documented estimate: $0.01 per successful request). No request is sent until the confirmation below is accepted. Do not use a real performer's recording or identity; describe an original voice only. Free-model privacy/data-improvement terms must be reviewed before sending private text.")
                    .font(.caption2).foregroundStyle(OraclePalette.coolText.opacity(0.56))
                if let message = configurationMessage ?? voice.lastError {
                    Text(message).font(.caption).foregroundStyle(OraclePalette.warning)
                }
                if let path = voice.lastVoiceDesignPath {
                    Text("Saved audition: \(path)")
                        .font(.caption2.monospaced()).foregroundStyle(OraclePalette.coolText.opacity(0.6)).textSelection(.enabled)
                }
            }
            Text("Unsupported controls are not shown. Model output has no direct execution authority in this candidate.")
                .font(.caption).foregroundStyle(OraclePalette.coolText.opacity(0.56))
        }
        .oraclePageSurface()
        .onAppear { voiceIDInput = voice.fishVoiceID }
        .confirmationDialog("Move expired encrypted camera evidence to Trash?", isPresented: $confirmExpiredCleanup, titleVisibility: .visible) {
            Button("Move \(store.expiredCameraEvidenceCount) file(s) to Trash", role: .destructive) { store.clearExpiredCameraEvidenceToTrash() }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("This does not automatically delete files. Items are moved to the macOS Trash so they remain recoverable.")
        }
        .confirmationDialog("Create a paid Fish Audio voice-design audition?", isPresented: $confirmVoiceDesign, titleVisibility: .visible) {
            Button("Approve one Voice Design request") {
                voice.designOriginalVoice(instruction: voiceDescription, previewText: voicePreview, spendApproved: true)
            }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("This sends the voice description and preview text to Fish Audio and is estimated at $0.01 per successful request. It must describe an original voice, not clone a performer. The free speech model may use requests to improve model quality.")
        }
    }

    private var latestFallbackAudition: String {
        "I am Oracle. Systems are observed, evidence is preserved, and consequential actions remain under your control."
    }
}

private struct OllamaTags: Codable { let models: [OllamaModel] }
private struct OllamaModel: Codable { let name: String }

@main
struct AgamemnonApplication {
    @MainActor
    static func main() {
        let app = NSApplication.shared
        app.setActivationPolicy(.regular)
        let controller = Agamemnon()
        app.delegate = controller
        app.run()
    }
}
