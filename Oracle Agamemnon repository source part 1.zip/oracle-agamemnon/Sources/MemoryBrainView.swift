import AppKit
import SceneKit
import SwiftUI

final class InteractiveMemoryBrainView: SCNView {
    var onSelectNode: ((String?) -> Void)?
    private var nodeIDs: Set<String> = []
    private var trackingArea: NSTrackingArea?
    private var highlightedNode: SCNNode?
    private var highlightedEmission: CGFloat = 0

    override func updateTrackingAreas() {
        super.updateTrackingAreas()
        if let trackingArea { removeTrackingArea(trackingArea) }
        let area = NSTrackingArea(rect: bounds, options: [.activeInKeyWindow, .mouseMoved, .inVisibleRect], owner: self, userInfo: nil)
        addTrackingArea(area)
        trackingArea = area
    }

    func configureNodeIDs(_ ids: Set<String>) {
        nodeIDs = ids
    }

    override func mouseMoved(with event: NSEvent) {
        let point = convert(event.locationInWindow, from: nil)
        let hit = hitTest(point, options: [.searchMode: SCNHitTestSearchMode.closest.rawValue])
        let candidate = hit.compactMap(\.node).first { $0.name.map(nodeIDs.contains) == true }
        if candidate?.name != highlightedNode?.name {
            if let highlightedNode { highlightedNode.geometry?.firstMaterial?.emission.intensity = highlightedEmission }
            highlightedNode = candidate
            if let candidate {
                highlightedEmission = CGFloat(candidate.geometry?.firstMaterial?.emission.intensity ?? 0.7)
                candidate.geometry?.firstMaterial?.emission.intensity = 2.1
                NSCursor.pointingHand.set()
            } else {
                NSCursor.arrow.set()
            }
        }
    }

    override func mouseDown(with event: NSEvent) {
        let point = convert(event.locationInWindow, from: nil)
        let hit = hitTest(point, options: [.searchMode: SCNHitTestSearchMode.closest.rawValue])
        let nodeName = hit.compactMap(\.node).first { $0.name.map(nodeIDs.contains) == true }?.name
        onSelectNode?(nodeName)
        super.mouseDown(with: event)
    }
}

struct MemoryBrainSceneRepresentable: NSViewRepresentable {
    let graph: MemoryBrainGraph
    @Binding var selectedNodeID: String?
    let animate: Bool
    let reduceTransparency: Bool
    let increaseContrast: Bool
    let resetToken: Int

    final class Coordinator {
        var lastSignature = ""
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeNSView(context: Context) -> InteractiveMemoryBrainView {
        let view = InteractiveMemoryBrainView(frame: .zero, options: nil)
        view.backgroundColor = .clear
        view.antialiasingMode = .multisampling4X
        view.preferredFramesPerSecond = animate ? 30 : 1
        view.allowsCameraControl = true
        view.autoenablesDefaultLighting = false
        view.onSelectNode = { id in
            DispatchQueue.main.async { selectedNodeID = id }
        }
        return view
    }

    func updateNSView(_ view: InteractiveMemoryBrainView, context: Context) {
        let signature = "\(graph.generatedAt.timeIntervalSince1970)|\(selectedNodeID ?? "")|\(animate)|\(reduceTransparency)|\(increaseContrast)|\(resetToken)|\(graph.nodes.count)|\(graph.edges.count)"
        guard signature != context.coordinator.lastSignature else { return }
        context.coordinator.lastSignature = signature
        view.onSelectNode = { id in DispatchQueue.main.async { selectedNodeID = id } }
        view.scene = buildScene()
        view.configureNodeIDs(Set(graph.nodes.filter { $0.kind == .note }.map(\.id)))
        view.rendersContinuously = animate
        view.preferredFramesPerSecond = animate ? 30 : 1
    }

    private func buildScene() -> SCNScene {
        let scene = SCNScene()
        scene.background.contents = NSColor.clear
        let root = scene.rootNode
        let camera = SCNNode()
        camera.camera = SCNCamera()
        camera.camera?.fieldOfView = 52
        camera.camera?.wantsHDR = true
        camera.position = SCNVector3(0, 0.2, 7.4)
        camera.look(at: SCNVector3Zero, up: SCNVector3(0, 1, 0), localFront: SCNVector3(0, 0, -1))
        root.addChildNode(camera)

        let ambient = SCNLight()
        ambient.type = .ambient
        ambient.intensity = increaseContrast ? 420 : 260
        ambient.color = NSColor(calibratedRed: 0.35, green: 0.20, blue: 0.52, alpha: 1)
        let ambientNode = SCNNode()
        ambientNode.light = ambient
        root.addChildNode(ambientNode)

        let key = SCNLight()
        key.type = .omni
        key.intensity = 1_250
        key.color = NSColor(calibratedRed: 0.78, green: 0.22, blue: 1.0, alpha: 1)
        let keyNode = SCNNode()
        keyNode.light = key
        keyNode.position = SCNVector3(2.8, 2.2, 4.5)
        root.addChildNode(keyNode)

        let warm = SCNLight()
        warm.type = .omni
        warm.intensity = 720
        warm.color = NSColor(calibratedRed: 1.0, green: 0.46, blue: 0.20, alpha: 1)
        let warmNode = SCNNode()
        warmNode.light = warm
        warmNode.position = SCNVector3(-3.0, -1.7, 3.2)
        root.addChildNode(warmNode)

        let orbit = SCNNode()
        orbit.name = "memory-orbit"
        root.addChildNode(orbit)

        let hub = makeHubNode()
        hub.name = "memory-hub"
        root.addChildNode(hub)

        if let energyFile = Bundle.main.path(forResource: "OracleEnergyThreeQuarter", ofType: "png"),
           let energyImage = NSImage(contentsOfFile: energyFile) {
            let plane = SCNPlane(width: 3.2, height: 4.8)
            let material = SCNMaterial()
            material.diffuse.contents = energyImage
            material.emission.contents = energyImage
            material.emission.intensity = increaseContrast ? 0.05 : 0.12
            material.transparency = reduceTransparency ? 0.10 : 0.17
            material.isDoubleSided = true
            plane.materials = [material]
            let artwork = SCNNode(geometry: plane)
            artwork.name = "memory-artwork-backdrop"
            artwork.position = SCNVector3(0, 0, -2.15)
            root.addChildNode(artwork)
        }

        let wire = SCNNode(geometry: makeWireGeometry())
        wire.name = "memory-hub-wire"
        root.addChildNode(wire)

        let rings = makeRings()
        root.addChildNode(rings)

        let particles = makeStardust()
        root.addChildNode(particles)

        if let lineNode = makeConnectionLines(edges: graph.edges, alpha: 0.26) {
            let lineParent = SCNNode()
            lineParent.addChildNode(lineNode)
            orbit.addChildNode(lineParent)
        }
        if let selectedNodeID {
            let selectedEdges = Array(graph.edges.filter {
                ($0.from == selectedNodeID || $0.to == selectedNodeID) && $0.kind == .noteLink
            }.prefix(12))
            if let highlighted = makeConnectionLines(edges: selectedEdges, alpha: 0.92) {
                highlighted.name = "selected-memory-links"
                orbit.addChildNode(highlighted)
            }
        }

        for node in graph.nodes where node.kind == .note {
            let sphere = SCNSphere(radius: CGFloat(0.085 + node.weight * 0.055))
            sphere.segmentCount = 28
            let material = SCNMaterial()
            material.lightingModel = .physicallyBased
            material.diffuse.contents = nodeColor(for: node)
            material.metalness.contents = 0.35
            material.roughness.contents = 0.26
            material.emission.contents = nodeColor(for: node)
            material.emission.intensity = selectedNodeID == node.id ? 2.4 : 0.75
            sphere.materials = [material]
            let nodeObject = SCNNode(geometry: sphere)
            nodeObject.name = node.id
            nodeObject.position = SCNVector3(node.position.x, node.position.y, node.position.z)
            nodeObject.scale = selectedNodeID == node.id ? SCNVector3(1.5, 1.5, 1.5) : SCNVector3(1, 1, 1)
            orbit.addChildNode(nodeObject)
        }

        if animate {
            orbit.runAction(.repeatForever(.rotateBy(x: 0, y: .pi * 2, z: 0, duration: 80)))
            rings.childNodes.enumerated().forEach { index, node in
                let duration = 18.0 + Double(index) * 7.0
                node.runAction(.repeatForever(.rotateBy(x: CGFloat.pi / 3, y: CGFloat.pi * 2, z: CGFloat.pi / 5, duration: duration)))
            }
        }
        return scene
    }

    private func makeHubNode() -> SCNNode {
        let parent = SCNNode()
        for offset in [-0.23, 0.23] {
            let sphere = SCNSphere(radius: 0.55)
            sphere.segmentCount = 72
            let material = SCNMaterial()
            material.lightingModel = .physicallyBased
            material.diffuse.contents = NSColor(calibratedRed: 0.070, green: 0.016, blue: 0.135, alpha: reduceTransparency ? 1 : 0.94)
            material.metalness.contents = 0.70
            material.roughness.contents = 0.26
            material.emission.contents = NSColor(calibratedRed: 0.42, green: 0.08, blue: 0.82, alpha: 1)
            material.emission.intensity = 0.66
            sphere.materials = [material]
            let lobe = SCNNode(geometry: sphere)
            lobe.position = SCNVector3(offset, 0, 0)
            lobe.scale = SCNVector3(1.08, 0.80, 0.72)
            parent.addChildNode(lobe)
        }
        return parent
    }

    private func makeWireGeometry() -> SCNGeometry {
        let sphere = SCNSphere(radius: 0.735)
        sphere.segmentCount = 52
        let material = SCNMaterial()
        material.fillMode = .lines
        material.lightingModel = .constant
        material.diffuse.contents = NSColor(calibratedRed: 0.82, green: 0.30, blue: 1.0, alpha: 0.45)
        material.emission.contents = NSColor(calibratedRed: 0.82, green: 0.30, blue: 1.0, alpha: 0.45)
        material.isDoubleSided = true
        sphere.materials = [material]
        return sphere
    }

    private func makeRings() -> SCNNode {
        let parent = SCNNode()
        for index in 0..<3 {
            let radius = 0.92 + CGFloat(index) * 0.18
            let torus = SCNTorus(ringRadius: radius, pipeRadius: 0.006 + CGFloat(index) * 0.002)
            let material = SCNMaterial()
            material.lightingModel = .constant
            let color = index == 1
                ? NSColor(calibratedRed: 1.0, green: 0.48, blue: 0.20, alpha: 0.7)
                : NSColor(calibratedRed: 0.84, green: 0.32, blue: 1.0, alpha: 0.65)
            material.diffuse.contents = color
            material.emission.contents = color
            torus.materials = [material]
            let node = SCNNode(geometry: torus)
            node.eulerAngles = SCNVector3(CGFloat(index + 1) * 0.72, CGFloat(index) * 0.9, CGFloat(index + 1) * 0.42)
            parent.addChildNode(node)
        }
        return parent
    }

    private func makeStardust() -> SCNNode {
        let node = SCNNode()
        let particles = SCNParticleSystem()
        particles.birthRate = (animate && !reduceTransparency) ? 95 : 0
        particles.particleLifeSpan = 4.0
        particles.particleLifeSpanVariation = 1.4
        particles.particleVelocity = 0.20
        particles.particleVelocityVariation = 0.20
        particles.particleSize = 0.028
        particles.particleSizeVariation = 0.018
        particles.particleColor = NSColor(calibratedRed: 0.90, green: 0.58, blue: 1.0, alpha: 0.72)
        particles.particleColorVariation = SCNVector4(0.10, 0.18, 0.04, 0.20)
        particles.emitterShape = SCNSphere(radius: 1.65)
        particles.blendMode = reduceTransparency ? .alpha : .additive
        particles.isAffectedByGravity = false
        particles.particleImage = NSImage(systemSymbolName: "circle.fill", accessibilityDescription: nil)
        node.addParticleSystem(particles)
        return node
    }

    private func makeConnectionLines(edges: [MemoryBrainEdge], alpha: CGFloat) -> SCNNode? {
        guard !edges.isEmpty else { return nil }
        var positions: [SCNVector3] = []
        let positionsByID = Dictionary(uniqueKeysWithValues: graph.nodes.map {
            ($0.id, SCNVector3($0.position.x, $0.position.y, $0.position.z))
        })
        for edge in edges {
            guard let from = positionsByID[edge.from], let to = positionsByID[edge.to] else { continue }
            positions.append(from)
            positions.append(to)
        }
        guard !positions.isEmpty else { return nil }
        let geometry = SCNGeometry(
            sources: [SCNGeometrySource(vertices: positions)],
            elements: [SCNGeometryElement(indices: Array(0..<Int32(positions.count)), primitiveType: .line)]
        )
        let material = SCNMaterial()
        material.lightingModel = .constant
        material.diffuse.contents = NSColor(calibratedRed: 0.64, green: 0.24, blue: 0.96, alpha: alpha * 0.68)
        material.emission.contents = NSColor(calibratedRed: 0.78, green: 0.24, blue: 1.0, alpha: alpha)
        geometry.materials = [material]
        return SCNNode(geometry: geometry)
    }

    private func nodeColor(for node: MemoryBrainNode) -> NSColor {
        let seed = node.folder?.unicodeScalars.reduce(0) { ($0 + Int($1.value)) % 29 } ?? 0
        let warm = seed % 7 == 0
        if warm {
            return NSColor(calibratedRed: 1.0, green: 0.48, blue: 0.20, alpha: 0.95)
        }
        let hue = 0.72 + CGFloat(seed) * 0.007
        return NSColor(calibratedHue: hue, saturation: 0.72, brightness: 1.0, alpha: 0.96)
    }
}

struct MemoryBrainView: View {
    @ObservedObject var store: OracleWorkspaceStore
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @Environment(\.colorSchemeContrast) private var contrast
    @Environment(\.scenePhase) private var scenePhase
    @State private var mode = 0
    @State private var selectedNodeID: String?
    @State private var resetToken = 0

    private var selectedNode: MemoryBrainNode? {
        store.memoryBrainGraph.nodes.first { $0.id == selectedNodeID }
    }

    private var policy: OracleVisualPolicy {
        .make(
            reduceMotion: reduceMotion,
            reduceTransparency: reduceTransparency,
            increaseContrast: contrast == .increased,
            sceneActive: scenePhase == .active
        )
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .firstTextBaseline) {
                OracleSectionHeading(
                    eyebrow: "Obsidian memory lattice",
                    title: "Memory Brain",
                    detail: store.memoryBrainRepresentedNoteCount == 0
                        ? "A live 3D map of the selected Obsidian vault. Links are read from Markdown; unresolved links remain absent."
                        : "\(store.memoryBrainRepresentedNoteCount) of \(store.memoryBrainRepresentedNoteCount + store.memoryBrainSkippedNoteCount) indexed notes represented. Unresolved and ambiguous links remain absent."
                )
                Spacer()
                Picker("Memory view", selection: $mode) {
                    Text("3D Brain").tag(0)
                    Text("Accessible list").tag(1)
                }
                .labelsHidden()
                .pickerStyle(.segmented)
                .frame(width: 230)
                .tint(OraclePalette.violet)
                .accessibilityLabel("Memory brain presentation")
            }

            if store.memoryBrainLoading {
                HStack(spacing: 10) {
                    ProgressView().controlSize(.small)
                    Text("Building memory lattice from the Obsidian vault…").font(.footnote).foregroundStyle(OraclePalette.coolText.opacity(0.72))
                }
                .padding(.vertical, 20)
            } else if store.obsidianVaultPath == nil {
                ContentUnavailableView(
                    "Choose an Obsidian vault",
                    systemImage: "brain.head.profile",
                    description: Text("The Memory Brain is built only from the vault explicitly selected in the Obsidian page.")
                )
                .frame(maxWidth: .infinity, minHeight: 360)
            } else if store.memoryBrainGraph.nodes.count <= 1 {
                ContentUnavailableView(
                    "No memory notes indexed",
                    systemImage: "brain",
                    description: Text("The selected vault has no readable Markdown notes in the bounded memory index.")
                )
                .frame(maxWidth: .infinity, minHeight: 360)
            } else {
                HStack(alignment: .top, spacing: 16) {
                    Group {
                        if mode == 0 {
                            ZStack(alignment: .topTrailing) {
                                MemoryBrainSceneRepresentable(
                                    graph: store.memoryBrainGraph,
                                    selectedNodeID: $selectedNodeID,
                                    animate: policy.animationEnabled && !ProcessInfo.processInfo.isLowPowerModeEnabled,
                                    reduceTransparency: reduceTransparency,
                                    increaseContrast: contrast == .increased,
                                    resetToken: resetToken
                                )
                                .background(
                                    RadialGradient(colors: [OraclePalette.deepPurple.opacity(0.45), OraclePalette.void.opacity(0.92)], center: .center, startRadius: 10, endRadius: 420)
                                )
                                .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                                .overlay(RoundedRectangle(cornerRadius: 20).stroke(OraclePalette.lavender.opacity(policy.borderOpacity)))
                                .accessibilityElement(children: .ignore)
                                .accessibilityLabel("Interactive 3D Obsidian memory brain with \(store.memoryBrainGraph.nodes.filter { $0.kind == .note }.count) notes")
                                .accessibilityValue(selectedNode.map { "Selected \($0.title)" } ?? "No note selected")

                                Button { resetToken += 1 } label: { Label("Reset view", systemImage: "arrow.counterclockwise") }
                                    .labelStyle(.iconOnly)
                                    .buttonStyle(.borderedProminent).tint(OraclePalette.violet)
                                    .padding(12)
                                    .help("Reset memory brain view")
                            }
                            .frame(minWidth: 430, minHeight: 520)
                        } else {
                            MemoryBrainAccessibleList(graph: store.memoryBrainGraph, selectedNodeID: $selectedNodeID)
                                .frame(minWidth: 430, minHeight: 520)
                        }
                    }
                    .frame(maxWidth: .infinity)

                    MemoryBrainInspector(
                        node: selectedNode,
                        graph: store.memoryBrainGraph,
                        onInspect: { node in
                            store.inspectMemoryBrainNote(node)
                            store.section = "Obsidian"
                        },
                        onAttach: { node in
                            store.inspectMemoryBrainNote(node)
                            store.attachObsidianPreviewToOracle()
                        }
                    )
                    .frame(width: 260)
                }
            }
        }
        .oraclePageSurface()
        .onChange(of: store.memoryBrainGraph.generatedAt) { _, _ in
            if selectedNodeID == nil {
                selectedNodeID = store.memoryBrainGraph.nodes.first(where: { $0.kind == .note })?.id
            }
        }
        .onAppear {
            if selectedNodeID == nil {
                selectedNodeID = store.memoryBrainGraph.nodes.first(where: { $0.kind == .note })?.id
            }
        }
    }
}

private struct MemoryBrainAccessibleList: View {
    let graph: MemoryBrainGraph
    @Binding var selectedNodeID: String?

    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 8) {
                ForEach(graph.nodes.filter { $0.kind == .note }) { node in
                    Button { selectedNodeID = node.id } label: {
                        HStack(alignment: .top, spacing: 10) {
                            Image(systemName: "circle.hexagongrid.fill")
                                .foregroundStyle(node.linkCount > 0 ? OraclePalette.magenta : OraclePalette.electricPurple)
                                .frame(width: 22)
                            VStack(alignment: .leading, spacing: 3) {
                                Text(node.title).font(.body.weight(.semibold))
                                Text(node.relativePath ?? node.folder ?? "Vault note").font(.caption).foregroundStyle(.secondary).lineLimit(1)
                                Text("\(node.linkCount) outgoing resolved link(s) • \(node.folder ?? "Vault root")")
                                    .font(.caption2).foregroundStyle(.secondary)
                            }
                            Spacer()
                            if selectedNodeID == node.id { Image(systemName: "checkmark.circle.fill").foregroundStyle(.white) }
                        }
                        .padding(10)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(OraclePalette.void.opacity(0.42), in: RoundedRectangle(cornerRadius: 10))
                        .overlay(RoundedRectangle(cornerRadius: 10).stroke(OraclePalette.lavender.opacity(0.12)))
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("\(node.title), \(node.linkCount) resolved links")
                }
            }
        }
    }
}

private struct MemoryBrainInspector: View {
    let node: MemoryBrainNode?
    let graph: MemoryBrainGraph
    let onInspect: (MemoryBrainNode) -> Void
    let onAttach: (MemoryBrainNode) -> Void

    private var links: [MemoryBrainNode] {
        guard let node else { return [] }
        return graph.edges.compactMap { edge in
            guard edge.kind == .noteLink, edge.from == node.id || edge.to == node.id else { return nil }
            let otherID = edge.from == node.id ? edge.to : edge.from
            return graph.nodes.first { $0.id == otherID }
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            if let node {
                Text(node.title).font(.headline).foregroundStyle(OraclePalette.lavender)
                Text(node.relativePath ?? "Obsidian note").font(.caption).foregroundStyle(.secondary).textSelection(.enabled)
                InfoRow(key: "Folder", value: node.folder ?? "Vault root")
                InfoRow(key: "Outgoing links", value: "\(node.linkCount) resolved")
                InfoRow(key: "Position", value: String(format: "%.2f, %.2f, %.2f", node.position.x, node.position.y, node.position.z))
                if !links.isEmpty {
                    Text("Connected notes").font(.caption.weight(.semibold)).foregroundStyle(OraclePalette.ember)
                    ForEach(links) { linked in
                        Text("• \(linked.title)").font(.caption).foregroundStyle(OraclePalette.coolText.opacity(0.76))
                    }
                }
                Button("Inspect in Obsidian") { onInspect(node) }
                    .buttonStyle(.bordered)
                    .frame(maxWidth: .infinity, alignment: .leading)
                Button("Attach to Oracle") { onAttach(node) }
                    .buttonStyle(.borderedProminent)
                    .tint(OraclePalette.violet)
                    .frame(maxWidth: .infinity, alignment: .leading)
            } else {
                ContentUnavailableView("Select a memory node", systemImage: "circle.dashed", description: Text("Click a note node in the brain or choose one from the accessible list."))
                    .frame(maxWidth: .infinity, minHeight: 260)
            }
        }
        .padding(13)
        .oracleGlassCard(cornerRadius: 14)
    }
}
