import Foundation
import SceneKit

/// Deterministic, opt-in study controller for the existing 24-bone Oracle mesh.
/// It does not provide finger, face, hair, or speech animation.
final class Oracle3DMotionController {
    enum Phase: String {
        case idle
        case walking
        case turning
        case settled
    }

    struct Frame {
        let phase: Phase
        let leftFootPlanted: Bool
        let rightFootPlanted: Bool
        let leftToeTarget: SCNVector3
        let rightToeTarget: SCNVector3
    }

    private struct Step {
        let start: Double
        let end: Double
        let destination: Double
    }

    private let motionRoot: SCNNode
    private let joints: [String: SCNNode]
    private let initialAngles: [String: SCNVector3]
    private let initialPosition: SCNVector3
    private let initialRootAngles: SCNVector3
    private let leftToeInitial: SCNVector3
    private let rightToeInitial: SCNVector3
    private let leftIK: SCNIKConstraint
    private let rightIK: SCNIKConstraint

    private static let leftSteps = [Step(start: 0.12, end: 0.58, destination: 0.24),
                                    Step(start: 1.52, end: 1.98, destination: 0.48)]
    private static let rightSteps = [Step(start: 0.82, end: 1.28, destination: 0.24),
                                     Step(start: 2.22, end: 2.68, destination: 0.48)]

    init?(motionRoot: SCNNode) {
        let names = ["Hips", "Spine02", "Spine01", "Spine", "neck", "Head",
                     "LeftArm", "RightArm", "LeftForeArm", "RightForeArm",
                     "LeftUpLeg", "RightUpLeg", "LeftLeg", "RightLeg",
                     "LeftFoot", "RightFoot", "LeftToeBase", "RightToeBase"]
        var found: [String: SCNNode] = [:]
        for name in names {
            guard let joint = motionRoot.childNode(withName: name, recursively: true) else { return nil }
            found[name] = joint
        }
        self.motionRoot = motionRoot
        self.joints = found
        self.initialAngles = found.mapValues(\.eulerAngles)
        self.initialPosition = motionRoot.position
        self.initialRootAngles = motionRoot.eulerAngles
        self.leftToeInitial = found["LeftToeBase"]!.worldPosition
        self.rightToeInitial = found["RightToeBase"]!.worldPosition

        let leftIK = SCNIKConstraint.inverseKinematicsConstraint(chainRootNode: found["LeftUpLeg"]!)
        let rightIK = SCNIKConstraint.inverseKinematicsConstraint(chainRootNode: found["RightUpLeg"]!)
        for (constraint, prefix) in [(leftIK, "Left"), (rightIK, "Right")] {
            constraint.setMaxAllowedRotationAngle(48, forJoint: found[prefix + "UpLeg"]!)
            constraint.setMaxAllowedRotationAngle(95, forJoint: found[prefix + "Leg"]!)
            constraint.setMaxAllowedRotationAngle(42, forJoint: found[prefix + "Foot"]!)
            constraint.setMaxAllowedRotationAngle(16, forJoint: found[prefix + "ToeBase"]!)
        }
        leftIK.targetPosition = leftToeInitial
        rightIK.targetPosition = rightToeInitial
        found["LeftToeBase"]!.constraints = [leftIK]
        found["RightToeBase"]!.constraints = [rightIK]
        self.leftIK = leftIK
        self.rightIK = rightIK
    }

    func apply(at seconds: TimeInterval, reduceMotion: Bool = false) -> Frame {
        let time = seconds.isFinite ? max(0, min(seconds, 6)) : 0
        let walkTime = max(0, time - 1.0)
        let walking = !reduceMotion && time >= 1.0 && time < 4.15
        let turning = !reduceMotion && time >= 4.15 && time < 5.05
        let phase: Phase = time < 1 || reduceMotion ? .idle : (walking ? .walking : (turning ? .turning : .settled))
        let left = reduceMotion ? (leftToeInitial, true) : Self.footTarget(initial: leftToeInitial, steps: Self.leftSteps, walkTime: walkTime)
        let right = reduceMotion ? (rightToeInitial, true) : Self.footTarget(initial: rightToeInitial, steps: Self.rightSteps, walkTime: walkTime)

        SCNTransaction.begin()
        SCNTransaction.animationDuration = 0
        let approach = reduceMotion ? 0 : Self.rootTravel(walkTime)
        let yaw = reduceMotion ? 0 : 0.28 * Self.smooth((time - 4.15) / 0.75)
        let strideEnvelope = reduceMotion ? 0 : Self.smooth(walkTime / 0.25) * (1 - Self.smooth((time - 3.85) / 0.40))
        let stride = sin(walkTime * 2 * .pi / 1.4) * strideEnvelope
        let breath = reduceMotion ? 0 : sin(time * 1.32)

        motionRoot.position = SCNVector3(initialPosition.x + CGFloat(0.008 * stride),
                                         initialPosition.y + CGFloat(0.008 * abs(stride)),
                                         initialPosition.z + CGFloat(approach))
        motionRoot.eulerAngles = SCNVector3(initialRootAngles.x,
                                            initialRootAngles.y + CGFloat(yaw),
                                            initialRootAngles.z)
        rotate("Hips", y: 0.025 * stride, z: 0.018 * stride)
        rotate("Spine02", y: -0.018 * stride, z: -0.012 * stride)
        rotate("Spine01", x: 0.006 * breath, y: -0.012 * stride)
        rotate("Spine", x: 0.004 * breath)
        rotate("neck", y: -0.025 * yaw)
        rotate("Head", x: 0.009 * sin(time * 0.71), y: -0.10 * yaw + 0.018 * sin(time * 0.44))
        rotate("LeftArm", z: -0.17 * stride)
        rotate("RightArm", z: 0.17 * stride)
        rotate("LeftForeArm", z: 0.05 * max(0, stride))
        rotate("RightForeArm", z: 0.05 * max(0, -stride))

        leftIK.targetPosition = left.0
        rightIK.targetPosition = right.0
        SCNTransaction.commit()
        return Frame(phase: phase, leftFootPlanted: left.1, rightFootPlanted: right.1,
                     leftToeTarget: left.0, rightToeTarget: right.0)
    }

    private func rotate(_ name: String, x: Double = 0, y: Double = 0, z: Double = 0) {
        guard let joint = joints[name], let original = initialAngles[name] else { return }
        joint.eulerAngles = SCNVector3(original.x + CGFloat(x), original.y + CGFloat(y), original.z + CGFloat(z))
    }

    private static func footTarget(initial: SCNVector3, steps: [Step], walkTime: Double) -> (SCNVector3, Bool) {
        var previous = 0.0
        for step in steps {
            if walkTime < step.start { break }
            if walkTime <= step.end {
                let u = smooth((walkTime - step.start) / (step.end - step.start))
                let lift = 0.055 * sin(.pi * u)
                return (SCNVector3(initial.x, initial.y + CGFloat(lift),
                                   initial.z + CGFloat(previous + (step.destination - previous) * u)), false)
            }
            previous = step.destination
        }
        return (SCNVector3(initial.x, initial.y, initial.z + CGFloat(previous)), true)
    }

    private static func rootTravel(_ t: Double) -> Double {
        if t <= 0 { return 0 }
        if t < 0.55 { return 0.055 * smooth(t / 0.55) }
        if t < 2.45 { return 0.055 + 0.36 * ((t - 0.55) / 1.90) }
        if t < 3.10 { return 0.415 + 0.065 * smooth((t - 2.45) / 0.65) }
        return 0.48
    }

    private static func smooth(_ x: Double) -> Double {
        let u = max(0, min(1, x))
        return u * u * (3 - 2 * u)
    }
}
