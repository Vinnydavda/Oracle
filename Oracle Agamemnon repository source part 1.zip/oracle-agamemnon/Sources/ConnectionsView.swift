import SwiftUI

struct ConnectionsView: View {
    @ObservedObject var store: OracleWorkspaceStore
    @State private var applicationsExpanded = false

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            OracleSectionHeading(
                eyebrow: "Verified local connections",
                title: "Devices, apps & projects",
                detail: "Oracle shows only connections it can observe or invoke locally. Launch/open is not control; no app-specific automation is inferred."
            )

            HStack(spacing: 10) {
                Button("Refresh inventory") { store.refreshControlCenterInventory() }
                    .buttonStyle(.borderedProminent).tint(OraclePalette.violet)
                Button("Open Memory Triage") {
                    if let mtt = store.connectedResources.first(where: { $0.id == "app-memory-triage" }) {
                        store.openConnectedResource(mtt)
                    }
                }
                .buttonStyle(.bordered)
                Button("Capture MTT sample") { store.captureMTTSnapshot() }
                    .buttonStyle(.bordered)
                    .disabled(store.integrationBusy)
                if store.integrationBusy { ProgressView().controlSize(.small) }
                Spacer()
            }

            if let error = store.lastIntegrationError {
                Text(error).font(.footnote).foregroundStyle(OraclePalette.warning)
            }

            if let mtt = store.mttBridgeMetadata {
                VStack(alignment: .leading, spacing: 10) {
                    let freshness = ControlCenterIntegrationEngine.mttSampleFreshness(lastCapturedAt: mtt.lastCapturedAt)
                    HStack(alignment: .firstTextBaseline, spacing: 10) {
                        Text("Memory Trinity Triage bridge").font(.headline).foregroundStyle(OraclePalette.lavender)
                        Spacer()
                        Text("PROCESS \(mtt.isRunning ? "RUNNING" : "INSTALLED")")
                            .font(.caption2.weight(.bold)).foregroundStyle(mtt.isRunning ? OraclePalette.good : OraclePalette.warning)
                        Text("SAMPLE \(freshness.label.uppercased())")
                            .font(.caption2.weight(.bold))
                            .foregroundStyle(freshness == .fresh ? OraclePalette.good : (freshness == .stale ? OraclePalette.warning : OraclePalette.coolText.opacity(0.58)))
                    }
                    Text("MTT remains a separate app • version \(mtt.version) build \(mtt.build)")
                        .font(.footnote).foregroundStyle(OraclePalette.coolText.opacity(0.72))
                    Text("Supported bridge: fixed executable with `--monitor-record 1 1`, one-shot JSON, no URL scheme or persistent IPC.")
                        .font(.caption).foregroundStyle(OraclePalette.coolText.opacity(0.62))
                    Text("Session metadata: \(mtt.sessionMessageCount) saved message(s), \(mtt.draftLength) draft character(s), last saved \(mtt.sessionSavedAt?.formatted(date: .abbreviated, time: .standard) ?? "Unknown"). Message bodies are not read.")
                        .font(.caption).foregroundStyle(OraclePalette.coolText.opacity(0.58))
                    if let events = mtt.monitorEventsBytes {
                        Text("Monitor Events.json: \(ByteCountFormatter.string(fromByteCount: Int64(events), countStyle: .file)) • metadata only")
                            .font(.caption2).foregroundStyle(OraclePalette.coolText.opacity(0.52))
                    }
                    if let snapshot = mtt.lastSnapshot {
                        Divider().overlay(OraclePalette.lavender.opacity(0.12))
                        HStack(spacing: 18) {
                            mttMetric("CPU", snapshot.cpuTotal.map { String(format: "%.1f%%", $0) } ?? "Warming up")
                            mttMetric("Memory used", snapshot.memoryUsed.map { ByteCountFormatter.string(fromByteCount: Int64($0), countStyle: .memory) } ?? "Unavailable")
                            mttMetric("Compressed", snapshot.compressed.map { ByteCountFormatter.string(fromByteCount: Int64($0), countStyle: .memory) } ?? "Unavailable")
                            mttMetric("Thermal", snapshot.thermalState)
                            mttMetric("Processes", "\(snapshot.processCount)")
                        }
                        Text("Captured \(mtt.lastCapturedAt?.formatted(date: .abbreviated, time: .standard) ?? "Unknown") • sample \(freshness.label.lowercased()) • network telemetry: \(snapshot.networkStatus) • process telemetry: \(snapshot.processStatus)")
                            .font(.caption2).foregroundStyle(freshness == .stale ? OraclePalette.warning : OraclePalette.coolText.opacity(0.56))
                        Button("Ask Oracle about this sample") { store.attachMTTSampleToOracle() }
                            .buttonStyle(.bordered).controlSize(.small)
                    } else {
                        Text("No live MTT sample captured in Oracle yet.")
                            .font(.caption).foregroundStyle(OraclePalette.warning)
                    }
                }
                .padding(14)
                .background(OraclePalette.void.opacity(0.4), in: RoundedRectangle(cornerRadius: 14))
                .overlay(RoundedRectangle(cornerRadius: 14).stroke(OraclePalette.magenta.opacity(0.28)))
            }

            ForEach(resourceKinds, id: \.self) { kind in
                let resources = store.connectedResources.filter { $0.kind == kind }
                if !resources.isEmpty {
                    resourceSection(kind, resources: resources)
                }
            }

            Text("Oracle does not claim universal control. App launch/open and reveal-in-Finder are available; app lifecycle, remote devices, settings, credentials and arbitrary commands require separate verified integrations and approval.")
                .font(.footnote).foregroundStyle(OraclePalette.warning.opacity(0.9))
        }
        .oraclePageSurface()
        .onAppear { store.refreshControlCenterInventory() }
    }

    private var resourceKinds: [String] {
        ["Device", "Separate app", "Service", "Knowledge", "Security", "Project", "Application"]
    }

    @ViewBuilder
    private func resourceSection(_ kind: String, resources: [ConnectedResource]) -> some View {
        if kind == "Application" {
            DisclosureGroup(isExpanded: $applicationsExpanded) {
                resourceRows(resources)
            } label: {
                HStack {
                    Text("Applications").font(.headline).foregroundStyle(OraclePalette.lavender)
                    Spacer()
                    Text("\(resources.count) observed").font(.caption).foregroundStyle(OraclePalette.coolText.opacity(0.55))
                }
            }
            .padding(12)
            .background(OraclePalette.violet.opacity(0.1), in: RoundedRectangle(cornerRadius: 12))
        } else {
            VStack(alignment: .leading, spacing: 8) {
                Text(kind).font(.headline).foregroundStyle(OraclePalette.lavender)
                resourceRows(resources)
            }
        }
    }

    private func resourceRows(_ resources: [ConnectedResource]) -> some View {
        ForEach(resources) { resource in
            VStack(alignment: .leading, spacing: 5) {
                HStack(alignment: .firstTextBaseline) {
                    Text(resource.name).font(.body.weight(.semibold)).foregroundStyle(OraclePalette.lavender)
                    Spacer()
                    Text(resource.status.uppercased())
                        .font(.caption2.weight(.bold))
                        .foregroundStyle(resource.isRunning ? OraclePalette.good : OraclePalette.warning)
                }
                Text(resource.detail).font(.caption).foregroundStyle(OraclePalette.coolText.opacity(0.68)).textSelection(.enabled)
                if let path = resource.path {
                    Text(path).font(.caption2.monospaced()).foregroundStyle(OraclePalette.coolText.opacity(0.48)).lineLimit(1).textSelection(.enabled)
                }
                if !resource.capabilities.isEmpty {
                    Text(resource.capabilities.joined(separator: " • ")).font(.caption2).foregroundStyle(OraclePalette.coolText.opacity(0.62))
                }
                ForEach(resource.limitations, id: \.self) { limitation in
                    Text("Limit: \(limitation)").font(.caption2).foregroundStyle(OraclePalette.coolText.opacity(0.5))
                }
                if resource.path != nil {
                    HStack(spacing: 10) {
                        Button(resource.path?.hasSuffix(".app") == true ? "Open app" : "Open folder") { store.openConnectedResource(resource) }
                            .buttonStyle(.bordered).controlSize(.small)
                        Button("Reveal") { store.revealConnectedResource(resource) }
                            .buttonStyle(.borderless).controlSize(.small)
                    }
                }
            }
            .padding(11)
            .background(OraclePalette.void.opacity(0.34), in: RoundedRectangle(cornerRadius: 10))
        }
    }

    private func mttMetric(_ title: String, _ value: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title.uppercased()).font(.caption2.weight(.bold)).tracking(0.8).foregroundStyle(OraclePalette.magenta)
            Text(value).font(.caption).foregroundStyle(OraclePalette.coolText.opacity(0.78))
        }
    }
}
