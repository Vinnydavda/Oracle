import Foundation

enum OracleMotionMode: String, CaseIterable, Identifiable {
    case idle = "Idle"
    case runway = "Runway"
    case greeting = "Greeting"
    case listening = "Listening"
    case thinking = "Thinking"
    case speaking = "Speaking"

    var id: String { rawValue }
}

enum OracleGestureCue: String, CaseIterable, Identifiable {
    case none = "None"
    case wave = "Wave"
    case openPalm = "Open palm"
    case point = "Point"
    case handToHeart = "Hand to heart"
    case hairSweep = "Hair sweep"
    case turn = "Turn"
    case bow = "Bow"

    var id: String { rawValue }
}

enum OracleMaskExpression: String, CaseIterable, Identifiable {
    case calm = "Calm"
    case warm = "Warm"
    case attentive = "Attentive"
    case curious = "Curious"
    case confident = "Confident"
    case delighted = "Delighted"
    case speaking = "Speaking"

    var id: String { rawValue }
}

struct OracleMotionFrame: Equatable {
    let bodyOffsetX: Double
    let bodyOffsetY: Double
    let bodyScale: Double
    let bodyRotation: Double
    let perspective: Double
    let hipSway: Double
    let shoulderRoll: Double
    let headTilt: Double
    let hairDrift: Double
    let cameraPush: Double
    let catwalkPulse: Double
    let maskPulse: Double
    let leftHandPulse: Double
    let rightHandPulse: Double
    // Normalized rig channels. The current reference renderer cannot articulate
    // these joints; an approved skinned host can consume them in a later release.
    let leftFootContact: Double
    let rightFootContact: Double
    let leftArmSwing: Double
    let rightArmSwing: Double
    let weightShift: Double
    let gazeX: Double
    let blink: Double
    let jawOpen: Double
    let leftFingerCurl: Double
    let rightFingerCurl: Double
    let expression: OracleMaskExpression
    let gesture: OracleGestureCue
}

enum OracleMotionEngine {
    static func frame(
        mode: OracleMotionMode,
        phase: TimeInterval,
        mouthOpenness: Double,
        speechProgress: Double,
        gesture: OracleGestureCue,
        reduceMotion: Bool,
        sceneActive: Bool
    ) -> OracleMotionFrame {
        let animated = !reduceMotion && sceneActive
        let phase = phase.isFinite ? phase : 0
        let mouth = bounded(mouthOpenness, 0, 1)
        let gesturePulse = animated ? pow(max(0, sin(phase * 5.4)), 2) : 0.55
        let breath = animated ? sin(phase * 1.25) : 0
        let sway = animated ? sin(phase * 1.05) : 0
        let hip = animated ? sin(phase * 4.6) : 0
        let shoulder = animated ? -sin(phase * 4.6 + 0.22) : 0

        var offsetX = sway * 2.2
        var offsetY = breath * 1.2
        var scale = 1 + breath * 0.003
        var rotation = sway * 0.42
        var perspective = sway * 1.8
        var headTilt = shoulder * 0.75
        var hairDrift = animated ? sin(phase * 0.72) : 0
        var cameraPush = 1.0
        var catwalkPulse = 0.0
        var maskPulse = 0.32 + max(0, breath) * 0.05
        var handL = 0.0
        var handR = 0.0
        var expression = expression(for: mode)
        var leftFootContact = 1.0
        var rightFootContact = 1.0
        var leftArmSwing = 0.0
        var rightArmSwing = 0.0
        var weightShift = 0.0
        var leftFingerCurl = 0.42
        var rightFingerCurl = 0.42
        let blinkCycle = phase.truncatingRemainder(dividingBy: 4.7)
        let blink = animated ? max(0, 1 - abs(blinkCycle - 0.13) / 0.13) : 0
        var gazeX = 0.0

        switch mode {
        case .idle:
            break
        case .runway:
            let cycle = phase.truncatingRemainder(dividingBy: 10) / 10
            let runwayStride = animated ? sin(cycle * .pi * 8) : 0
            offsetX = runwayStride * 7.5
            offsetY = -abs(runwayStride) * 3.2
            scale = animated ? 0.968 + 0.055 * (0.5 - 0.5 * cos(cycle * .pi * 2)) : 1.0
            rotation = runwayStride * 1.45
            perspective = runwayStride * 4.8
            headTilt = -runwayStride * 1.1
            hairDrift = animated ? sin(cycle * .pi * 10) : 0
            cameraPush = animated ? 1.0 + 0.018 * sin(cycle * .pi * 2) : 1.0
            catwalkPulse = animated ? 0.45 + abs(runwayStride) * 0.55 : 0
            maskPulse = 0.42 + abs(runwayStride) * 0.15
            expression = .confident
            let gait = animated ? sin(phase * 4.6) : 0
            leftFootContact = animated ? max(0, gait) : 1
            rightFootContact = animated ? max(0, -gait) : 1
            leftArmSwing = animated ? -gait * 0.68 : 0
            rightArmSwing = animated ? gait * 0.68 : 0
            weightShift = animated ? gait * 0.65 : 0
            gazeX = 0
        case .greeting:
            offsetX = -3.5
            rotation = -1.1
            perspective = -4.2
            headTilt = -1.4
            handR = 0.55 + gesturePulse * 0.45
            expression = .warm
        case .listening:
            offsetX = 1.5
            offsetY = 0.7
            perspective = 2.4
            headTilt = 1.1
            maskPulse = 0.42 + gesturePulse * 0.16
            expression = .attentive
        case .thinking:
            offsetX = 3.2
            rotation = 0.9
            perspective = 8.5
            headTilt = -2.2
            gazeX = 0.1
            expression = .curious
        case .speaking:
            // Speech alone does not license a random nod, sway or gesture.
            // An approved rig can later use timed semantic cues from the
            // actual utterance; this reference renderer has no such joints.
            offsetX = 0
            offsetY = breath * 0.7
            scale = 1
            rotation = 0
            perspective = 0
            headTilt = 0
            maskPulse = 0.55 + mouth * 0.42
            expression = .speaking
        }

        switch gesture {
        case .none:
            break
        case .wave:
            handR = max(handR, 0.65 + gesturePulse * 0.35)
            headTilt += 0.8
            expression = .warm
            rightFingerCurl = 0.08
        case .openPalm:
            handL = max(handL, 0.55 + gesturePulse * 0.35)
            handR = max(handR, 0.55 + gesturePulse * 0.35)
            expression = .delighted
            leftFingerCurl = 0.05
            rightFingerCurl = 0.05
        case .point:
            handR = 1.0
            perspective += 1.8
            expression = .confident
            rightFingerCurl = 0.72
        case .handToHeart:
            handL = 1.0
            maskPulse = max(maskPulse, 0.72)
            expression = .warm
            leftFingerCurl = 0.30
        case .hairSweep:
            handR = 0.9
            hairDrift = 1.0
            headTilt -= 1.4
            expression = .confident
            rightFingerCurl = 0.18
        case .turn:
            perspective += 10
            rotation += 1.8
            hairDrift = 1.0
        case .bow:
            offsetY += 16
            rotation += 2.4
            headTilt += 4.0
            expression = .warm
        }

        return OracleMotionFrame(
            bodyOffsetX: bounded(offsetX, -12, 12),
            bodyOffsetY: bounded(offsetY, -10, 18),
            bodyScale: bounded(scale, 0.95, 1.04),
            bodyRotation: bounded(rotation, -3, 3),
            perspective: bounded(perspective, -12, 12),
            hipSway: bounded(hip, -1, 1),
            shoulderRoll: bounded(shoulder, -1, 1),
            headTilt: bounded(headTilt, -5, 5),
            hairDrift: bounded(hairDrift, -1, 1),
            cameraPush: bounded(cameraPush, 0.98, 1.03),
            catwalkPulse: bounded(catwalkPulse, 0, 1),
            maskPulse: bounded(maskPulse, 0, 1),
            leftHandPulse: bounded(handL, 0, 1),
            rightHandPulse: bounded(handR, 0, 1),
            leftFootContact: bounded(leftFootContact, 0, 1),
            rightFootContact: bounded(rightFootContact, 0, 1),
            leftArmSwing: bounded(leftArmSwing, -1, 1),
            rightArmSwing: bounded(rightArmSwing, -1, 1),
            weightShift: bounded(weightShift, -1, 1),
            gazeX: bounded(gazeX, -1, 1),
            blink: bounded(blink, 0, 1),
            jawOpen: mode == .speaking ? mouth : 0,
            leftFingerCurl: bounded(leftFingerCurl, 0, 1),
            rightFingerCurl: bounded(rightFingerCurl, 0, 1),
            expression: expression,
            gesture: gesture
        )
    }

    static func expression(for mode: OracleMotionMode) -> OracleMaskExpression {
        switch mode {
        case .idle: return .calm
        case .runway: return .confident
        case .greeting: return .warm
        case .listening: return .attentive
        case .thinking: return .curious
        case .speaking: return .speaking
        }
    }

    private static func bounded(_ value: Double, _ lower: Double, _ upper: Double) -> Double {
        guard value.isFinite else { return lower <= 0 && upper >= 0 ? 0 : lower }
        return min(max(value, lower), upper)
    }
}
