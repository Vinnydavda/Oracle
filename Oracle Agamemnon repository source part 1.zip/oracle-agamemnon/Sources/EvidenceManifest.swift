import CryptoKit
import Foundation

struct EvidenceManifestItem: Hashable {
    let path: String
    let sha256: String
    let observedAt: Date
    let kind: String
}

enum EvidenceManifestReader {
    private static let ignoredNames: Set<String> = [".DS_Store"]

    static func read(root: URL, observedAt: Date, limit: Int = 200) -> [EvidenceManifestItem] {
        guard limit > 0,
              let enumerator = FileManager.default.enumerator(
                at: root,
                includingPropertiesForKeys: [.isRegularFileKey, .isHiddenKey],
                options: [.skipsHiddenFiles, .skipsPackageDescendants]
              ) else { return [] }

        var items: [EvidenceManifestItem] = []
        for case let url as URL in enumerator {
            guard items.count < limit else { break }
            guard !ignoredNames.contains(url.lastPathComponent),
                  let values = try? url.resourceValues(forKeys: [.isRegularFileKey, .isHiddenKey]),
                  values.isRegularFile == true,
                  values.isHidden != true,
                  let digest = sha256(of: url) else { continue }
            items.append(EvidenceManifestItem(
                path: url.path,
                sha256: digest,
                observedAt: observedAt,
                kind: kind(for: url.pathExtension)
            ))
        }
        return items.sorted { $0.path.localizedStandardCompare($1.path) == .orderedAscending }
    }

    private static func sha256(of url: URL) -> String? {
        guard let handle = try? FileHandle(forReadingFrom: url) else { return nil }
        defer { try? handle.close() }
        var hasher = SHA256()
        while true {
            let chunk: Data
            do { chunk = try handle.read(upToCount: 1_048_576) ?? Data() }
            catch { return nil }
            if chunk.isEmpty { break }
            hasher.update(data: chunk)
        }
        return hasher.finalize().map { String(format: "%02x", $0) }.joined()
    }

    private static func kind(for pathExtension: String) -> String {
        switch pathExtension.lowercased() {
        case "jpg", "jpeg": return "jpeg"
        case "png": return "png"
        case "mov": return "quicktime"
        case "mp4": return "mpeg4"
        case "json": return "json"
        case "txt", "log": return "text"
        default: return pathExtension.isEmpty ? "file" : pathExtension.lowercased()
        }
    }
}
