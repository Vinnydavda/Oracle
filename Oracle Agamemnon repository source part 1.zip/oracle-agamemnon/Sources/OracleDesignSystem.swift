import AppKit
import SwiftUI

struct OracleBundleImage: View {
    let resourceName: String
    var fileExtension: String = "png"

    var body: some View {
        if let url = Bundle.main.url(forResource: resourceName, withExtension: fileExtension),
           let image = NSImage(contentsOf: url) {
            Image(nsImage: image).resizable()
        } else {
            Color.clear
        }
    }
}

struct OracleVisualPolicy {
    let animationEnabled: Bool
    let blurRadius: Double
    let glassOpacity: Double
    let borderOpacity: Double
    let secondaryTextOpacity: Double

    static func make(
        reduceMotion: Bool,
        reduceTransparency: Bool,
        increaseContrast: Bool,
        sceneActive: Bool
    ) -> OracleVisualPolicy {
        OracleVisualPolicy(
            animationEnabled: !reduceMotion && sceneActive,
            blurRadius: reduceTransparency ? 0 : 22,
            glassOpacity: reduceTransparency ? 0.92 : (increaseContrast ? 0.66 : 0.46),
            borderOpacity: increaseContrast ? 0.72 : 0.24,
            secondaryTextOpacity: increaseContrast ? 0.95 : 0.72
        )
    }
}

enum OraclePalette {
    static let void = Color(red: 0.035, green: 0.018, blue: 0.075)
    static let abyss = Color(red: 0.07, green: 0.025, blue: 0.13)
    static let deepPurple = Color(red: 0.18, green: 0.05, blue: 0.31)
    static let violet = Color(red: 0.46, green: 0.13, blue: 0.76)
    static let electricPurple = Color(red: 0.67, green: 0.22, blue: 1.0)
    static let magenta = Color(red: 0.98, green: 0.34, blue: 0.91)
    static let lavender = Color(red: 0.96, green: 0.84, blue: 1.0)
    static let ember = Color(red: 1.0, green: 0.58, blue: 0.29)
    static let gold = Color(red: 0.88, green: 0.67, blue: 0.26)
    static let good = Color(red: 0.33, green: 0.92, blue: 0.66)
    static let warning = Color(red: 1.0, green: 0.72, blue: 0.27)
    static let danger = Color(red: 1.0, green: 0.34, blue: 0.42)
    static let coolText = Color(red: 0.91, green: 0.84, blue: 0.97)
}

struct OracleBackdrop: View {
    var paused: Bool = false
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @Environment(\.colorSchemeContrast) private var contrast
    @Environment(\.scenePhase) private var scenePhase

    private var policy: OracleVisualPolicy {
        .make(
            reduceMotion: reduceMotion,
            reduceTransparency: reduceTransparency,
            increaseContrast: contrast == .increased,
            sceneActive: scenePhase == .active && !paused
        )
    }

    var body: some View {
        Group {
            if policy.animationEnabled {
                SwiftUI.TimelineView(.periodic(from: .now, by: 0.14)) { timeline in
                    field(phase: timeline.date.timeIntervalSinceReferenceDate)
                }
            } else {
                field(phase: 12)
            }
        }
        .accessibilityHidden(true)
        .allowsHitTesting(false)
        .ignoresSafeArea()
    }

    private func field(phase: TimeInterval) -> some View {
        GeometryReader { proxy in
            let size = proxy.size
            let slow = phase * 0.09
            ZStack {
                LinearGradient(
                    colors: [OraclePalette.void, OraclePalette.abyss, Color.black, OraclePalette.deepPurple.opacity(0.72)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )

                Circle()
                    .fill(RadialGradient(colors: [OraclePalette.violet.opacity(0.5), .clear], center: .center, startRadius: 0, endRadius: size.width * 0.42))
                    .frame(width: size.width * 0.75, height: size.width * 0.75)
                    .blur(radius: policy.blurRadius + 18)
                    .offset(x: sin(slow) * size.width * 0.12 - size.width * 0.22,
                            y: cos(slow * 0.8) * size.height * 0.08 - size.height * 0.20)

                Ellipse()
                    .fill(RadialGradient(colors: [OraclePalette.magenta.opacity(0.22), .clear], center: .center, startRadius: 0, endRadius: size.width * 0.38))
                    .frame(width: size.width * 0.8, height: size.height * 0.55)
                    .blur(radius: policy.blurRadius + 24)
                    .offset(x: cos(slow * 0.7) * size.width * 0.18 + size.width * 0.22,
                            y: sin(slow * 0.55) * size.height * 0.12 + size.height * 0.18)

                ForEach(0..<22, id: \.self) { index in
                    let seed = Double(index)
                    let drift = policy.animationEnabled ? sin(phase * 0.18 + seed * 1.7) : 0
                    Circle()
                        .fill(index.isMultiple(of: 5) ? OraclePalette.ember : OraclePalette.lavender)
                        .frame(width: index.isMultiple(of: 5) ? 2.4 : 1.5)
                        .opacity(policy.glassOpacity * (0.35 + Double(index % 4) * 0.12))
                        .position(
                            x: size.width * ((seed * 0.173).truncatingRemainder(dividingBy: 1.0)),
                            y: size.height * ((seed * 0.293).truncatingRemainder(dividingBy: 1.0)) + drift * 8
                        )
                        .blur(radius: index.isMultiple(of: 5) ? 1.2 : 0)
                }

                LinearGradient(
                    colors: [.clear, OraclePalette.magenta.opacity(0.11), OraclePalette.ember.opacity(0.08), .clear],
                    startPoint: .leading,
                    endPoint: .trailing
                )
                .rotationEffect(.degrees(-18 + (policy.animationEnabled ? sin(slow * 0.45) * 3 : 0)))
                .scaleEffect(1.7)
                .blur(radius: policy.blurRadius)
            }
            .overlay(Color.black.opacity(reduceTransparency ? 0.06 : 0.18))
        }
    }
}

private struct OracleGlassSurfaceModifier: ViewModifier {
    var cornerRadius: CGFloat
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @Environment(\.colorSchemeContrast) private var contrast
    @Environment(\.scenePhase) private var scenePhase
    @State private var hovered = false

    private var policy: OracleVisualPolicy {
        .make(
            reduceMotion: reduceMotion,
            reduceTransparency: reduceTransparency,
            increaseContrast: contrast == .increased,
            sceneActive: scenePhase == .active
        )
    }

    func body(content: Content) -> some View {
        content
            .background {
                ZStack {
                    if reduceTransparency {
                        RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                            .fill(OraclePalette.abyss.opacity(policy.glassOpacity))
                    } else {
                        RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                            .fill(.ultraThinMaterial)
                        RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                            .fill(
                                LinearGradient(
                                    colors: [
                                        OraclePalette.lavender.opacity(0.12),
                                        OraclePalette.violet.opacity(0.20),
                                        OraclePalette.magenta.opacity(0.12)
                                    ],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                )
                            )
                    }
                }
            }
            .overlay {
                RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                    .strokeBorder(
                        LinearGradient(
                            colors: [
                                OraclePalette.lavender.opacity(policy.borderOpacity),
                                OraclePalette.violet.opacity(policy.borderOpacity * 0.65),
                                OraclePalette.ember.opacity(policy.borderOpacity * 0.28)
                            ],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ),
                        lineWidth: contrast == .increased ? 1.5 : 1
                    )
            }
            .shadow(color: OraclePalette.violet.opacity(hovered ? 0.22 : 0.10), radius: hovered ? 22 : 14, y: hovered ? 12 : 8)
            .shadow(color: Color.black.opacity(0.48), radius: 18, y: 12)
            .scaleEffect(hovered && !reduceMotion ? 1.004 : 1)
            .offset(y: hovered && !reduceMotion ? -1.5 : 0)
            .animation(reduceMotion ? nil : .easeOut(duration: 0.22), value: hovered)
            .onHover { hovered = $0 }
    }
}

extension View {
    func oracleGlassCard(cornerRadius: CGFloat = 18) -> some View {
        modifier(OracleGlassSurfaceModifier(cornerRadius: cornerRadius))
    }

    func oraclePageSurface() -> some View {
        padding(20)
            .frame(maxWidth: .infinity, alignment: .leading)
            .oracleGlassCard(cornerRadius: 22)
    }
}

struct OracleSectionHeading: View {
    let eyebrow: String
    let title: String
    let detail: String?
    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(eyebrow.uppercased())
                .font(.caption2.weight(.bold))
                .tracking(1.6)
                .foregroundStyle(OraclePalette.magenta)
            Text(title)
                .font(.system(.title2, design: .serif).weight(.semibold))
                .foregroundStyle(OraclePalette.lavender)
            if let detail {
                Text(detail).font(.footnote).foregroundStyle(.secondary)
            }
        }
        .accessibilityElement(children: .combine)
    }
}

struct OracleBrandHeader: View {
    let title: String
    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                Circle()
                    .fill(RadialGradient(colors: [OraclePalette.magenta.opacity(0.55), OraclePalette.violet.opacity(0.18)], center: .center, startRadius: 2, endRadius: 28))
                    .frame(width: 48, height: 48)
                OracleBundleImage(resourceName: "AppIcon")
                    .scaledToFit().frame(width: 48, height: 48)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
            }
            .overlay(Circle().stroke(OraclePalette.lavender.opacity(0.35)))
            .accessibilityHidden(true)

            VStack(alignment: .leading, spacing: 2) {
                Text("WAYNE INDUSTRIES")
                    .font(.caption2.weight(.bold))
                    .tracking(2.2)
                    .foregroundStyle(OraclePalette.lavender)
                Text(title)
                    .font(.system(.title3, design: .serif).weight(.semibold))
                    .foregroundStyle(OraclePalette.lavender)
            }
            Spacer()
            Text("ORACLE • AGAMEMNON")
                .font(.caption.monospaced().weight(.semibold))
                .tracking(1.2)
                .foregroundStyle(OraclePalette.ember.opacity(0.92))
                .accessibilityLabel("Oracle Agamemnon")
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 14)
        .background(OraclePalette.void.opacity(0.62), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(OraclePalette.lavender.opacity(0.14)))
    }
}

struct OracleStatusPill: View {
    let title: String
    let color: Color
    let symbol: String
    var body: some View {
        Label(title, systemImage: symbol)
            .font(.caption.weight(.semibold))
            .foregroundStyle(OraclePalette.lavender)
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(color.opacity(0.17), in: Capsule())
            .overlay(Capsule().stroke(color.opacity(0.56)))
            .accessibilityElement(children: .combine)
    }
}

struct OracleSidebarBrand: View {
    var body: some View {
        HStack(spacing: 11) {
            ZStack {
                Circle().fill(OraclePalette.violet.opacity(0.32))
                OracleBundleImage(resourceName: "AppIcon")
                    .scaledToFit().frame(width: 38, height: 38)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
            }
            .frame(width: 38, height: 38)
            .overlay(Circle().stroke(OraclePalette.magenta.opacity(0.45)))
            VStack(alignment: .leading, spacing: 2) {
                Text("WAYNE")
                    .font(.caption2.weight(.bold)).tracking(1.8).foregroundStyle(OraclePalette.lavender)
                Text("ORACLE")
                    .font(.system(.headline, design: .serif).weight(.semibold)).foregroundStyle(OraclePalette.lavender)
            }
            Spacer()
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 13)
        .accessibilityElement(children: .combine)
        .accessibilityLabel("Wayne Industries Oracle")
    }
}

struct OracleAvatarStage: View {
    let imageName: String
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @Environment(\.colorSchemeContrast) private var contrast
    @Environment(\.scenePhase) private var scenePhase
    @State private var hoverPoint = CGPoint(x: 0.5, y: 0.5)
    @State private var hovered = false

    private var policy: OracleVisualPolicy {
        .make(
            reduceMotion: reduceMotion,
            reduceTransparency: reduceTransparency,
            increaseContrast: contrast == .increased,
            sceneActive: scenePhase == .active
        )
    }

    private var parallaxX: Double { hovered && !reduceMotion ? (hoverPoint.x - 0.5) * 5 : 0 }
    private var parallaxY: Double { hovered && !reduceMotion ? (hoverPoint.y - 0.5) * 4 : 0 }

    var body: some View {
        GeometryReader { proxy in
            ZStack {
                LinearGradient(colors: [Color.black, OraclePalette.deepPurple.opacity(0.82), OraclePalette.void], startPoint: .top, endPoint: .bottom)

                OracleBundleImage(resourceName: imageName)
                    .scaledToFit()
                    .frame(width: proxy.size.width * 0.94, height: proxy.size.height * 0.94)
                    .scaleEffect(hovered && !reduceMotion ? 1.025 : 1)
                    .offset(x: parallaxX * 2.2, y: parallaxY * 1.8)
                    .saturation(contrast == .increased ? 0.82 : 1.06)
                    .contrast(contrast == .increased ? 1.18 : 1.04)
                    .animation(reduceMotion ? nil : .easeOut(duration: 0.35), value: hovered)

                if policy.animationEnabled {
                    SwiftUI.TimelineView(.periodic(from: .now, by: 0.16)) { timeline in
                        aura(phase: timeline.date.timeIntervalSinceReferenceDate)
                    }
                } else {
                    aura(phase: 4)
                }

                LinearGradient(colors: [.clear, Color.black.opacity(reduceTransparency ? 0.46 : 0.2), Color.black.opacity(0.62)], startPoint: .center, endPoint: .bottom)

                VStack {
                    Spacer()
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("ORACLE")
                                .font(.caption2.weight(.bold)).tracking(2)
                                .foregroundStyle(OraclePalette.magenta)
                            Text("Reference energy form")
                                .font(.caption).foregroundStyle(OraclePalette.lavender.opacity(policy.secondaryTextOpacity))
                        }
                        Spacer()
                        Image(systemName: "sparkles")
                            .foregroundStyle(OraclePalette.magenta)
                    }
                    .padding(14)
                    .background(OraclePalette.void.opacity(0.62), in: RoundedRectangle(cornerRadius: 12))
                }
            }
            .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .strokeBorder(
                        LinearGradient(colors: [OraclePalette.lavender.opacity(policy.borderOpacity), OraclePalette.magenta.opacity(policy.borderOpacity * 0.8), OraclePalette.ember.opacity(policy.borderOpacity * 0.42)], startPoint: .topLeading, endPoint: .bottomTrailing)
                    )
            }
            .shadow(color: OraclePalette.violet.opacity(hovered ? 0.28 : 0.16), radius: hovered ? 26 : 18)
            .rotation3DEffect(.degrees(parallaxX), axis: (x: 0, y: 1, z: 0), perspective: 0.55)
            .rotation3DEffect(.degrees(-parallaxY), axis: (x: 1, y: 0, z: 0), perspective: 0.55)
            .onContinuousHover { phase in
                switch phase {
                case .active(let location):
                    hovered = true
                    guard proxy.size.width > 0, proxy.size.height > 0 else { return }
                    hoverPoint = CGPoint(x: location.x / proxy.size.width, y: location.y / proxy.size.height)
                case .ended:
                    hovered = false
                    hoverPoint = CGPoint(x: 0.5, y: 0.5)
                }
            }
            .accessibilityElement(children: .ignore)
            .accessibilityLabel("Oracle energy reference artwork")
            .accessibilityValue("Interactive depth preview using the approved purple artwork. Rigged humanoid controls are not available.")
        }
    }

    private func aura(phase: TimeInterval) -> some View {
        GeometryReader { proxy in
            ZStack {
                Circle()
                    .stroke(OraclePalette.magenta.opacity(0.18), lineWidth: 1)
                    .frame(width: proxy.size.width * 0.70, height: proxy.size.width * 0.70)
                    .blur(radius: 2)
                    .offset(y: -proxy.size.height * 0.08)
                    .scaleEffect(1 + sin(phase * 0.32) * 0.018)
                ForEach(0..<9, id: \.self) { index in
                    let seed = Double(index)
                    Circle()
                        .fill(index.isMultiple(of: 3) ? OraclePalette.ember : OraclePalette.lavender)
                        .frame(width: index.isMultiple(of: 3) ? 2.2 : 1.3)
                        .position(
                            x: proxy.size.width * ((seed * 0.219).truncatingRemainder(dividingBy: 1.0)),
                            y: proxy.size.height * ((seed * 0.317).truncatingRemainder(dividingBy: 1.0)) + sin(phase * 0.22 + seed) * 7
                        )
                        .opacity(0.45)
                }
            }
            .blendMode(.screen)
        }
        .allowsHitTesting(false)
    }
}
