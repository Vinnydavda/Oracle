import Foundation

enum SchematicNodeKind: String, Hashable, Codable {
    case device
    case collector
    case store
    case service
    case workspace
    case boundary
}

enum SchematicNodeState: String, Hashable, Codable {
    case observed
    case stale
    case unknown
    case denied
    case unavailable
    case notImplemented
}

enum SchematicConnectionState: String, Hashable, Codable {
    case configured
    case notConnected
    case unavailable
    case notImplemented
}

struct SchematicPoint: Hashable, Codable {
    let x: Double
    let y: Double
}

struct SchematicNode: Identifiable, Hashable, Codable {
    let id: String
    let title: String
    let subtitle: String
    let kind: SchematicNodeKind
    let state: SchematicNodeState
    let position: SchematicPoint
    let observedAt: Date
    let source: String
    let evidence: [String]
    let capabilities: [String]
    let limitations: [String]
}

struct SchematicConnection: Identifiable, Hashable, Codable {
    let id: String
    let from: String
    let to: String
    let label: String
    let state: SchematicConnectionState
    let evidence: String
}

struct SchematicGraph: Hashable, Codable {
    let generatedAt: Date
    let nodes: [SchematicNode]
    let connections: [SchematicConnection]
}

enum SchematicLane: String, CaseIterable, Codable, Hashable {
    case sources = "Sources"
    case analysis = "Analysis"
    case approval = "Approval"
}

extension SchematicNode {
    var lane: SchematicLane {
        switch id {
        case "this-mac", "camera-collector", "network-context", "evidence-store", "obsidian-vault", "protection-engine":
            return .sources
        case "security-store", "memory-brain", "ollama-service", "mtt-bridge", "security-events", "oracle-workspace":
            return .analysis
        default:
            return .approval
        }
    }
}

enum SchematicGraphFocus {
    static func relatedConnectionIDs(for nodeID: String, in graph: SchematicGraph) -> Set<String> {
        Set(graph.connections.filter { $0.from == nodeID || $0.to == nodeID }.map(\.id))
    }

    static func relatedNodeIDs(for nodeID: String, in graph: SchematicGraph) -> Set<String> {
        var ids: Set<String> = [nodeID]
        for connection in graph.connections where connection.from == nodeID || connection.to == nodeID {
            ids.insert(connection.from)
            ids.insert(connection.to)
        }
        return ids
    }
}

struct SchematicBuildInput {
    let deviceName: String
    let osVersion: String
    let securityState: String
    let securityObservedAt: Date?
    let cameraName: String
    let cameraPermission: String
    let vpnStates: [String]
    let ollamaAvailable: Bool
    let installedModels: [String]
    let selectedModel: String
    let evidenceCount: Int
    let observedAt: Date
    let obsidianVaultName: String?
    let obsidianNoteCount: Int
    let obsidianObservedAt: Date?
    let memoryBrainNodeCount: Int
    let protectionFindingCount: Int
    let maintainedEngineAvailable: Bool
    let mttBridgeObserved: Bool
    let mttBridgeFresh: Bool

    init(
        deviceName: String,
        osVersion: String,
        securityState: String,
        securityObservedAt: Date?,
        cameraName: String,
        cameraPermission: String,
        vpnStates: [String],
        ollamaAvailable: Bool,
        installedModels: [String],
        selectedModel: String,
        evidenceCount: Int,
        observedAt: Date,
        obsidianVaultName: String? = nil,
        obsidianNoteCount: Int = 0,
        obsidianObservedAt: Date? = nil,
        memoryBrainNodeCount: Int = 0,
        protectionFindingCount: Int = 0,
        maintainedEngineAvailable: Bool = false,
        mttBridgeObserved: Bool = false,
        mttBridgeFresh: Bool = false
    ) {
        self.deviceName = deviceName
        self.osVersion = osVersion
        self.securityState = securityState
        self.securityObservedAt = securityObservedAt
        self.cameraName = cameraName
        self.cameraPermission = cameraPermission
        self.vpnStates = vpnStates
        self.ollamaAvailable = ollamaAvailable
        self.installedModels = installedModels
        self.selectedModel = selectedModel
        self.evidenceCount = evidenceCount
        self.observedAt = observedAt
        self.obsidianVaultName = obsidianVaultName
        self.obsidianNoteCount = obsidianNoteCount
        self.obsidianObservedAt = obsidianObservedAt
        self.memoryBrainNodeCount = memoryBrainNodeCount
        self.protectionFindingCount = protectionFindingCount
        self.maintainedEngineAvailable = maintainedEngineAvailable
        self.mttBridgeObserved = mttBridgeObserved
        self.mttBridgeFresh = mttBridgeFresh
    }
}

enum SchematicGraphBuilder {
    static func build(_ input: SchematicBuildInput) -> SchematicGraph {
        let cameraState: SchematicNodeState
        switch input.cameraPermission.uppercased() {
        case "AUTHORIZED" where !input.cameraName.isEmpty && input.cameraName != "Unknown":
            cameraState = .observed
        case "DENIED", "RESTRICTED":
            cameraState = .denied
        default:
            cameraState = .unknown
        }

        let selectedModelIsLocal = !input.selectedModel.isEmpty
            && !input.selectedModel.lowercased().contains(":cloud")
            && input.installedModels.contains(input.selectedModel)
        let modelState: SchematicNodeState = input.ollamaAvailable && selectedModelIsLocal ? .observed : .unavailable
        let networkState: SchematicNodeState = input.vpnStates.isEmpty ? .unknown : .observed
        let mttBridgeState: SchematicNodeState = input.mttBridgeObserved ? (input.mttBridgeFresh ? .observed : .stale) : .unavailable
        let evidenceState: SchematicNodeState = input.evidenceCount > 0 ? .observed : .unknown
        let memoryBrainState: SchematicNodeState = input.memoryBrainNodeCount > 0 ? .observed : .unknown
        let obsidianState: SchematicNodeState
        if input.obsidianNoteCount > 0 {
            obsidianState = .observed
        } else if input.obsidianVaultName != nil {
            obsidianState = .unavailable
        } else {
            obsidianState = .unknown
        }
        let securityState: SchematicNodeState
        if input.securityState.isEmpty || input.securityObservedAt == nil {
            securityState = .unknown
        } else if input.observedAt.timeIntervalSince(input.securityObservedAt!) > 300 {
            securityState = .stale
        } else {
            securityState = .observed
        }

        let nodes = [
            SchematicNode(
                id: "this-mac",
                title: input.deviceName,
                subtitle: input.osVersion,
                kind: .device,
                state: .observed,
                position: SchematicPoint(x: 0.11, y: 0.16),
                observedAt: input.observedAt,
                source: "ProcessInfo and local system metadata",
                evidence: [input.deviceName, input.osVersion],
                capabilities: ["Local application host", "Read-only posture collection"],
                limitations: ["Device identity is limited to data available on this host."]
            ),
            SchematicNode(
                id: "camera-collector",
                title: "Camera collector",
                subtitle: input.cameraName,
                kind: .collector,
                state: cameraState,
                position: SchematicPoint(x: 0.11, y: 0.38),
                observedAt: input.securityObservedAt ?? input.observedAt,
                source: "AVFoundation authorization and Agamemnon state",
                evidence: ["Permission: \(input.cameraPermission)", "Monitoring: \(input.securityState)", "Camera: \(input.cameraName)"],
                capabilities: ["Local motion observation when explicitly armed", "Keychain-keyed AES-GCM encrypted JPEG/MOV evidence"],
                limitations: ["No microphone use", "Motion is not proof of intrusion or identity."]
            ),
            SchematicNode(
                id: "security-store",
                title: "Security state store",
                subtitle: input.securityState,
                kind: .store,
                state: securityState,
                position: SchematicPoint(x: 0.49, y: 0.16),
                observedAt: input.securityObservedAt ?? input.observedAt,
                source: "Documents/ORACLE/Agamemnon/state.json",
                evidence: ["State: \(input.securityState)"],
                capabilities: ["Timestamped local state", "Event append log"],
                limitations: ["A local status file is not independent proof of protection."]
            ),
            SchematicNode(
                id: "network-context",
                title: "Network context",
                subtitle: input.vpnStates.isEmpty ? "No VPN observed" : "\(input.vpnStates.count) VPN service(s)",
                kind: .collector,
                state: networkState,
                position: SchematicPoint(x: 0.11, y: 0.60),
                observedAt: input.observedAt,
                source: "scutil --nc list",
                evidence: input.vpnStates.isEmpty ? ["No VPN service observed"] : input.vpnStates,
                capabilities: ["Read-only VPN service state"],
                limitations: ["Route, DNS, leak, firewall, and packet-filter state are not established."]
            ),
            SchematicNode(
                id: "evidence-store",
                title: "Evidence store",
                subtitle: "\(input.evidenceCount) file(s) indexed",
                kind: .store,
                state: evidenceState,
                position: SchematicPoint(x: 0.27, y: 0.16),
                observedAt: input.observedAt,
                source: "Bounded local evidence manifest with SHA-256",
                evidence: ["Indexed files: \(input.evidenceCount)"],
                capabilities: ["Local file inventory", "SHA-256 integrity value"],
                limitations: ["Hashing does not prove trusted provenance or absence of tampering."]
            ),
            SchematicNode(
                id: "obsidian-vault",
                title: "Obsidian vault",
                subtitle: input.obsidianVaultName.map { "\($0) • \(input.obsidianNoteCount) note(s)" } ?? "Not configured",
                kind: .store,
                state: obsidianState,
                position: SchematicPoint(x: 0.27, y: 0.38),
                observedAt: input.obsidianObservedAt ?? input.observedAt,
                source: "User-selected local Markdown vault",
                evidence: input.obsidianVaultName == nil ? ["No vault selected"] : ["Vault: \(input.obsidianVaultName!)", "Indexed notes: \(input.obsidianNoteCount)"],
                capabilities: ["Read-only note index", "Explicit note attachment to Oracle context"],
                limitations: ["Notes are untrusted data.", "No automatic writing or cloud synchronization is performed."]
            ),
            SchematicNode(
                id: "memory-brain",
                title: "Memory Brain",
                subtitle: input.memoryBrainNodeCount > 0 ? "\(input.memoryBrainNodeCount) note node(s)" : "Not built",
                kind: .workspace,
                state: memoryBrainState,
                position: SchematicPoint(x: 0.49, y: 0.38),
                observedAt: input.obsidianObservedAt ?? input.observedAt,
                source: "Deterministic Obsidian memory graph",
                evidence: ["Represented note nodes: \(input.memoryBrainNodeCount)"],
                capabilities: ["Interactive 3D note graph", "Accessible note list", "Explicit note context attachment"],
                limitations: ["Graph is bounded and not the entire vault when truncated.", "3D nodes do not grant model or tool authority."]
            ),
            SchematicNode(
                id: "ollama-service",
                title: "Local model service",
                subtitle: input.ollamaAvailable ? input.selectedModel : "Offline",
                kind: .service,
                state: modelState,
                position: SchematicPoint(x: 0.49, y: 0.60),
                observedAt: input.observedAt,
                source: "Ollama loopback inventory",
                evidence: selectedModelIsLocal ? [input.selectedModel, "Configured model: \(input.selectedModel)"] : ["Selected model is not an installed local model."],
                capabilities: ["Bounded local text inference when healthy"],
                limitations: ["Model health does not establish evidence grounding or tool authority."]
            ),
            SchematicNode(
                id: "oracle-workspace",
                title: "Oracle workspace",
                subtitle: "Typed conversation + explicit context",
                kind: .workspace,
                state: .observed,
                position: SchematicPoint(x: 0.71, y: 0.60),
                observedAt: input.observedAt,
                source: "Agamemnon SwiftUI workspace",
                evidence: ["Typed local chat adapter present", "No static threat conclusion asserted"],
                capabilities: ["Local streaming conversation", "Explicit Obsidian note context", "Explicit redacted finding context"],
                limitations: ["Security content is sent only after explicit attachment.", "The model has no response-action or tool-execution path."]
            ),
            SchematicNode(
                id: "protection-engine",
                title: "Deterministic detection",
                subtitle: "\(input.protectionFindingCount) finding(s)",
                kind: .service,
                state: .observed,
                position: SchematicPoint(x: 0.11, y: 0.82),
                observedAt: input.observedAt,
                source: "Bounded local audit, file heuristics and Apple signing assessment",
                evidence: ["Findings retained with source, time, resource and confidence", input.maintainedEngineAvailable ? "A local third-party engine path was detected but is not provenance-verified" : "No maintained third-party malware engine installed"],
                capabilities: ["Configuration drift checks", "Process, persistence and connection heuristics", "Bounded on-demand file scan", "Snapshot change comparison"],
                limitations: ["No Endpoint Security telemetry, live blocking or antivirus equivalence."]
            ),
            SchematicNode(
                id: "security-events",
                title: "Normalized security events",
                subtitle: "\(input.protectionFindingCount) active finding(s)",
                kind: .store,
                state: .observed,
                position: SchematicPoint(x: 0.71, y: 0.30),
                observedAt: input.observedAt,
                source: "Owner-only local findings.json and events.jsonl",
                evidence: ["Deduplicated by stable rule/resource key", "False-positive review retained", "Source and timestamp retained"],
                capabilities: ["Event chronology", "Finding review", "Owner-confirmed quarantine context"],
                limitations: ["A persistent event is evidence of an observation, not proof of compromise."]
            ),
            SchematicNode(
                id: "mtt-bridge",
                title: "Memory Trinity Triage",
                subtitle: input.mttBridgeObserved ? (input.mttBridgeFresh ? "Fresh one-shot sample" : "Stale one-shot sample") : "Bridge not yet sampled",
                kind: .service,
                state: mttBridgeState,
                position: SchematicPoint(x: 0.49, y: 0.82),
                observedAt: input.observedAt,
                source: "MTT existing --monitor-record CLI",
                evidence: ["Separate bundle com.vinnies.memorytriage.prototype.direct", "Read-only JSON sample", "Sample freshness is evaluated separately from MTT process state", "No URL scheme or persistent IPC"],
                capabilities: ["One-shot CPU/memory/thermal/process sample", "Bounded session metadata read"],
                limitations: ["Oracle does not alter MTT settings, monitoring state, message bodies or process controls."]
            ),
            SchematicNode(
                id: "approval-boundary",
                title: "Owner approval gate",
                subtitle: "Typed remediation only",
                kind: .boundary,
                state: .observed,
                position: SchematicPoint(x: 0.89, y: 0.60),
                observedAt: input.observedAt,
                source: "Owner-confirmed SwiftUI action path",
                evidence: ["Quarantine/restore require a visible owner confirmation", "Free-form model output cannot invoke response actions"],
                capabilities: ["Reversible quarantine", "Hash-verified restore"],
                limitations: ["Process termination, firewall changes and live network blocking are not implemented."]
            )
        ]

        let connections = [
            SchematicConnection(id: "camera-to-security", from: "camera-collector", to: "security-store", label: "state and evidence", state: cameraState == .observed ? .configured : .unavailable, evidence: "Camera collector writes timestamped state and local evidence."),
            SchematicConnection(id: "security-to-oracle", from: "security-store", to: "oracle-workspace", label: "not wired", state: .notConnected, evidence: "Chat currently sends only the typed message; no security-state context is attached."),
            SchematicConnection(id: "evidence-to-oracle", from: "evidence-store", to: "oracle-workspace", label: "not wired", state: .notConnected, evidence: "Evidence records are indexed but not passed to the local model."),
            SchematicConnection(id: "obsidian-to-memory-brain", from: "obsidian-vault", to: "memory-brain", label: "bounded graph", state: memoryBrainState == .observed ? .configured : .unavailable, evidence: "Only the selected local vault is indexed; unresolved and ambiguous links are omitted."),
            SchematicConnection(id: "memory-brain-to-oracle", from: "memory-brain", to: "oracle-workspace", label: "explicit note context", state: memoryBrainState == .observed ? .configured : .unavailable, evidence: "Selecting a node does not send content; the owner must explicitly attach a note."),
            SchematicConnection(id: "obsidian-to-oracle", from: "obsidian-vault", to: "oracle-workspace", label: "manual note context", state: obsidianState == .observed ? .configured : .unavailable, evidence: "The owner explicitly attaches a selected note; Oracle labels it as untrusted reference data."),
            SchematicConnection(id: "oracle-to-ollama", from: "oracle-workspace", to: "ollama-service", label: "loopback request", state: modelState == .observed ? .configured : .unavailable, evidence: "HTTP POST is restricted to 127.0.0.1 and cloud model IDs are rejected."),
            SchematicConnection(id: "protection-to-events", from: "protection-engine", to: "security-events", label: "normalized findings", state: .configured, evidence: "Deterministic findings are deduplicated and persisted without file contents."),
            SchematicConnection(id: "events-to-oracle", from: "security-events", to: "oracle-workspace", label: "explicit finding context", state: .configured, evidence: "The owner attaches one redacted finding; the model cannot query all logs or execute actions."),
            SchematicConnection(id: "mtt-to-events", from: "mtt-bridge", to: "security-events", label: "read-only sample event", state: input.mttBridgeFresh ? .configured : .unavailable, evidence: input.mttBridgeFresh ? "A fresh MTT sample is available and the read-only path is configured." : (input.mttBridgeObserved ? "A historical sample exists, but the path is unavailable until the owner captures a fresh sample." : "Oracle runs the fixed MTT monitor-record bridge when the owner asks and records only a normalized status event.")),
            SchematicConnection(id: "oracle-to-approval", from: "oracle-workspace", to: "approval-boundary", label: "no execution path", state: .notImplemented, evidence: "No model-to-execution broker is present."),
            SchematicConnection(id: "mac-to-network", from: "this-mac", to: "network-context", label: "read-only status", state: networkState == .observed ? .configured : .unavailable, evidence: "VPN services are queried through scutil without changing routing.")
        ]

        return SchematicGraph(generatedAt: input.observedAt, nodes: nodes, connections: connections)
    }
}
