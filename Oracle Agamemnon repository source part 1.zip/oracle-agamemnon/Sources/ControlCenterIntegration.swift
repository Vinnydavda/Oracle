import AppKit
import Foundation

struct ConnectedResource: Identifiable, Hashable {
    let id: String
    let name: String
    let kind: String
    let status: String
    let detail: String
    let path: String?
    let isRunning: Bool
    let capabilities: [String]
    let limitations: [String]
}

struct MTTMonitorSnapshot: Hashable {
    let timestamp: Date
    let cpuTotal: Double?
    let memoryPhysical: UInt64?
    let memoryUsed: UInt64?
    let compressed: UInt64?
    let thermalState: String
    let thermalRank: Int
    let networkStatus: String
    let processStatus: String
    let processCount: Int
}

enum MTTSampleFreshness: String, Codable, Hashable {
    case noSample
    case fresh
    case stale

    var label: String {
        switch self {
        case .noSample: return "No sample"
        case .fresh: return "Fresh"
        case .stale: return "Stale"
        }
    }
}

struct MTTBridgeMetadata: Hashable {
    let appPath: String
    let version: String
    let build: String
    let isRunning: Bool
    let sessionSavedAt: Date?
    let sessionMessageCount: Int
    let draftLength: Int
    let monitorEventsBytes: UInt64?
    let lastSnapshot: MTTMonitorSnapshot?
    let lastCapturedAt: Date?
}

struct ControlCenterIntegrationState: Codable {
    var mttLastCapturedAt: Date?
    var mttLastSnapshot: StoredMTTSnapshot?
}

struct StoredMTTSnapshot: Codable, Hashable {
    let timestamp: Date
    let cpuTotal: Double?
    let memoryPhysical: UInt64?
    let memoryUsed: UInt64?
    let compressed: UInt64?
    let thermalState: String
    let thermalRank: Int
    let networkStatus: String
    let processStatus: String
    let processCount: Int
}

enum ControlCenterIntegrationEngine {
    static let mttBundleID = "com.vinnies.memorytriage.prototype.direct"
    static let mttPath = NSHomeDirectory() + "/Applications/Memory Triage.app"
    static let mttExecutable = NSHomeDirectory() + "/Applications/Memory Triage.app/Contents/MacOS/MemoryTriage"
    static let mttSupport = URL(fileURLWithPath: NSHomeDirectory()).appendingPathComponent("Library/Application Support/Memory Triage", isDirectory: true)

    static func mttVersion() -> (String, String) {
        let info = URL(fileURLWithPath: mttPath).appendingPathComponent("Contents/Info.plist")
        guard let data = try? Data(contentsOf: info),
              let plist = try? PropertyListSerialization.propertyList(from: data, format: nil) as? [String: Any] else { return ("Unknown", "Unknown") }
        return (plist["CFBundleShortVersionString"] as? String ?? "Unknown", plist["CFBundleVersion"] as? String ?? "Unknown")
    }

    static func isMTTRunning() -> Bool {
        !NSRunningApplication.runningApplications(withBundleIdentifier: mttBundleID).isEmpty
    }

    static func captureMTTSnapshot() throws -> MTTMonitorSnapshot {
        guard FileManager.default.isExecutableFile(atPath: mttExecutable) else {
            throw NSError(domain: "OracleMTT", code: 1, userInfo: [NSLocalizedDescriptionKey: "Memory Trinity Triage executable is not installed."])
        }
        let result = LocalCommand.run(mttExecutable, ["--monitor-record", "1", "1"], timeout: 12)
        guard !result.timedOut else {
            throw NSError(domain: "OracleMTT", code: 2, userInfo: [NSLocalizedDescriptionKey: "MTT one-shot monitor capture timed out."])
        }
        guard let line = result.output.split(separator: "\n").first(where: { !$0.trimmingCharacters(in: .whitespaces).isEmpty }) else {
            throw NSError(domain: "OracleMTT", code: 3, userInfo: [NSLocalizedDescriptionKey: "MTT returned no readable sample."])
        }
        guard let object = try JSONSerialization.jsonObject(with: Data(line.utf8)) as? [String: Any] else {
            throw NSError(domain: "OracleMTT", code: 4, userInfo: [NSLocalizedDescriptionKey: "MTT sample was not valid JSON."])
        }
        let formatter = ISO8601DateFormatter()
        let timestamp = (object["timestamp"] as? String).flatMap(formatter.date(from:)) ?? Date()
        let cpu = object["cpu"] as? [String: Any]
        let memory = object["memory"] as? [String: Any]
        let thermal = object["thermal"] as? [String: Any]
        let network = object["network"] as? [String: Any]
        return MTTMonitorSnapshot(
            timestamp: timestamp,
            cpuTotal: cpu?["total"] as? Double,
            memoryPhysical: (memory?["physicalBytes"] as? NSNumber)?.uint64Value,
            memoryUsed: (memory?["usedBytesEstimate"] as? NSNumber)?.uint64Value,
            compressed: (memory?["compressedBytes"] as? NSNumber)?.uint64Value,
            thermalState: thermal?["state"] as? String ?? "Unknown",
            thermalRank: (thermal?["rank"] as? NSNumber)?.intValue ?? -1,
            networkStatus: network?["status"] as? String ?? "Unknown",
            processStatus: object["processStatus"] as? String ?? "Unknown",
            processCount: (object["processes"] as? [[String: Any]])?.count ?? 0
        )
    }

    static let mttSampleFreshWindow: TimeInterval = 15 * 60

    static func mttSampleFreshness(
        lastCapturedAt: Date?,
        now: Date = Date(),
        freshWindow: TimeInterval = mttSampleFreshWindow
    ) -> MTTSampleFreshness {
        guard let lastCapturedAt else { return .noSample }
        let age = now.timeIntervalSince(lastCapturedAt)
        guard age >= 0 else { return .stale }
        return age <= freshWindow ? .fresh : .stale
    }

    static func sessionMetadata() -> (savedAt: Date?, messageCount: Int, draftLength: Int) {
        let url = mttSupport.appendingPathComponent("Oracle/Session.json")
        guard let data = try? Data(contentsOf: url),
              let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return (nil, 0, 0) }
        let formatter = ISO8601DateFormatter()
        return (
            (object["savedAt"] as? String).flatMap(formatter.date(from:)),
            (object["messages"] as? [[String: Any]])?.count ?? 0,
            (object["draft"] as? String)?.count ?? 0
        )
    }

    static func monitorEventsBytes() -> UInt64? {
        let url = mttSupport.appendingPathComponent("Monitor Events.json")
        guard let values = try? url.resourceValues(forKeys: [.fileSizeKey]) else { return nil }
        return values.fileSize.map(UInt64.init)
    }

    static func inventory(modelAvailable: Bool, modelName: String, vaultName: String?, findingCount: Int) -> [ConnectedResource] {
        let mttRunning = isMTTRunning()
        let (mttVersion, mttBuild) = mttVersion()
        var rows: [ConnectedResource] = [
            ConnectedResource(
                id: "device-this-mac", name: ProcessInfo.processInfo.hostName, kind: "Device",
                status: "Connected", detail: "\(ProcessInfo.processInfo.operatingSystemVersionString) • local host",
                path: nil, isRunning: true,
                capabilities: ["Read-only system posture", "Process inventory", "Network connection inventory", "Local file scanning"],
                limitations: ["No remote-device link is implemented in Oracle.", "Endpoint Security and Network Extension access remain unauthorized."]
            ),
            ConnectedResource(
                id: "app-memory-triage", name: "Memory Trinity Triage", kind: "Separate app",
                status: mttRunning ? "Running • bridge available" : "Installed • bridge available",
                detail: "Version \(mttVersion) build \(mttBuild) • \(mttBundleID)",
                path: mttPath, isRunning: mttRunning,
                capabilities: ["One-shot --monitor-record JSON sample", "Bounded read-only session metadata", "Open the separate app"],
                limitations: ["No URL scheme or persistent IPC is declared.", "Oracle does not read message bodies, alter MTT settings or control MTT monitoring."]
            ),
            ConnectedResource(
                id: "service-qwen", name: "Local Qwen", kind: "Service",
                status: modelAvailable ? "Connected" : "Unavailable", detail: modelName,
                path: nil, isRunning: modelAvailable,
                capabilities: ["Loopback streaming chat", "Explicit note/finding context", "Cancellation"],
                limitations: ["No cloud fallback", "Model output has no execution authority."]
            ),
            ConnectedResource(
                id: "store-obsidian", name: "Obsidian Memory Brain", kind: "Knowledge",
                status: vaultName == nil ? "Not configured" : "Connected",
                detail: vaultName.map { "Vault: \($0)" } ?? "No vault selected",
                path: vaultName == nil ? nil : nil, isRunning: vaultName != nil,
                capabilities: ["Read-only Markdown index", "Animated memory graph", "Explicit note attachment"],
                limitations: ["Notes remain untrusted data and are never sent unless attached."]
            ),
            ConnectedResource(
                id: "security-findings", name: "Oracle protection findings", kind: "Security",
                status: "Connected", detail: "\(findingCount) retained finding(s)",
                path: nil, isRunning: true,
                capabilities: ["Deterministic detection", "Owner-confirmed quarantine", "Explicit model explanation"],
                limitations: ["No maintained third-party malware engine is installed.", "No live blocking."]
            ),
            ConnectedResource(
                id: "device-sukuna", name: "Sukuna’s Mac Studio", kind: "Device",
                status: "Not connected", detail: "Historical handoff mentions only; no current Oracle route.",
                path: nil, isRunning: false,
                capabilities: [], limitations: ["Requires a separately authorized remote connector and identity verification."]
            )
        ]

        let projectPaths: [(String, String)] = [
            ("project-oracle-workspace", NSHomeDirectory() + "/AI-Handoff/Wayne-Unified-Command-v1/files/Oracle Agamemnon Protocol Overwatch 20261107/Workspace"),
            ("project-oracle-runtime", NSHomeDirectory() + "/Documents/ORACLE/Agamemnon"),
            ("project-mtt-source", NSHomeDirectory() + "/AI-Handoff/Wayne-Unified-Command-v1/files/Memory Pressure Product/App"),
            ("project-ai-handoff", NSHomeDirectory() + "/AI-Handoff")
        ]
        for (id, path) in projectPaths {
            let exists = FileManager.default.fileExists(atPath: path)
            rows.append(ConnectedResource(
                id: id, name: (path as NSString).lastPathComponent, kind: "Project",
                status: exists ? "Accessible" : "Missing", detail: path,
                path: path, isRunning: false,
                capabilities: exists ? ["Open local folder", "Read-only inventory"] : [],
                limitations: ["Project files are not modified by this read-only inventory."]
            ))
        }

        let appRoots = [URL(fileURLWithPath: "/Applications"), URL(fileURLWithPath: NSHomeDirectory()).appendingPathComponent("Applications")]
        for root in appRoots {
            guard let urls = try? FileManager.default.contentsOfDirectory(at: root, includingPropertiesForKeys: [.isDirectoryKey], options: [.skipsHiddenFiles]) else { continue }
            for url in urls where url.pathExtension == "app" {
                let info = url.appendingPathComponent("Contents/Info.plist")
                guard let data = try? Data(contentsOf: info),
                      let plist = try? PropertyListSerialization.propertyList(from: data, format: nil) as? [String: Any] else { continue }
                let bundle = plist["CFBundleIdentifier"] as? String ?? url.lastPathComponent
                let name = plist["CFBundleDisplayName"] as? String ?? plist["CFBundleName"] as? String ?? url.deletingPathExtension().lastPathComponent
                let version = plist["CFBundleShortVersionString"] as? String ?? "Unknown"
                let running = !NSRunningApplication.runningApplications(withBundleIdentifier: bundle).isEmpty
                rows.append(ConnectedResource(
                    id: "app-\(bundle)", name: name, kind: "Application",
                    status: running ? "Running" : "Installed", detail: "Version \(version) • \(bundle)",
                    path: url.path, isRunning: running,
                    capabilities: ["Open the existing app"], limitations: ["Launch/open only; no app-specific automation is implied."]
                ))
            }
        }
        var seen = Set<String>()
        return rows.filter { seen.insert($0.id).inserted }.sorted {
            if $0.kind != $1.kind { return $0.kind < $1.kind }
            return $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending
        }
    }
}
