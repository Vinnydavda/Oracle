import SwiftUI

private extension SchematicNodeState {
    var label: String {
        switch self {
        case .observed: return "Observed"
        case .stale: return "Stale"
        case .unknown: return "Unknown"
        case .denied: return "Denied"
        case .unavailable: return "Unavailable"
        case .notImplemented: return "Not implemented"
        }
    }

    var symbol: String {
        switch self {
        case .observed: return "checkmark.circle.fill"
        case .stale: return "clock.badge.exclamationmark"
        case .unknown: return "questionmark.circle"
        case .denied: return "hand.raised.slash"
        case .unavailable: return "wifi.slash"
        case .notImplemented: return "hammer"
        }
    }

    var tint: Color {
        switch self {
        case .observed: return OraclePalette.good
        case .stale: return OraclePalette.warning
        case .unknown: return OraclePalette.coolText.opacity(0.62)
        case .denied, .unavailable: return OraclePalette.danger
        case .notImplemented: return OraclePalette.ember
        }
    }
}

private extension SchematicConnectionState {
    var label: String {
        switch self {
        case .configured: return "Configured"
        case .notConnected: return "Not wired"
        case .unavailable: return "Unavailable"
        case .notImplemented: return "Not implemented"
        }
    }

    var color: Color {
        switch self {
        case .configured: return OraclePalette.good
        case .notConnected: return OraclePalette.coolText.opacity(0.55)
        case .unavailable: return OraclePalette.danger
        case .notImplemented: return OraclePalette.ember
        }
    }
}

struct SchematicsView: View {
    @ObservedObject var store: OracleWorkspaceStore
    @State private var mode = 0
    @State private var selectedNodeID: String?

    private var selectedNode: SchematicNode? {
        store.schematicGraph.nodes.first { $0.id == selectedNodeID }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .firstTextBaseline) {
                OracleSectionHeading(
                    eyebrow: "Interactive system map",
                    title: "Architecture and evidence flow",
                    detail: "Observed sources remain separate from planned or unavailable paths. Connections describe declared application flow, not inspected traffic."
                )
                Spacer()
                Picker("Schematic view", selection: $mode) {
                    Text("Map").tag(0)
                    Text("Accessible list").tag(1)
                }
                .labelsHidden()
                .pickerStyle(.segmented)
                .frame(width: 230)
                .tint(OraclePalette.violet)
                .accessibilityLabel("Schematic presentation")
            }

            if store.schematicGraph.nodes.isEmpty {
                ContentUnavailableView("Schematic not loaded", systemImage: "point.3.connected.trianglepath.dotted", description: Text("Runtime observations have not completed yet."))
                    .frame(maxWidth: .infinity, minHeight: 360)
            } else {
                ViewThatFits(in: .horizontal) {
                    HStack(alignment: .top, spacing: 12) {
                        schematicContent
                            .frame(minWidth: 620, minHeight: 470)
                        inspectorPanel
                            .frame(width: 340)
                    }
                    VStack(alignment: .leading, spacing: 12) {
                        schematicContent
                            .frame(minHeight: 470)
                        inspectorPanel
                    }
                }
            }
        }
        .onChange(of: store.schematicGraph.nodes.map(\.id)) { _, ids in
            if selectedNodeID == nil || !ids.contains(selectedNodeID ?? "") {
                selectedNodeID = ids.first
            }
        }
        .onAppear {
            if selectedNodeID == nil { selectedNodeID = store.schematicGraph.nodes.first?.id }
        }
        .oraclePageSurface()
    }

    @ViewBuilder
    private var schematicContent: some View {
        if mode == 0 {
            SchematicMapView(graph: store.schematicGraph, selectedNodeID: $selectedNodeID)
        } else {
            SchematicAccessibleList(graph: store.schematicGraph, selectedNodeID: $selectedNodeID)
        }
    }

    @ViewBuilder
    private var inspectorPanel: some View {
        if let selectedNode {
            SchematicInspector(node: selectedNode, graph: store.schematicGraph)
        } else {
            Text("Select a node to inspect its source, timestamp, evidence, capabilities, related paths, and limits.")
                .font(.footnote).foregroundStyle(.secondary)
                .padding(14)
                .frame(maxWidth: .infinity, alignment: .leading)
                .oracleGlassCard(cornerRadius: 14)
        }
    }
}

private struct SchematicMapView: View {
    let graph: SchematicGraph
    @Binding var selectedNodeID: String?

    @State private var zoom: CGFloat = 1
    @State private var pan: CGSize = .zero
    @State private var dragOrigin: CGSize = .zero
    @GestureState private var magnification: CGFloat = 1

    private let logicalSize = CGSize(width: 920, height: 560)

    private var effectiveZoom: CGFloat {
        min(2.2, max(0.65, zoom * magnification))
    }

    private var focusedConnectionIDs: Set<String> {
        guard let selectedNodeID else { return [] }
        return SchematicGraphFocus.relatedConnectionIDs(for: selectedNodeID, in: graph)
    }

    private var focusedNodeIDs: Set<String> {
        guard let selectedNodeID else { return [] }
        return SchematicGraphFocus.relatedNodeIDs(for: selectedNodeID, in: graph)
    }

    var body: some View {
        GeometryReader { proxy in
            ZStack(alignment: .topTrailing) {
                LinearGradient(colors: [OraclePalette.void.opacity(0.96), OraclePalette.deepPurple.opacity(0.74), Color.black.opacity(0.94)], startPoint: .topLeading, endPoint: .bottomTrailing)

                ZStack {
                    laneBackgrounds
                    ForEach(graph.connections) { connection in
                        connectionLayer(connection)
                    }
                    ForEach(graph.nodes) { node in
                        nodeButton(node)
                    }
                }
                .frame(width: logicalSize.width, height: logicalSize.height)
                .scaleEffect(effectiveZoom)
                .offset(pan)
                .frame(maxWidth: .infinity, maxHeight: .infinity)

                VStack(alignment: .trailing, spacing: 8) {
                    HStack(spacing: 6) {
                        Button { zoom = min(2.2, zoom + 0.15) } label: { Label("Zoom in", systemImage: "plus.magnifyingglass") }
                            .help("Zoom in")
                        Button { zoom = max(0.65, zoom - 0.15) } label: { Label("Zoom out", systemImage: "minus.magnifyingglass") }
                            .help("Zoom out")
                        Button { zoom = 1; pan = .zero; dragOrigin = .zero } label: { Label("Fit", systemImage: "arrow.up.left.and.arrow.down.right") }
                            .help("Fit schematic")
                    }
                    .labelStyle(.iconOnly)
                    .buttonStyle(.borderedProminent)
                    .tint(OraclePalette.violet)

                    Text("\(Int(effectiveZoom * 100))%")
                        .font(.caption.monospacedDigit())
                        .foregroundStyle(.secondary)
                        .accessibilityLabel("Schematic zoom \(Int(effectiveZoom * 100)) percent")

                    HStack(spacing: 10) {
                        legend("Observed", color: .green)
                        legend("Unknown", color: .secondary)
                        legend("Blocked", color: .red)
                        legend("Not implemented", color: .yellow)
                    }
                }
                .padding(12)
            }
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(OraclePalette.lavender.opacity(0.18)))
            .contentShape(Rectangle())
            .gesture(
                DragGesture(minimumDistance: 8)
                    .onChanged { value in
                        pan = CGSize(width: dragOrigin.width + value.translation.width,
                                     height: dragOrigin.height + value.translation.height)
                    }
                    .onEnded { _ in dragOrigin = pan }
            )
            .simultaneousGesture(
                MagnificationGesture()
                    .updating($magnification) { value, state, _ in state = value }
                    .onEnded { value in zoom = min(2.2, max(0.65, zoom * value)) }
            )
            .accessibilityElement(children: .contain)
            .accessibilityLabel("Interactive system schematic")
            .accessibilityValue("\(graph.nodes.count) nodes and \(graph.connections.count) declared connections")
            .onAppear { _ = proxy.size }
        }
    }

    private var laneBackgrounds: some View {
        ForEach(SchematicLane.allCases, id: \.self) { lane in
            let geometry = laneGeometry(lane)
            VStack(alignment: .leading, spacing: 6) {
                Text(lane.rawValue.uppercased())
                    .font(.caption2.weight(.bold))
                    .tracking(1.3)
                    .foregroundStyle(OraclePalette.lavender.opacity(0.72))
            }
            .padding(12)
            .frame(width: logicalSize.width * geometry.width, height: logicalSize.height - 24, alignment: .topLeading)
            .background(OraclePalette.void.opacity(lane == .approval ? 0.26 : 0.18), in: RoundedRectangle(cornerRadius: 16))
            .overlay(RoundedRectangle(cornerRadius: 16).stroke(OraclePalette.lavender.opacity(0.08)))
            .position(x: logicalSize.width * geometry.center, y: logicalSize.height / 2)
        }
    }

    private func laneGeometry(_ lane: SchematicLane) -> (center: CGFloat, width: CGFloat) {
        switch lane {
        case .sources: return (0.19, 0.35)
        case .analysis: return (0.59, 0.37)
        case .approval: return (0.89, 0.18)
        }
    }

    private func nodeButton(_ node: SchematicNode) -> some View {
        Button { selectedNodeID = node.id } label: {
            VStack(alignment: .leading, spacing: 5) {
                HStack(spacing: 6) {
                    Image(systemName: node.state.symbol).foregroundStyle(node.state.tint)
                    Text(node.title).font(.subheadline.weight(.semibold)).lineLimit(2)
                }
                Text(node.subtitle).font(.caption).foregroundStyle(.secondary).lineLimit(2)
                Text(node.state.label)
                    .font(.caption2.weight(.medium))
                    .foregroundStyle(node.state.tint)
            }
            .frame(width: 170, height: 82, alignment: .leading)
            .padding(10)
            .oracleGlassCard(cornerRadius: 13)
            .overlay(
                RoundedRectangle(cornerRadius: 13, style: .continuous)
                    .stroke(selectedNodeID == node.id ? OraclePalette.lavender : node.state.tint.opacity(0.55), lineWidth: selectedNodeID == node.id ? 2 : 1)
            )
            .contentShape(RoundedRectangle(cornerRadius: 13, style: .continuous))
        }
        .buttonStyle(.plain)
        .position(x: node.position.x * logicalSize.width, y: node.position.y * logicalSize.height)
        .accessibilityLabel(node.title)
        .accessibilityValue("\(node.state.label). \(node.subtitle)")
        .accessibilityHint("Show source, evidence, capabilities, and limitations")
        .opacity(selectedNodeID == nil || focusedNodeIDs.contains(node.id) ? 1 : 0.36)
    }

    private func connectionLayer(_ connection: SchematicConnection) -> some View {
        let endpoints = endpoints(for: connection)
        return ZStack {
            Path { path in
                let start = endpoints.start
                let end = endpoints.end
                let bend = max(44, abs(end.x - start.x) * 0.45)
                path.move(to: start)
                path.addCurve(to: end,
                              control1: CGPoint(x: start.x + bend, y: start.y),
                              control2: CGPoint(x: end.x - bend, y: end.y))
            }
            .stroke(connection.state.color.opacity(selectedNodeID == nil || focusedConnectionIDs.contains(connection.id) ? 0.92 : 0.16),
                    style: StrokeStyle(lineWidth: focusedConnectionIDs.contains(connection.id) ? 3 : 1.5, lineCap: .round, dash: connection.state == .configured ? [] : [6, 5]))

            Text(connection.label)
                .font(.caption2.weight(.medium))
                .foregroundStyle(connection.state.color.opacity(selectedNodeID == nil || focusedConnectionIDs.contains(connection.id) ? 1 : 0.22))
                .padding(.horizontal, 7).padding(.vertical, 3)
                .background(OraclePalette.void.opacity(0.88), in: Capsule())
                .position(x: (endpoints.start.x + endpoints.end.x) / 2,
                          y: (endpoints.start.y + endpoints.end.y) / 2 - 10)
                .opacity(selectedNodeID == nil || focusedConnectionIDs.contains(connection.id) ? 1 : 0.22)
        }
        .accessibilityHidden(true)
    }

    private func endpoints(for connection: SchematicConnection) -> (start: CGPoint, end: CGPoint) {
        let from = graph.nodes.first { $0.id == connection.from }?.position ?? SchematicPoint(x: 0.5, y: 0.5)
        let to = graph.nodes.first { $0.id == connection.to }?.position ?? SchematicPoint(x: 0.5, y: 0.5)
        let startX = from.x * logicalSize.width
        let startY = from.y * logicalSize.height
        let endX = to.x * logicalSize.width
        let endY = to.y * logicalSize.height
        if abs(endX - startX) < 40 {
            return (CGPoint(x: startX, y: startY + 48), CGPoint(x: endX, y: endY - 48))
        }
        let direction: CGFloat = endX > startX ? 1 : -1
        return (CGPoint(x: startX + direction * 90, y: startY),
                CGPoint(x: endX - direction * 90, y: endY))
    }

    private func legend(_ text: String, color: Color) -> some View {
        HStack(spacing: 4) {
            Circle().fill(color).frame(width: 7, height: 7)
            Text(text).font(.caption2).foregroundStyle(OraclePalette.coolText.opacity(0.62))
        }
    }
}

private struct SchematicAccessibleList: View {
    let graph: SchematicGraph
    @Binding var selectedNodeID: String?

    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 10) {
                Text("Accessible node list").font(.headline)
                Text("This list exposes the same nodes and evidence as the map without requiring zoom, pan, or pointer precision.")
                    .font(.footnote).foregroundStyle(.secondary)
                ForEach(graph.nodes) { node in
                    Button { selectedNodeID = node.id } label: {
                        HStack(alignment: .top, spacing: 10) {
                            Image(systemName: node.state.symbol).foregroundStyle(node.state.tint).frame(width: 22)
                            VStack(alignment: .leading, spacing: 3) {
                                Text(node.title).font(.body.weight(.semibold))
                                Text(node.subtitle).font(.caption).foregroundStyle(.secondary)
                                Text("\(node.state.label) • \(node.source)").font(.caption2).foregroundStyle(.secondary)
                            }
                            Spacer()
                            if selectedNodeID == node.id { Image(systemName: "checkmark.circle.fill").foregroundStyle(.white) }
                        }
                        .padding(12)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .oracleGlassCard(cornerRadius: 11)
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("\(node.title), \(node.state.label)")
                    .accessibilityHint("Show details")
                }
                Divider().padding(.vertical, 4)
                Text("Declared connections").font(.headline)
                ForEach(graph.connections) { connection in
                    HStack(alignment: .top, spacing: 8) {
                        Circle().fill(connection.state.color).frame(width: 8, height: 8).padding(.top, 5)
                        VStack(alignment: .leading, spacing: 2) {
                            Text("\(nodeName(connection.from)) → \(nodeName(connection.to))").font(.body)
                            Text("\(connection.label): \(connection.state.label)").font(.caption).foregroundStyle(.secondary)
                            Text(connection.evidence).font(.caption2).foregroundStyle(.secondary)
                        }
                    }
                }
            }
        }
    }

    private func nodeName(_ id: String) -> String {
        graph.nodes.first { $0.id == id }?.title ?? id
    }
}

private struct SchematicInspector: View {
    let node: SchematicNode
    let graph: SchematicGraph

    private var relatedConnections: [SchematicConnection] {
        graph.connections.filter { $0.from == node.id || $0.to == node.id }
    }

    private var nextSafeAction: String {
        switch node.state {
        case .observed: return "Review the cited evidence. No automatic action is implied."
        case .stale: return "Refresh the source and confirm a new timestamped observation before relying on it."
        case .unknown: return "Collect a fresh authorized observation; do not infer health."
        case .denied, .unavailable: return "Resolve the permission or connector boundary, then remeasure."
        case .notImplemented: return "Owner design and approval are required before implementation."
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Image(systemName: node.state.symbol).foregroundStyle(node.state.tint).font(.title3)
                VStack(alignment: .leading, spacing: 2) {
                    Text(node.title).font(.headline)
                    Text("\(node.state.label) • \(node.kind.rawValue.capitalized) • \(node.observedAt.formatted(date: .abbreviated, time: .standard))")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
            }
            InfoRow(key: "Source", value: node.source)
            InfoRow(key: "Next safe action", value: nextSafeAction)
            detailSection("Evidence", values: node.evidence)
            detailSection("Capabilities", values: node.capabilities)
            detailSection("Limits", values: node.limitations)
            Divider().overlay(OraclePalette.lavender.opacity(0.12))
            Text("Related paths").font(.caption.weight(.semibold)).foregroundStyle(.secondary)
            if relatedConnections.isEmpty {
                Text("No declared path touches this node.").font(.footnote).foregroundStyle(.secondary)
            } else {
                ForEach(relatedConnections) { connection in
                    VStack(alignment: .leading, spacing: 2) {
                        Text("\(nodeName(connection.from)) → \(nodeName(connection.to))")
                            .font(.footnote.weight(.semibold))
                        Text("\(connection.label): \(connection.state.label)")
                            .font(.caption2).foregroundStyle(connection.state.color)
                        Text(connection.evidence)
                            .font(.caption2).foregroundStyle(.secondary)
                    }
                    .padding(8)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(OraclePalette.void.opacity(0.28), in: RoundedRectangle(cornerRadius: 8))
                }
            }
        }
        .padding(14)
        .oracleGlassCard(cornerRadius: 14)
    }

    private func nodeName(_ id: String) -> String {
        graph.nodes.first { $0.id == id }?.title ?? id
    }

    private func detailSection(_ title: String, values: [String]) -> some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(title).font(.caption.weight(.semibold)).foregroundStyle(.secondary)
            if values.isEmpty {
                Text("None reported.").font(.footnote).foregroundStyle(.secondary)
            } else {
                ForEach(values, id: \.self) { value in
                    Text("• \(value)").font(.footnote).textSelection(.enabled)
                }
            }
        }
    }
}
