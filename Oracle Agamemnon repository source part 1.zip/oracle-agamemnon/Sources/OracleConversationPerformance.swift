import Foundation

/// Conversation lifecycle, derived from the existing single voice, dictation,
/// and local-model session. This does not claim facial or 3D animation.
enum OracleConversationPhase: String, Equatable {
    case idle
    case awaitingPermission
    case listening
    case processing
    case speaking
    case interrupted
    case error
}

struct OracleConversationSignals: Equatable {
    var microphoneStarting = false
    var microphoneCapturing = false
    var modelStreaming = false
    var voicePreparing = false
    var voicePlaying = false
    var interrupted = false
    var failed = false
}

enum OracleConversationPerformance {
    static func phase(_ signals: OracleConversationSignals) -> OracleConversationPhase {
        // Active capture wins over other status so the UI never masks a live
        // microphone behind a speaking or processing animation.
        if signals.microphoneCapturing { return .listening }
        if signals.microphoneStarting { return .awaitingPermission }
        if signals.voicePlaying { return .speaking }
        if signals.modelStreaming || signals.voicePreparing { return .processing }
        if signals.interrupted { return .interrupted }
        if signals.failed { return .error }
        return .idle
    }

    static func visualMode(_ phase: OracleConversationPhase) -> OracleMotionMode {
        switch phase {
        case .listening: return .listening
        case .processing: return .thinking
        case .speaking: return .speaking
        case .idle, .awaitingPermission, .interrupted, .error: return .idle
        }
    }
}
