import Foundation
import SceneKit

/// Stable points on the imported, deforming Oracle body. It does not render
/// dust; an appearance layer can consume these positions after asset approval.
final class OracleSkinnedSurfaceSampler {
    struct Influence {
        let boneIndex: Int
        let weight: CGFloat
    }

    struct Anchor {
        let vertexIndex: Int
        let localPosition: SCNVector3
        let influences: [Influence]
    }

    enum SamplingError: Error {
        case missingSkinner
        case unsupportedGeometryFormat
        case invalidBoneData
    }

    private let mesh: SCNNode
    private let bones: [SCNNode]
    private let inverseBinds: [SCNMatrix4]
    private let positionSource: SCNGeometrySource
    private let weightSource: SCNGeometrySource
    private let indexSource: SCNGeometrySource

    init(mesh: SCNNode) throws {
        guard let geometry = mesh.geometry, let skinner = mesh.skinner,
              let positions = geometry.sources(for: .vertex).first,
              let binds = skinner.boneInverseBindTransforms else {
            throw SamplingError.missingSkinner
        }
        let weights = skinner.boneWeights
        let indices = skinner.boneIndices
        guard positions.usesFloatComponents, positions.componentsPerVector == 3, positions.bytesPerComponent == 4,
              weights.usesFloatComponents, weights.componentsPerVector == 4, weights.bytesPerComponent == 4,
              !indices.usesFloatComponents, indices.componentsPerVector == 4, indices.bytesPerComponent == 2,
              positions.vectorCount == weights.vectorCount, positions.vectorCount == indices.vectorCount else {
            throw SamplingError.unsupportedGeometryFormat
        }
        guard binds.count == skinner.bones.count, !binds.isEmpty else {
            throw SamplingError.invalidBoneData
        }
        self.mesh = mesh
        self.bones = skinner.bones
        self.inverseBinds = binds.map(\.scnMatrix4Value)
        self.positionSource = positions
        self.weightSource = weights
        self.indexSource = indices
    }

    var vertexCount: Int { positionSource.vectorCount }
    var boneCount: Int { bones.count }

    /// Deterministic vertices prevent visible particle anchors jumping when
    /// a scene is resized or recreated. This is a sampling primitive only;
    /// the final dust distribution still needs art direction and density QA.
    func anchors(count: Int, seed: UInt64 = 0x0AC1E) throws -> [Anchor] {
        guard count > 0, vertexCount > 0 else { return [] }
        var state = seed == 0 ? 1 : seed
        let target = min(count, vertexCount)
        var selected = Array(0..<target)
        if target < vertexCount {
            for index in target..<vertexCount {
                state = state &* 2862933555777941757 &+ 3037000493
                let replacement = Int(state % UInt64(index + 1))
                if replacement < target { selected[replacement] = index }
            }
        }
        return try selected.sorted().map(anchor(at:))
    }

    func anchor(at vertexIndex: Int) throws -> Anchor {
        guard (0..<vertexCount).contains(vertexIndex) else { throw SamplingError.unsupportedGeometryFormat }
        let offset = positionSource.dataOffset + vertexIndex * positionSource.dataStride
        let values: [Float] = (0..<3).map { component in
            positionSource.data.withUnsafeBytes {
                $0.loadUnaligned(fromByteOffset: offset + component * 4, as: Float.self)
            }
        }
        let local = SCNVector3(values[0], values[1], values[2])
        let weightOffset = weightSource.dataOffset + vertexIndex * weightSource.dataStride
        let indexOffset = indexSource.dataOffset + vertexIndex * indexSource.dataStride
        var influences: [Influence] = []
        for component in 0..<4 {
            let value = weightSource.data.withUnsafeBytes {
                $0.loadUnaligned(fromByteOffset: weightOffset + component * 4, as: Float.self)
            }
            guard value.isFinite, value >= 0 else { throw SamplingError.invalidBoneData }
            guard value > 0 else { continue }
            let boneIndex = Int(indexSource.data.withUnsafeBytes {
                $0.loadUnaligned(fromByteOffset: indexOffset + component * 2, as: UInt16.self)
            })
            guard bones.indices.contains(boneIndex) else { throw SamplingError.invalidBoneData }
            influences.append(Influence(boneIndex: boneIndex, weight: CGFloat(value)))
        }
        let total = influences.reduce(CGFloat.zero) { $0 + $1.weight }
        guard abs(total - 1) <= 0.01 else { throw SamplingError.invalidBoneData }
        return Anchor(vertexIndex: vertexIndex, localPosition: local, influences: influences)
    }

    func worldPositions(for anchors: [Anchor]) -> [SCNVector3] {
        let matrices = zip(inverseBinds, bones).map { bind, bone in
            SCNMatrix4Mult(bind, bone.worldTransform)
        }
        return anchors.map { anchor in
            var result = SCNVector3Zero
            for influence in anchor.influences {
                let matrix = matrices[influence.boneIndex]
                let point = anchor.localPosition
                result.x += influence.weight * (point.x * matrix.m11 + point.y * matrix.m21 + point.z * matrix.m31 + matrix.m41)
                result.y += influence.weight * (point.x * matrix.m12 + point.y * matrix.m22 + point.z * matrix.m32 + matrix.m42)
                result.z += influence.weight * (point.x * matrix.m13 + point.y * matrix.m23 + point.z * matrix.m33 + matrix.m43)
            }
            return result
        }
    }

    func restWorldPosition(of anchor: Anchor) -> SCNVector3 {
        mesh.convertPosition(anchor.localPosition, to: nil)
    }
}
