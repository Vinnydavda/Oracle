import AppKit
import SwiftUI

enum OraclePresentationMode: String {
    case workspace
    case immersive
    case compact
}

/// One window and one OracleWorkspaceStore own every presentation. This class
/// changes only window geometry; conversation, capture, model and voice objects
/// remain owned by the existing store.
@MainActor
final class OracleWindowPresentation {
    private weak var window: NSWindow?
    private var workspaceFrame: NSRect?
    private let workspaceFrameKey = "app.oracle.agamemnon.security.workspaceFrameBeforeCompact"

    func attach(_ window: NSWindow) {
        self.window = window
        window.collectionBehavior.insert(.fullScreenPrimary)
        if let encoded = UserDefaults.standard.string(forKey: workspaceFrameKey) {
            let frame = NSRectFromString(encoded)
            if frame.width >= 900 && frame.height >= 620 {
                workspaceFrame = frame
                if window.frame.width < 900 || window.frame.height < 620 {
                    window.setFrame(fit(frame, on: window.screen), display: true)
                }
            }
        }
    }

    var isFullScreen: Bool { window?.styleMask.contains(.fullScreen) ?? false }

    func setAlwaysOnTop(_ enabled: Bool) {
        window?.level = enabled ? .floating : .normal
    }

    func toggleNativeFullScreen() {
        window?.toggleFullScreen(nil)
    }

    /// Returns false if the requested compact transition must wait until the
    /// owner exits native full screen. Native Minimize is never repurposed.
    func apply(_ next: OraclePresentationMode, previous: OraclePresentationMode) -> Bool {
        guard let window else { return false }
        if next == .compact {
            guard !isFullScreen else { return false }
            if previous != .compact {
                workspaceFrame = window.frame
                UserDefaults.standard.set(NSStringFromRect(window.frame), forKey: workspaceFrameKey)
            }
            window.minSize = NSSize(width: 360, height: 440)
            let visible = window.screen?.visibleFrame ?? NSScreen.main?.visibleFrame ?? window.frame
            let width = min(460.0, visible.width)
            let height = min(620.0, visible.height)
            let target = NSRect(x: max(visible.minX, visible.maxX - width - 24),
                                y: max(visible.minY, visible.maxY - height - 24),
                                width: width, height: height)
            window.setFrame(target, display: true, animate: true)
        } else if previous == .compact {
            window.minSize = NSSize(width: 900, height: 620)
            let target = workspaceFrame ?? NSRect(x: 120, y: 120, width: 1200, height: 780)
            window.setFrame(fit(target, on: window.screen), display: true, animate: true)
        }
        return true
    }

    private func fit(_ desired: NSRect, on screen: NSScreen?) -> NSRect {
        let visible = screen?.visibleFrame ?? NSScreen.main?.visibleFrame ?? desired
        let width = min(max(900, desired.width), visible.width)
        let height = min(max(620, desired.height), visible.height)
        let x = min(max(desired.minX, visible.minX), visible.maxX - width)
        let y = min(max(desired.minY, visible.minY), visible.maxY - height)
        return NSRect(x: x, y: y, width: width, height: height)
    }
}

/// Full-window presence and small companion are views of the same store.
/// The approved reference remains visible while the 3D asset fails its gate.
struct OraclePresenceView: View {
    @ObservedObject var store: OracleWorkspaceStore
    @ObservedObject private var voice: OracleVoiceController
    @ObservedObject private var dictation: OracleDictationController
    @State private var showTranscript = false

    init(store: OracleWorkspaceStore) {
        self.store = store
        _voice = ObservedObject(wrappedValue: store.voiceController)
        _dictation = ObservedObject(wrappedValue: store.dictationController)
    }

    private var compact: Bool { store.presentationMode == .compact }
    private var phase: OracleConversationPhase {
        OracleConversationPerformance.phase(.init(
            microphoneStarting: dictation.isStarting,
            microphoneCapturing: dictation.isListening,
            modelStreaming: store.modelState == .streaming,
            voicePreparing: voice.state == .preparing,
            voicePlaying: voice.isSpeaking,
            failed: voice.state == .failed || dictation.lastError != nil ||
                store.modelState == .failed || store.modelState == .timeout || store.modelState == .unavailable
        ))
    }
    private var pose: OracleHumanoidPose {
        switch OracleConversationPerformance.visualMode(phase) {
        case .listening: return .listening
        case .thinking: return .thinking
        case .speaking: return .speaking
        default: return .idle
        }
    }

    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .top) {
                Group {
                    if store.show3DCandidate {
                        Oracle3DCandidateView()
                    } else {
                        OracleHumanoidView(
                            pose: pose,
                            measuredVoiceAmplitude: voice.measuredAmplitude,
                            speechProgress: voice.speechProgress,
                            motionMode: store.motionMode,
                            gesture: store.gestureCue,
                            expressionOverride: store.modelBehaviorExpression ?? store.maskExpression
                        )
                    }
                }
                .frame(width: geometry.size.width, height: geometry.size.height)

                VStack(spacing: 10) {
                    HStack(spacing: 8) {
                        Text(store.show3DCandidate ? "ORACLE • 3D CANDIDATE • VISUAL GATE FAILED" : "ORACLE • APPROVED REFERENCE")
                            .font(.caption2.weight(.bold)).tracking(1)
                            .lineLimit(1)
                        Spacer(minLength: 4)
                        if !compact {
                            Button(store.isNativeFullScreen ? "Exit full screen" : "Native full screen") { store.toggleNativeFullScreen() }
                                .accessibilityLabel("Toggle native full screen")
                            Button("Compact") { store.setPresentationMode(.compact) }
                                .disabled(store.isNativeFullScreen)
                                .accessibilityLabel("Open compact companion in the same window")
                        }
                        Button(compact ? "Expand" : "Workspace") { store.setPresentationMode(.workspace) }
                            .accessibilityLabel(compact ? "Restore Oracle workspace" : "Exit immersive Oracle")
                    }
                    .buttonStyle(.bordered)
                    .controlSize(.small)

                    Spacer(minLength: 0)

                    if showTranscript && !compact {
                        transcriptPanel
                            .frame(maxWidth: min(540, geometry.size.width - 28), maxHeight: geometry.size.height * 0.44)
                            .transition(.opacity)
                    }

                    VStack(alignment: .leading, spacing: 8) {
                        HStack(spacing: 8) {
                            Text("\(phase.rawValue) • \(voice.state.label)")
                                .font(.caption.weight(.semibold))
                                .lineLimit(1)
                            Spacer(minLength: 2)
                            if dictation.isStarting || dictation.isListening {
                                Label("Microphone active or starting", systemImage: "mic.fill")
                                    .labelStyle(.iconOnly)
                                    .foregroundStyle(OraclePalette.warning)
                                    .accessibilityLabel(dictation.isListening ? "Microphone capturing" : "Microphone starting")
                            } else {
                                Image(systemName: "mic.slash")
                                    .accessibilityLabel("Microphone off")
                            }
                        }
                        if compact, let last = store.messages.last(where: { !$0.text.isEmpty }) {
                            Text(last.text).font(.caption).lineLimit(2)
                                .accessibilityLabel("Latest \(last.role) message: \(last.text)")
                        }
                        HStack(spacing: 8) {
                            Button(dictation.isListening ? (store.voiceConversationEnabled ? "Send voice" : "Stop listening") : dictation.isStarting ? "Cancel listen" : "Listen") {
                                toggleListening()
                            }
                            Button(voice.isMuted ? "Unmute output" : "Mute output") {
                                let muting = !voice.isMuted
                                voice.setMuted(muting)
                                if muting { store.cancelModelBehavior() }
                            }
                            .accessibilityHint("Controls Oracle audio; microphone listening is separate")
                            if !compact {
                                Button("Stop voice") { voice.stop(); store.cancelModelBehavior() }
                                    .disabled(!voice.isSpeaking && voice.state != .preparing)
                            }
                            Button("Stop turn") {
                                dictation.stop()
                                store.cancelRequest()
                                voice.stop()
                                store.cancelModelBehavior()
                            }
                            .accessibilityLabel("Stop listening, model response, and voice playback")
                            if !compact {
                                Button(showTranscript ? "Hide transcript" : "Transcript") { showTranscript.toggle() }
                            }
                            Spacer(minLength: 0)
                        }
                        .buttonStyle(.bordered)
                        .controlSize(.small)
                        Toggle("Send dictated turns and speak local replies", isOn: $store.voiceConversationEnabled)
                            .font(.caption)
                        if compact {
                            Toggle("Stay on top", isOn: Binding(
                                get: { store.companionAlwaysOnTop },
                                set: { store.setCompanionAlwaysOnTop($0) }
                            ))
                            .font(.caption)
                            Button("Conversation and controls") { store.setPresentationMode(.workspace) }
                                .buttonStyle(.link)
                                .accessibilityLabel("Open full Oracle conversation and controls")
                        }
                    }
                    .padding(12)
                    .background(OraclePalette.void.opacity(0.88), in: RoundedRectangle(cornerRadius: 14))
                }
                .padding(compact ? 12 : 18)
            }
        }
        .onExitCommand { store.setPresentationMode(.workspace) }
        .preferredColorScheme(.dark)
    }

    private var transcriptPanel: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Conversation").font(.headline)
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 8) {
                    ForEach(store.messages) { message in
                        VStack(alignment: .leading, spacing: 2) {
                            Text(message.role.uppercased()).font(.caption2.weight(.bold))
                            Text(message.text.isEmpty && message.state == .streaming ? "Responding locally…" : message.text)
                                .font(.callout).textSelection(.enabled)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
            }
            HStack {
                TextField("Ask Oracle", text: Binding(get: { store.draft }, set: { store.setDraft($0) }))
                    .textFieldStyle(.roundedBorder)
                if store.modelState == .streaming {
                    Button("Cancel") { store.cancelRequest() }
                } else {
                    Button("Send") { dictation.stop(); store.send(store.draft) }
                        .disabled(store.draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
        }
        .padding(14)
        .background(OraclePalette.void.opacity(0.92), in: RoundedRectangle(cornerRadius: 14))
    }

    private func toggleListening() {
        if dictation.isStarting {
            dictation.stop()
        } else if dictation.isListening {
            let finalTranscript = dictation.transcript
            dictation.stop()
            if store.voiceConversationEnabled { store.send(finalTranscript) }
        } else {
            voice.stop()
            dictation.start { transcript in store.setDraft(transcript) }
        }
    }
}
