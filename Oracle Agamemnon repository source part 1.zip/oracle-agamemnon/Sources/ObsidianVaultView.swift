import SwiftUI

struct ObsidianVaultView: View {
    @ObservedObject var store: OracleWorkspaceStore
    @State private var searchText = ""

    private var filteredNotes: [ObsidianNote] {
        let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !query.isEmpty else { return store.obsidianIndex.notes }
        return store.obsidianIndex.notes.filter {
            $0.title.localizedCaseInsensitiveContains(query) || $0.relativePath.localizedCaseInsensitiveContains(query)
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(alignment: .top, spacing: 14) {
                Image(systemName: "books.vertical.fill")
                    .font(.system(size: 34))
                    .foregroundStyle(OraclePalette.magenta)
                    .accessibilityHidden(true)
                OracleSectionHeading(
                    eyebrow: "Local knowledge",
                    title: "Obsidian knowledge project",
                    detail: "Read-only Markdown access. A note reaches Oracle only through an explicit attach action."
                )
                Spacer()
                HStack(spacing: 8) {
                    Button("Choose Vault…") { store.chooseObsidianVault() }
                        .buttonStyle(.borderedProminent)
                        .tint(OraclePalette.violet)
                    if store.obsidianVaultPath != nil {
                        Button("Refresh") { store.refreshObsidianVault() }
                            .buttonStyle(.bordered)
                        Button("Disconnect", role: .destructive) { store.disconnectObsidianVault() }
                    }
                }
            }

            statusCard

            if let error = store.obsidianError {
                Label(error, systemImage: "exclamationmark.triangle.fill")
                    .font(.footnote)
                    .foregroundStyle(.orange)
                    .padding(10)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.orange.opacity(0.09), in: RoundedRectangle(cornerRadius: 10))
            }

            if store.obsidianVaultPath == nil {
                ContentUnavailableView(
                    "Obsidian vault not configured",
                    systemImage: "folder.badge.questionmark",
                    description: Text("Choose the local folder that contains your Obsidian vault and its .obsidian directory.")
                )
                .frame(maxWidth: .infinity, minHeight: 260)
            } else {
                HStack(alignment: .top, spacing: 16) {
                    noteBrowser
                        .frame(minWidth: 300, idealWidth: 340, maxWidth: 380)
                    notePreview
                        .frame(maxWidth: .infinity)
                }
            }
        }
        .oraclePageSurface()
    }

    private var statusCard: some View {
        HStack(spacing: 10) {
            Image(systemName: statusSymbol)
                .foregroundStyle(statusColor)
            VStack(alignment: .leading, spacing: 2) {
                Text(statusTitle).font(.headline)
                Text(statusDetail).font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
            if let path = store.obsidianVaultPath {
                Text(URL(fileURLWithPath: path).lastPathComponent)
                    .font(.caption.weight(.medium))
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                    .truncationMode(.middle)
                    .help(path)
            }
        }
        .padding(13)
        .oracleGlassCard(cornerRadius: 13)
        .accessibilityElement(children: .combine)
        .accessibilityLabel("Obsidian status: \(statusTitle). \(statusDetail)")
    }

    private var noteBrowser: some View {
        VStack(alignment: .leading, spacing: 8) {
            TextField("Search notes", text: $searchText)
                .textFieldStyle(.roundedBorder)
                .accessibilityLabel("Search Obsidian notes")
            Text("\(filteredNotes.count) note(s)").font(.caption).foregroundStyle(.secondary)
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 6) {
                    if filteredNotes.isEmpty {
                        Text("No matching Markdown notes.").font(.footnote).foregroundStyle(.secondary).padding(12)
                    }
                    ForEach(filteredNotes) { note in
                        Button { store.selectObsidianNote(note) } label: {
                            HStack(spacing: 8) {
                                Image(systemName: "doc.text")
                                    .foregroundStyle(OraclePalette.magenta)
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(note.title).font(.body.weight(.medium)).lineLimit(1)
                                    Text(note.relativePath).font(.caption2).foregroundStyle(.secondary).lineLimit(1)
                                }
                                Spacer()
                                if store.obsidianSelectedNote?.relativePath == note.relativePath {
                                    Image(systemName: "checkmark.circle.fill").foregroundStyle(.white)
                                }
                            }
                            .padding(9)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(
                                store.obsidianSelectedNote?.relativePath == note.relativePath
                                    ? OraclePalette.violet.opacity(0.34)
                                    : OraclePalette.void.opacity(0.38),
                                in: RoundedRectangle(cornerRadius: 9)
                            )
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("\(note.title), \(note.relativePath)")
                        .accessibilityHint("Preview this Obsidian note")
                    }
                }
            }
            .frame(minHeight: 300, maxHeight: 430)
        }
        .padding(13)
        .oracleGlassCard(cornerRadius: 14)
    }

    private var notePreview: some View {
        VStack(alignment: .leading, spacing: 10) {
            if let note = store.obsidianSelectedNote, let preview = store.obsidianPreview {
                HStack(alignment: .firstTextBaseline) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(note.title).font(.headline)
                        Text(note.relativePath).font(.caption).foregroundStyle(.secondary).textSelection(.enabled)
                    }
                    Spacer()
                    Button(store.obsidianContext?.relativePath == note.relativePath ? "Attached to Oracle" : "Use in Oracle") {
                        store.attachObsidianPreviewToOracle()
                    }
                    .disabled(store.obsidianContext?.relativePath == note.relativePath)
                    .accessibilityHint("Attach this note as untrusted reference data for the next Oracle request")
                }
                if preview.truncated {
                    Label("Preview truncated at 12,000 characters.", systemImage: "scissors")
                        .font(.caption).foregroundStyle(.orange)
                }
                ScrollView {
                    Text(preview.text)
                        .font(.system(.body, design: .monospaced))
                        .textSelection(.enabled)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(12)
                }
                .background(OraclePalette.void.opacity(0.54), in: RoundedRectangle(cornerRadius: 10))
                .overlay(RoundedRectangle(cornerRadius: 10).stroke(OraclePalette.lavender.opacity(0.12)))
                Text("Read-only preview • Notes are treated as untrusted data and never grant tools or permissions.")
                    .font(.caption2).foregroundStyle(.secondary)
            } else {
                ContentUnavailableView(
                    "Select a note",
                    systemImage: "doc.text.magnifyingglass",
                    description: Text("Choose a Markdown note to inspect it or attach bounded context to Oracle.")
                )
                .frame(maxWidth: .infinity, minHeight: 300)
            }
        }
        .padding(13)
        .oracleGlassCard(cornerRadius: 14)
    }

    private var statusTitle: String {
        switch store.obsidianIndex.state {
        case .notConfigured: return "Not configured"
        case .invalid: return "Invalid vault"
        case .ready(let count): return "Connected • \(count) notes"
        case .error: return "Unavailable"
        }
    }

    private var statusDetail: String {
        switch store.obsidianIndex.state {
        case .notConfigured:
            return "Choose a local vault. No notes are being read."
        case .invalid(let reason):
            return reason
        case .ready:
            return "Scanned \(store.obsidianIndex.scannedAt.formatted(date: .abbreviated, time: .standard)) • read-only"
        case .error(let reason):
            return reason
        }
    }

    private var statusSymbol: String {
        switch store.obsidianIndex.state {
        case .notConfigured: return "questionmark.circle"
        case .invalid, .error: return "exclamationmark.triangle.fill"
        case .ready: return "checkmark.circle.fill"
        }
    }

    private var statusColor: Color {
        switch store.obsidianIndex.state {
        case .notConfigured: return .secondary
        case .invalid, .error: return OraclePalette.danger
        case .ready: return OraclePalette.good
        }
    }
}
