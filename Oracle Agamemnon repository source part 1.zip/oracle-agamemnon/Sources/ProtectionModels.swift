import Foundation

enum ProtectionCapabilityStatus: String, Codable, CaseIterable {
    case verified
    case implementedUnverified
    case missing
    case blocked
    case systemManaged

    var label: String {
        switch self {
        case .verified: return "Verified"
        case .implementedUnverified: return "Implemented · unverified"
        case .missing: return "Missing"
        case .blocked: return "Blocked"
        case .systemManaged: return "System-managed"
        }
    }
}

struct ProtectionCapability: Identifiable, Hashable {
    let id: String
    let name: String
    let layer: String
    let status: ProtectionCapabilityStatus
    let evidence: String
    let limitations: String
}

enum ProtectionSeverity: String, Codable, CaseIterable, Comparable {
    case info
    case low
    case medium
    case high
    case critical

    static func < (lhs: ProtectionSeverity, rhs: ProtectionSeverity) -> Bool {
        rank(lhs) < rank(rhs)
    }

    private static func rank(_ value: ProtectionSeverity) -> Int {
        switch value {
        case .info: return 0
        case .low: return 1
        case .medium: return 2
        case .high: return 3
        case .critical: return 4
        }
    }
}

enum ProtectionReviewStatus: String, Codable, CaseIterable {
    case open
    case acknowledged
    case falsePositive
    case resolved

    var label: String {
        switch self {
        case .open: return "Open"
        case .acknowledged: return "Acknowledged"
        case .falsePositive: return "False positive"
        case .resolved: return "Resolved"
        }
    }
}

struct ProtectionFinding: Identifiable, Codable, Hashable {
    var id: UUID
    var dedupeKey: String
    var createdAt: Date
    var lastObservedAt: Date
    var occurrences: Int
    var title: String
    var severity: ProtectionSeverity
    var source: String
    var resource: String
    var evidence: [String]
    var rationale: String
    var confidence: String
    var reviewStatus: ProtectionReviewStatus
    var canQuarantine: Bool
}

struct ProtectionEvent: Identifiable, Codable, Hashable {
    let id: UUID
    let observedAt: Date
    let kind: String
    let severity: ProtectionSeverity
    let source: String
    let summary: String
    let resource: String
    let evidence: [String]
    let dedupeKey: String
}

struct ProtectionScanReport: Identifiable, Hashable {
    let id: UUID
    let rootPath: String
    let startedAt: Date
    let completedAt: Date
    let filesInspected: Int
    let bytesInspected: UInt64
    let findings: [ProtectionFinding]
    let warnings: [String]
    let engine: String
    let cancelled: Bool
}

struct QuarantineRecord: Identifiable, Codable, Hashable {
    let id: UUID
    let originalPath: String
    let payloadPath: String
    let sha256: String
    let sizeBytes: UInt64
    let modifiedAt: Date?
    let quarantinedAt: Date
    let findingTitle: String
    let dedupeKey: String
    var restoredAt: Date?
}

struct ProtectionPreferences: Codable, Equatable {
    var scheduledScanEnabled: Bool = false
    var scheduledIntervalHours: Int = 24
    var lastScheduledScanAt: Date?
}

struct ProtectionPosture: Hashable {
    let observedAt: Date
    let macosVersion: String
    let fileVault: String
    let gatekeeper: String
    let sip: String
    let firewall: String
    let xprotectVersion: String
    let timeMachineDestinations: Int
}

struct ProcessObservation: Hashable {
    let pid: Int32
    let parentPID: Int32
    let user: String
    let cpuPercent: Double
    let memoryPercent: Double
    let executable: String
}

struct ConnectionObservation: Hashable {
    let pid: Int32
    let command: String
    let endpoint: String
}

struct PersistenceObservation: Hashable {
    let name: String
    let path: String
    let program: String
    let arguments: [String]
    let isDaemon: Bool
}

struct ProtectionAuditResult: Hashable {
    let observedAt: Date
    let posture: ProtectionPosture
    let processes: [ProcessObservation]
    let connections: [ConnectionObservation]
    let persistence: [PersistenceObservation]
    let findings: [ProtectionFinding]
    let warnings: [String]
}

struct SecurityPromptContext: Hashable {
    let title: String
    let content: String
}
