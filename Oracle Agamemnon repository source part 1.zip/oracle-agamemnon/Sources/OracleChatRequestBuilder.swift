import Foundation

struct PreparedOracleChatRequest {
    let body: Data
    let outboundNote: ObsidianNoteContent?
    let noteWasTruncated: Bool
    let historyWasTruncated: Bool
}

struct OracleChatHistoryTurn {
    let role: String
    let text: String
}

enum OracleChatRequestBuilder {
    static let maximumMessageBytes = 8_192
    static let maximumBodyBytes = 16_384
    static let initialNoteCharacters = 6_000
    static let maximumHistoryTurns = 8
    static let maximumHistoryTurnCharacters = 1_024

    static func prepare(model: String, userText: String, note: ObsidianNoteContent?, securityContext: SecurityPromptContext? = nil,
                        history: [OracleChatHistoryTurn] = [], tools: [[String: Any]] = []) throws -> PreparedOracleChatRequest {
        guard userText.utf8.count <= maximumMessageBytes else {
            throw NSError(
                domain: "OracleChat",
                code: 1,
                userInfo: [NSLocalizedDescriptionKey: "Message is too long. Please split it into shorter messages (8 KB maximum)."]
            )
        }

        let accepted = history.filter { ($0.role == "user" || $0.role == "assistant") && !$0.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
        var boundedHistory = accepted.suffix(maximumHistoryTurns).map { turn -> OracleChatHistoryTurn in
            let content = turn.text.count > maximumHistoryTurnCharacters
                ? "[Earlier part clipped] " + String(turn.text.suffix(maximumHistoryTurnCharacters))
                : turn.text
            return OracleChatHistoryTurn(role: turn.role, text: content)
        }
        var historyWasTruncated = boundedHistory.count != history.count ||
            accepted.suffix(maximumHistoryTurns).contains { $0.text.count > maximumHistoryTurnCharacters }
        var limit = min(note?.text.count ?? 0, initialNoteCharacters)
        while true {
            let bounded = note.map { boundedNote($0, maximumCharacters: limit) }
            let baseMessages = OracleObsidianPromptBuilder.messages(userText: userText, note: bounded?.note, securityContext: securityContext, model: model)
            let messages = [baseMessages[0]] + boundedHistory.map { ["role": $0.role, "content": $0.text] } +
                Array(baseMessages.dropFirst(2)) + [baseMessages[1]]
            var payload: [String: Any] = [
                "model": model,
                "stream": tools.isEmpty,
                "keep_alive": 0,
                "messages": messages,
                "options": ["num_predict": 256, "num_ctx": 8192]
            ]
            if !tools.isEmpty { payload["tools"] = tools }
            let body = try JSONSerialization.data(withJSONObject: payload)
            let requestLimit = tools.isEmpty ? maximumBodyBytes : maximumBodyBytes - 2_048
            if body.count <= requestLimit {
                return PreparedOracleChatRequest(
                    body: body,
                    outboundNote: bounded?.note,
                    noteWasTruncated: bounded?.wasTruncated ?? false,
                    historyWasTruncated: historyWasTruncated
                )
            }
            if limit > 0 {
                limit = max(0, limit - 250)
            } else if !boundedHistory.isEmpty {
                boundedHistory.removeFirst()
                historyWasTruncated = true
            } else {
                throw NSError(domain: "OracleChat", code: 2, userInfo: [NSLocalizedDescriptionKey: "Encoded message is too large; split it into shorter messages."])
            }
        }
    }

    static func boundedNote(_ note: ObsidianNoteContent, maximumCharacters: Int) -> (note: ObsidianNoteContent, wasTruncated: Bool) {
        if maximumCharacters <= 0, !note.text.isEmpty {
            return (ObsidianNoteContent(relativePath: note.relativePath,
                text: "[Oracle outbound note context omitted to fit the local request budget]", truncated: true), true)
        }
        guard note.text.count > maximumCharacters else {
            return (
                ObsidianNoteContent(relativePath: note.relativePath, text: note.text, truncated: note.truncated),
                note.truncated
            )
        }

        let marker = "\n\n[Oracle outbound context clipped to fit the local request budget]\n\n"
        let available = max(0, maximumCharacters - marker.count)
        let headCount = (available * 2) / 3
        let tailCount = available - headCount
        let clipped = String(note.text.prefix(headCount)) + marker + String(note.text.suffix(tailCount))
        return (
            ObsidianNoteContent(relativePath: note.relativePath, text: clipped, truncated: true),
            true
        )
    }
}
