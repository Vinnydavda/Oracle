import SwiftUI

struct ProtectionCenterView: View {
    @ObservedObject var store: OracleWorkspaceStore

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            OracleSectionHeading(
                eyebrow: "Layered local security",
                title: "Protection center",
                detail: "Read-only telemetry, deterministic rules, Apple signing assessment and approval-gated quarantine. This is not commercial antivirus equivalence."
            )

            HStack(spacing: 10) {
                Button("Run security audit") { store.runProtectionAudit() }
                    .buttonStyle(.borderedProminent).tint(OraclePalette.violet)
                    .disabled(store.protectionBusy)
                Button("Scan Downloads") { store.scanDownloads() }
                    .buttonStyle(.bordered)
                    .disabled(store.protectionBusy)
                Button("Scan Folder…") { store.chooseProtectionScanFolder() }
                    .buttonStyle(.bordered)
                    .disabled(store.protectionBusy)
                if store.protectionScanInProgress {
                    Button("Cancel scan") { store.cancelProtectionScan() }
                        .buttonStyle(.bordered)
                        .tint(OraclePalette.warning)
                } else if store.protectionBusy {
                    ProgressView().controlSize(.small)
                }
                Spacer()
            }

            if let error = store.lastProtectionError {
                Text(error).font(.footnote).foregroundStyle(OraclePalette.warning)
            }

            if let scan = store.lastScanReport {
                VStack(alignment: .leading, spacing: 7) {
                    HStack {
                        Text("Last scan").font(.headline).foregroundStyle(OraclePalette.lavender)
                        Spacer()
                        Text(scan.cancelled ? "CANCELLED" : "COMPLETED")
                            .font(.caption.weight(.bold)).foregroundStyle(scan.cancelled ? OraclePalette.warning : OraclePalette.good)
                    }
                    Text(scan.rootPath).font(.caption.monospaced()).foregroundStyle(OraclePalette.coolText.opacity(0.68)).textSelection(.enabled)
                    Text("\(scan.filesInspected) files • \(ByteCountFormatter.string(fromByteCount: Int64(scan.bytesInspected), countStyle: .file)) • \(scan.findings.count) findings • \(scan.completedAt.formatted(date: .abbreviated, time: .standard))")
                        .font(.caption).foregroundStyle(OraclePalette.coolText.opacity(0.72))
                    Text(scan.engine).font(.caption2).foregroundStyle(OraclePalette.coolText.opacity(0.55))
                    ForEach(scan.warnings, id: \.self) { warning in
                        Text("• \(warning)").font(.caption).foregroundStyle(OraclePalette.warning.opacity(0.9))
                    }
                }
                .padding(14)
                .background(OraclePalette.void.opacity(0.38), in: RoundedRectangle(cornerRadius: 13))
                .overlay(RoundedRectangle(cornerRadius: 13).stroke(OraclePalette.lavender.opacity(0.1)))
            }

            if let posture = store.protectionPosture {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 155), spacing: 10)], spacing: 10) {
                    postureCard("FileVault", posture.fileVault, posture.fileVault.lowercased().contains("on") ? OraclePalette.good : OraclePalette.warning)
                    postureCard("Gatekeeper", posture.gatekeeper, posture.gatekeeper.lowercased().contains("enabled") ? OraclePalette.good : OraclePalette.warning)
                    postureCard("SIP", posture.sip, posture.sip.lowercased().contains("enabled") ? OraclePalette.good : OraclePalette.warning)
                    postureCard("Firewall", posture.firewall, posture.firewall.lowercased().contains("enabled") ? OraclePalette.good : OraclePalette.warning)
                    postureCard("XProtect", posture.xprotectVersion, OraclePalette.electricPurple)
                    postureCard("Time Machine", posture.timeMachineDestinations == 0 ? "No destination" : "\(posture.timeMachineDestinations) destination", posture.timeMachineDestinations == 0 ? OraclePalette.warning : OraclePalette.good)
                }
            }

            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    Text("Scheduled scan").font(.headline).foregroundStyle(OraclePalette.lavender)
                    Spacer()
                    Toggle("", isOn: Binding(
                        get: { store.protectionPreferences.scheduledScanEnabled },
                        set: { store.setScheduledScanEnabled($0) }
                    )).labelsHidden()
                }
                HStack {
                    Text("Interval").font(.caption).foregroundStyle(OraclePalette.coolText.opacity(0.7))
                    Picker("", selection: Binding(
                        get: { store.protectionPreferences.scheduledIntervalHours },
                        set: { store.setScheduledScanInterval($0) }
                    )) {
                        Text("Every 6 hours").tag(6)
                        Text("Every 12 hours").tag(12)
                        Text("Every 24 hours").tag(24)
                    }
                    .labelsHidden()
                    .frame(width: 180)
                    Spacer()
                    Text(store.scheduledScanDetail)
                        .font(.caption2).foregroundStyle(OraclePalette.coolText.opacity(0.58))
                }
                Text("Runs only while Oracle is open. Downloads is the default scheduled target; this is not a privileged background daemon.")
                    .font(.caption).foregroundStyle(OraclePalette.coolText.opacity(0.58))
            }
            .padding(14)
            .background(OraclePalette.void.opacity(0.34), in: RoundedRectangle(cornerRadius: 13))

            VStack(alignment: .leading, spacing: 10) {
                Text("Capability matrix").font(.headline).foregroundStyle(OraclePalette.lavender)
                Text("Verified means exercised on this installed build. Implemented · unverified means code exists but the live acceptance case has not run. Blocked means a macOS entitlement, permission or external dependency is required.")
                    .font(.footnote).foregroundStyle(OraclePalette.coolText.opacity(0.62))
                ForEach(store.protectionCapabilities) { capability in
                    VStack(alignment: .leading, spacing: 5) {
                        HStack(alignment: .firstTextBaseline) {
                            Text(capability.name).font(.body.weight(.semibold)).foregroundStyle(OraclePalette.lavender)
                            Spacer()
                            ProtectionCapabilityBadge(status: capability.status)
                        }
                        Text("\(capability.layer) • \(capability.evidence)")
                            .font(.caption).foregroundStyle(OraclePalette.coolText.opacity(0.7))
                        Text("Limit: \(capability.limitations)")
                            .font(.caption2).foregroundStyle(OraclePalette.coolText.opacity(0.55))
                    }
                    .padding(12)
                    .background(OraclePalette.violet.opacity(0.12), in: RoundedRectangle(cornerRadius: 11))
                }
            }
        }
        .oraclePageSurface()
    }

    private func postureCard(_ title: String, _ value: String, _ color: Color) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(title.uppercased()).font(.caption2.weight(.bold)).tracking(1).foregroundStyle(color)
            Text(value).font(.caption).foregroundStyle(OraclePalette.coolText.opacity(0.78)).lineLimit(3)
        }
        .frame(maxWidth: .infinity, minHeight: 62, alignment: .topLeading)
        .padding(11)
        .background(OraclePalette.void.opacity(0.38), in: RoundedRectangle(cornerRadius: 11))
        .overlay(RoundedRectangle(cornerRadius: 11).stroke(color.opacity(0.25)))
    }
}

struct ProtectionCapabilityBadge: View {
    let status: ProtectionCapabilityStatus

    private var color: Color {
        switch status {
        case .verified: return OraclePalette.good
        case .implementedUnverified: return OraclePalette.warning
        case .missing: return OraclePalette.danger
        case .blocked: return OraclePalette.ember
        case .systemManaged: return OraclePalette.electricPurple
        }
    }

    var body: some View {
        Text(status.label.uppercased())
            .font(.caption2.weight(.bold)).tracking(0.7)
            .foregroundStyle(color)
            .padding(.horizontal, 8).padding(.vertical, 4)
            .background(color.opacity(0.14), in: Capsule())
            .overlay(Capsule().stroke(color.opacity(0.38)))
    }
}

struct ProtectionFindingsView: View {
    @ObservedObject var store: OracleWorkspaceStore
    @State private var pendingQuarantine: ProtectionFinding?

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            OracleSectionHeading(
                eyebrow: "Evidence-backed findings",
                title: "Findings",
                detail: "Deterministic findings retain source, resource, timestamp, confidence and review state. Heuristics can be wrong."
            )
            if store.protectionFindings.isEmpty {
                ContentUnavailableView("No open findings", systemImage: "checkmark.shield", description: Text("No current finding is asserted. Absence of a finding is not proof of protection."))
                    .frame(maxWidth: .infinity, minHeight: 240)
            } else {
                ForEach(store.protectionFindings) { finding in
                    VStack(alignment: .leading, spacing: 8) {
                        HStack(alignment: .firstTextBaseline) {
                            Text(finding.title).font(.headline).foregroundStyle(OraclePalette.lavender)
                            Spacer()
                            Text(finding.severity.rawValue.uppercased())
                                .font(.caption2.weight(.bold)).foregroundStyle(severityColor(finding.severity))
                        }
                        Text(finding.rationale).font(.footnote).foregroundStyle(OraclePalette.coolText.opacity(0.72))
                        Text(finding.resource).font(.caption.monospaced()).foregroundStyle(OraclePalette.coolText.opacity(0.62)).textSelection(.enabled)
                        Text("\(finding.source) • \(finding.confidence) confidence • observed \(finding.lastObservedAt.formatted(date: .abbreviated, time: .standard)) • \(finding.occurrences) occurrence(s)")
                            .font(.caption2).foregroundStyle(OraclePalette.coolText.opacity(0.55))
                        ForEach(finding.evidence, id: \.self) { line in
                            Text("• \(line)").font(.caption).foregroundStyle(OraclePalette.coolText.opacity(0.67))
                        }
                        HStack(spacing: 9) {
                            Button("Ask Oracle") { store.attachFindingToOracle(finding) }
                                .buttonStyle(.bordered)
                            Button("Mark false positive") { store.markFindingFalsePositive(finding) }
                                .buttonStyle(.borderless)
                            if finding.canQuarantine {
                                Button("Quarantine…") { pendingQuarantine = finding }
                                    .buttonStyle(.bordered).tint(OraclePalette.warning)
                            }
                            Spacer()
                            Text(finding.reviewStatus.label).font(.caption2.weight(.semibold)).foregroundStyle(OraclePalette.coolText.opacity(0.58))
                        }
                    }
                    .padding(14)
                    .background(OraclePalette.void.opacity(0.4), in: RoundedRectangle(cornerRadius: 13))
                    .overlay(RoundedRectangle(cornerRadius: 13).stroke(severityColor(finding.severity).opacity(0.28)))
                }
            }
        }
        .oraclePageSurface()
        .confirmationDialog(
            "Quarantine this file?",
            isPresented: Binding(get: { pendingQuarantine != nil }, set: { if !$0 { pendingQuarantine = nil } }),
            titleVisibility: .visible
        ) {
            if let finding = pendingQuarantine {
                Button("Move to reversible quarantine", role: .destructive) {
                    store.quarantine(finding)
                    pendingQuarantine = nil
                }
            }
            Button("Cancel", role: .cancel) { pendingQuarantine = nil }
        } message: {
            if let finding = pendingQuarantine {
                Text("Oracle will move \(finding.resource) into its local quarantine and preserve SHA-256 metadata. It will not delete the file. You can restore it later.")
            }
        }
    }

    private func severityColor(_ severity: ProtectionSeverity) -> Color {
        switch severity {
        case .info: return OraclePalette.coolText
        case .low: return OraclePalette.electricPurple
        case .medium: return OraclePalette.warning
        case .high, .critical: return OraclePalette.danger
        }
    }
}

struct QuarantineView: View {
    @ObservedObject var store: OracleWorkspaceStore
    @State private var pendingRestore: QuarantineRecord?

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            OracleSectionHeading(
                eyebrow: "Reversible response",
                title: "Quarantine",
                detail: "Files move only after explicit owner confirmation. Metadata and SHA-256 are preserved; automatic deletion is not implemented."
            )
            if store.quarantineRecords.isEmpty {
                ContentUnavailableView("No quarantined files", systemImage: "archivebox", description: Text("No quarantined item is recorded.")).frame(maxWidth: .infinity, minHeight: 230)
            } else {
                ForEach(store.quarantineRecords) { record in
                    VStack(alignment: .leading, spacing: 6) {
                        HStack {
                            Text(URL(fileURLWithPath: record.originalPath).lastPathComponent).font(.headline).foregroundStyle(OraclePalette.lavender)
                            Spacer()
                            Text(record.restoredAt == nil ? "QUARANTINED" : "RESTORED")
                                .font(.caption2.weight(.bold)).foregroundStyle(record.restoredAt == nil ? OraclePalette.warning : OraclePalette.good)
                        }
                        Text(record.originalPath).font(.caption.monospaced()).foregroundStyle(OraclePalette.coolText.opacity(0.65)).textSelection(.enabled)
                        Text(record.findingTitle).font(.caption).foregroundStyle(OraclePalette.coolText.opacity(0.72))
                        Text("SHA-256 \(record.sha256)").font(.caption2.monospaced()).foregroundStyle(OraclePalette.coolText.opacity(0.52)).textSelection(.enabled)
                        if record.restoredAt == nil {
                            Button("Restore…") { pendingRestore = record }.buttonStyle(.bordered)
                        }
                    }
                    .padding(13)
                    .background(OraclePalette.void.opacity(0.38), in: RoundedRectangle(cornerRadius: 12))
                }
            }
        }
        .oraclePageSurface()
        .confirmationDialog(
            "Restore quarantined file?",
            isPresented: Binding(get: { pendingRestore != nil }, set: { if !$0 { pendingRestore = nil } }),
            titleVisibility: .visible
        ) {
            if let record = pendingRestore {
                Button("Restore verified file") {
                    store.restore(record)
                    pendingRestore = nil
                }
            }
            Button("Cancel", role: .cancel) { pendingRestore = nil }
        } message: {
            if let record = pendingRestore {
                Text("Oracle will verify the preserved SHA-256 and move the file back to \(record.originalPath). Restore stops if the destination already exists.")
            }
        }
    }
}
