import AppKit
import SceneKit
import SwiftUI

/// Review surface for the original approved-reference Meshy body. This is an
/// actual skinned 3D geometry. The USDZ import retains the 24 body bones, but
/// this review surface has no accepted motion clips or facial/finger controls.
/// Keep the canonical reference view available until the owner accepts a rig.
struct Oracle3DCandidateView: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var playMotionStudy = false

    var body: some View {
        ZStack(alignment: .topLeading) {
            Oracle3DSceneView(playMotionStudy: playMotionStudy, reduceMotion: reduceMotion)
            VStack(alignment: .leading, spacing: 5) {
                Text("ORACLE • 3D MESH CANDIDATE")
                    .font(.caption2.weight(.bold))
                    .tracking(1.2)
                    .foregroundStyle(OraclePalette.magenta)
                Text("Drag to orbit • 24-bone body rig")
                    .font(.caption2)
                    .foregroundStyle(OraclePalette.coolText)
                Spacer()
                Text("Experimental IK gait • identity and motion not accepted")
                    .font(.caption2)
                    .foregroundStyle(OraclePalette.gold)
                Button(playMotionStudy ? "Reset gait study" : "Play gait study") {
                    playMotionStudy.toggle()
                }
                .buttonStyle(.bordered)
                .disabled(reduceMotion)
                .help(reduceMotion ? "Unavailable while Reduce Motion is enabled" : "Experimental six-second study; not an accepted walk")
            }
            .padding(13)
        }
        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .strokeBorder(OraclePalette.gold.opacity(0.32), lineWidth: 1)
        }
        .accessibilityElement(children: .contain)
        .accessibilityLabel("Oracle 3D body mesh candidate and experimental gait study")
        .accessibilityValue("A rotatable purple and gold skinned body candidate with twenty-four bones. Its face, hair and materials do not yet match the approved reference. The opt-in IK gait study is not accepted runway walking. Finger gestures, facial expression, hair motion and voice synchronization are unavailable.")
    }
}

private struct Oracle3DSceneView: NSViewRepresentable {
    let playMotionStudy: Bool
    let reduceMotion: Bool

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeNSView(context: Context) -> SCNView {
        let view = SCNView(frame: .zero)
        view.backgroundColor = NSColor(red: 0.035, green: 0.018, blue: 0.075, alpha: 1)
        view.allowsCameraControl = true
        view.autoenablesDefaultLighting = false
        view.rendersContinuously = false
        view.preferredFramesPerSecond = 30
        view.antialiasingMode = .multisampling4X
        if let (scene, motionRoot) = Oracle3DCandidateScene.makeScene() {
            view.scene = scene
            context.coordinator.controller = Oracle3DMotionController(motionRoot: motionRoot)
        }
        view.pointOfView = view.scene?.rootNode.childNode(withName: "Oracle review camera", recursively: false)
        context.coordinator.view = view
        return view
    }

    func updateNSView(_ view: SCNView, context: Context) {
        context.coordinator.setPlaying(playMotionStudy && !reduceMotion)
    }

    static func dismantleNSView(_ view: SCNView, coordinator: Coordinator) {
        coordinator.stopAndReset()
        view.scene = nil
        view.pointOfView = nil
    }

    final class Coordinator {
        weak var view: SCNView?
        var controller: Oracle3DMotionController?
        private var timer: Timer?
        private var requested = false
        private var startTime: TimeInterval = 0

        func setPlaying(_ shouldPlay: Bool) {
            guard shouldPlay != requested else { return }
            requested = shouldPlay
            if shouldPlay {
                startTime = ProcessInfo.processInfo.systemUptime
                view?.rendersContinuously = true
                timer = Timer.scheduledTimer(withTimeInterval: 1.0 / 30, repeats: true) { [weak self] _ in
                    self?.tick()
                }
            } else {
                stopAndReset()
            }
        }

        private func tick() {
            let elapsed = ProcessInfo.processInfo.systemUptime - startTime
            _ = controller?.apply(at: elapsed)
            if elapsed >= 6 {
                timer?.invalidate()
                timer = nil
                view?.rendersContinuously = false
            }
        }

        func stopAndReset() {
            timer?.invalidate()
            timer = nil
            requested = false
            _ = controller?.apply(at: 0, reduceMotion: true)
            view?.rendersContinuously = false
        }
    }
}

private enum Oracle3DCandidateScene {
    static func makeScene() -> (SCNScene, SCNNode)? {
        guard let url = Bundle.main.url(forResource: "Oracle3DSkinnedBodyCandidate", withExtension: "usdz"),
              let scene = try? SCNScene(url: url, options: nil) else { return nil }

        // The source is Z-up. Turn the model alone so SceneKit's camera and
        // lighting remain Y-up, with its feet on the scene floor.
        let model = SCNNode()
        model.name = "Oracle approved-reference body candidate"
        for child in scene.rootNode.childNodes {
            child.removeFromParentNode()
            model.addChildNode(child)
        }
        model.eulerAngles.x = -.pi / 2
        let motionRoot = SCNNode()
        motionRoot.name = "Oracle motion root"
        motionRoot.addChildNode(model)
        scene.rootNode.addChildNode(motionRoot)

        scene.background.contents = NSColor(red: 0.045, green: 0.022, blue: 0.09, alpha: 1)

        let camera = SCNCamera()
        camera.fieldOfView = 38
        camera.zNear = 0.01
        camera.zFar = 50
        let cameraNode = SCNNode()
        cameraNode.name = "Oracle review camera"
        cameraNode.camera = camera
        cameraNode.position = SCNVector3(0, 0.86, 3.3)
        cameraNode.look(at: SCNVector3(0, 0.86, 0))
        scene.rootNode.addChildNode(cameraNode)

        let ambient = SCNLight()
        ambient.type = .ambient
        ambient.color = NSColor(red: 0.32, green: 0.25, blue: 0.55, alpha: 1)
        ambient.intensity = 94
        let ambientNode = SCNNode()
        ambientNode.light = ambient
        scene.rootNode.addChildNode(ambientNode)

        let key = SCNLight()
        key.type = .omni
        key.color = NSColor(red: 0.9, green: 0.76, blue: 1, alpha: 1)
        key.intensity = 166
        let keyNode = SCNNode()
        keyNode.light = key
        keyNode.position = SCNVector3(1.8, 2.7, 2.1)
        scene.rootNode.addChildNode(keyNode)

        let rim = SCNLight()
        rim.type = .omni
        rim.color = NSColor(red: 1, green: 0.48, blue: 0.2, alpha: 1)
        rim.intensity = 78
        let rimNode = SCNNode()
        rimNode.light = rim
        rimNode.position = SCNVector3(-1.7, 1.8, -1.0)
        scene.rootNode.addChildNode(rimNode)
        return (scene, motionRoot)
    }
}
