@preconcurrency import AVFoundation
import Foundation
import Security
@preconcurrency import Speech

enum OracleVoiceState: String {
    case idle
    case preparing
    case speaking
    case finished
    case cancelled
    case failed
    case notConfigured
    case disclosureRequired
    case spendApprovalRequired

    var label: String {
        switch self {
        case .idle: return "Idle"
        case .preparing: return "Preparing"
        case .speaking: return "Speaking"
        case .finished: return "Audition complete"
        case .cancelled: return "Cancelled"
        case .failed: return "Failed"
        case .notConfigured: return "Not configured"
        case .disclosureRequired: return "Disclosure required"
        case .spendApprovalRequired: return "Approval required"
        }
    }
}

struct FishVoiceDesignCandidate: Codable, Hashable {
    let id: String
    let index: Int
    let audio_base64: String
    let sample_rate: Int
    let duration_ms: Int
}

private struct FishVoiceDesignResponse: Codable {
    let candidates: [FishVoiceDesignCandidate]
}

enum FishAudioRequestBuilder {
    static let voiceDesignURL = URL(string: "https://api.fish.audio/v1/voice-design")!
    static let ttsURL = URL(string: "https://api.fish.audio/v1/tts")!
    static let voiceDesignModel = "voice-design-1"
    static let ttsModel = "s2.1-pro-free"
    static let maximumSpeechBytes = 4_096
    static let maximumVoiceInstructionCharacters = 2_000
    static let maximumPreviewCharacters = 150
    static let estimatedVoiceDesignUSD = 0.01

    static func voiceDesignBody(instruction: String, referenceText: String) throws -> Data {
        let boundedInstruction = String(instruction.trimmingCharacters(in: .whitespacesAndNewlines).prefix(maximumVoiceInstructionCharacters))
        guard !boundedInstruction.isEmpty else {
            throw NSError(domain: "OracleFishVoice", code: 1, userInfo: [NSLocalizedDescriptionKey: "Describe the original voice before requesting a design audition."])
        }
        let boundedPreview = String(referenceText.trimmingCharacters(in: .whitespacesAndNewlines).prefix(maximumPreviewCharacters))
        let payload: [String: Any] = [
            "instruction": boundedInstruction,
            "reference_text": boundedPreview,
            "language": "en",
            "n": 1,
            "speed": 1.0,
            "num_step": 32,
            "guidance_scale": 2.0,
            "instruct_guidance_scale": 0.0
        ]
        return try JSONSerialization.data(withJSONObject: payload, options: [.sortedKeys])
    }

    static func ttsBody(text: String, originalVoiceID: String) throws -> Data {
        let boundedText = String(text.trimmingCharacters(in: .whitespacesAndNewlines).prefix(maximumSpeechBytes))
        guard !boundedText.isEmpty else {
            throw NSError(domain: "OracleFishVoice", code: 2, userInfo: [NSLocalizedDescriptionKey: "There is no text to audition."])
        }
        guard !originalVoiceID.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw NSError(domain: "OracleFishVoice", code: 3, userInfo: [NSLocalizedDescriptionKey: "Set an original Fish Audio voice model ID first."])
        }
        let payload: [String: Any] = [
            "text": boundedText,
            "reference_id": originalVoiceID,
            "format": "mp3",
            "mp3_bitrate": 128,
            "sample_rate": 44_100,
            "normalize": true,
            "chunk_length": 200,
            "latency": "balanced",
            "prosody": ["speed": 1.0, "volume": 0, "normalize_loudness": true]
        ]
        return try JSONSerialization.data(withJSONObject: payload, options: [.sortedKeys])
    }

    static func decodeVoiceCandidates(_ data: Data) throws -> [FishVoiceDesignCandidate] {
        let response = try JSONDecoder().decode(FishVoiceDesignResponse.self, from: data)
        guard !response.candidates.isEmpty else {
            throw NSError(domain: "OracleFishVoice", code: 4, userInfo: [NSLocalizedDescriptionKey: "Fish Audio returned no voice candidates."])
        }
        return response.candidates
    }
}

enum FishCredentialStore {
    private static let service = "app.oracle.agamemnon.security.fish-audio"
    private static let account = "api-key"

    static func hasKey() -> Bool {
        (try? loadKey()) != nil
    }

    static func saveKey(_ value: String) throws {
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            throw NSError(domain: "OracleFishCredential", code: 1, userInfo: [NSLocalizedDescriptionKey: "The Fish Audio API key is empty."])
        }
        let data = Data(trimmed.utf8)
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        let attributes: [String: Any] = [
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        ]
        let status = SecItemUpdate(query as CFDictionary, attributes as CFDictionary)
        if status == errSecItemNotFound {
            var add = query
            add.merge(attributes) { _, new in new }
            let addStatus = SecItemAdd(add as CFDictionary, nil)
            guard addStatus == errSecSuccess else {
                throw NSError(domain: "OracleFishCredential", code: Int(addStatus), userInfo: [NSLocalizedDescriptionKey: "Fish Audio key could not be saved in Keychain."])
            }
        } else if status != errSecSuccess {
            throw NSError(domain: "OracleFishCredential", code: Int(status), userInfo: [NSLocalizedDescriptionKey: "Fish Audio key could not be updated in Keychain."])
        }
    }

    static func deleteKey() throws {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        let status = SecItemDelete(query as CFDictionary)
        guard status == errSecSuccess || status == errSecItemNotFound else {
            throw NSError(domain: "OracleFishCredential", code: Int(status), userInfo: [NSLocalizedDescriptionKey: "Fish Audio key could not be removed from Keychain."])
        }
    }

    static func loadKey() throws -> String {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var item: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &item)
        guard status == errSecSuccess,
              let data = item as? Data,
              let value = String(data: data, encoding: .utf8),
              !value.isEmpty else {
            throw NSError(domain: "OracleFishCredential", code: Int(status), userInfo: [NSLocalizedDescriptionKey: "Fish Audio key is not configured."])
        }
        return value
    }
}

/// A word-timed visual cue for macOS speech. AVSpeechSynthesizer exposes text
/// ranges, not phoneme timestamps or output amplitude; this is not lip sync.
enum OracleSpeechMotion {
    static func openness(text: String, range: NSRange) -> Double {
        let source = text as NSString
        guard range.location >= 0, range.length > 0,
              range.location <= source.length,
              range.length <= source.length - range.location else { return 0 }
        let word = source.substring(with: range)
        let letters = word.unicodeScalars.filter { CharacterSet.letters.contains($0) }.count
        guard letters > 0 else { return 0.06 }
        let vowels = word.lowercased().unicodeScalars.filter { "aeiouy".unicodeScalars.contains($0) }.count
        return min(0.84, 0.22 + Double(min(vowels, 4)) * 0.11 + Double(min(letters, 10)) * 0.018)
    }

    static func durationMilliseconds(range: NSRange) -> Int {
        min(420, max(140, range.length * 42))
    }
}

@MainActor
final class OracleVoiceController: NSObject, ObservableObject, AVSpeechSynthesizerDelegate, AVAudioPlayerDelegate {
    @Published private(set) var state: OracleVoiceState = .idle
    @Published private(set) var sourceLabel = "No audition has run"
    @Published private(set) var mouthOpenness: Double = 0
    /// Output level from AVAudioPlayer metering only. Nil for macOS system
    /// speech, whose word callbacks do not expose actual output amplitude.
    @Published private(set) var measuredAmplitude: Double?
    @Published private(set) var speechProgress: Double = 0
    @Published private(set) var lastError: String?
    @Published private(set) var fishKeyConfigured = false
    @Published private(set) var fishVoiceID: String = UserDefaults.standard.string(forKey: "app.oracle.agamemnon.security.fishVoiceID") ?? ""
    @Published private(set) var lastVoiceDesignPath: String?
    @Published var fishDisclosureAccepted = false
    @Published private(set) var isMuted = false

    private let synthesizer = AVSpeechSynthesizer()
    private var player: AVAudioPlayer?
    private var speechAnimationTask: Task<Void, Never>?
    private var meterTask: Task<Void, Never>?
    private var fishRequestTask: Task<Void, Never>?
    private var activeRequestID: UUID?
    private var activeSpeechUtterance: AVSpeechUtterance?
    private var currentSpeech: String = ""
    private(set) var localSpeechSessionID: UUID?
    var currentLocalSpeechText: String? { localSpeechSessionID == nil ? nil : currentSpeech }

    override init() {
        super.init()
        synthesizer.delegate = self
        refreshConfiguration()
    }

    var isSpeaking: Bool { state == .speaking }

    /// Muting cancels current playback and pending external speech. It does not
    /// start or stop microphone capture, which has its own explicit control.
    func setMuted(_ muted: Bool) {
        guard isMuted != muted else { return }
        isMuted = muted
        if muted { stop() }
    }
    var fishReady: Bool { fishKeyConfigured && !fishVoiceID.trimmingCharacters(in: .whitespaces).isEmpty }

    func refreshConfiguration() {
        fishKeyConfigured = FishCredentialStore.hasKey()
    }

    func saveFishKey(_ value: String) throws {
        try FishCredentialStore.saveKey(value)
        fishKeyConfigured = true
    }

    func removeFishKey() throws {
        try FishCredentialStore.deleteKey()
        fishKeyConfigured = false
    }

    func saveFishVoiceID(_ value: String) {
        let bounded = String(value.trimmingCharacters(in: .whitespacesAndNewlines).prefix(128))
        fishVoiceID = bounded
        UserDefaults.standard.set(bounded, forKey: "app.oracle.agamemnon.security.fishVoiceID")
    }

    func speakLocal(_ text: String) {
        guard !isMuted else { return }
        let bounded = String(text.trimmingCharacters(in: .whitespacesAndNewlines).prefix(600))
        guard !bounded.isEmpty else { return }
        stop()
        currentSpeech = bounded
        localSpeechSessionID = UUID()
        sourceLabel = "macOS local speech audition — not Fish Audio"
        lastError = nil
        speechProgress = 0
        mouthOpenness = 0
        state = .preparing
        let utterance = AVSpeechUtterance(string: bounded)
        utterance.voice = AVSpeechSynthesisVoice(language: "en-US")
        utterance.rate = 0.46
        utterance.pitchMultiplier = 0.95
        utterance.volume = 1
        activeSpeechUtterance = utterance
        synthesizer.speak(utterance)
    }

    /// Plays the one owner-approved ElevenLabs library-voice audition. This is
    /// a bundled sample, not a dynamic reply voice or an original voice model.
    func playElevenLabsAudition() {
        guard !isMuted else { return }
        stop()
        sourceLabel = "ElevenLabs Ali sample • prerecorded audition"
        currentSpeech = "Hello. I am Oracle. My voice is here to guide, not to guess. Tell me what matters, and we will move with purpose, one step at a time."
        lastError = nil
        speechProgress = 0
        mouthOpenness = 0
        state = .preparing
        do {
            guard let url = Bundle.main.url(forResource: "OracleElevenLabsAliAudition", withExtension: "mp3") else {
                throw NSError(domain: "OracleElevenLabsAudition", code: 1, userInfo: [NSLocalizedDescriptionKey: "The bundled ElevenLabs audition is missing."])
            }
            try playAudio(Data(contentsOf: url))
        } catch {
            finishWithError(error.localizedDescription)
        }
    }

    func speakFish(_ text: String) {
        guard !isMuted else { return }
        guard fishDisclosureAccepted else {
            state = .disclosureRequired
            lastError = "Review and accept the external Fish Audio disclosure before sending any text."
            return
        }
        guard fishKeyConfigured else {
            state = .notConfigured
            lastError = "Fish Audio is not configured. No external request was made."
            return
        }
        guard !fishVoiceID.isEmpty else {
            state = .notConfigured
            lastError = "Set an original Fish Audio voice model ID. Oracle does not clone a real performer."
            return
        }
        stop()
        currentSpeech = text
        sourceLabel = "Fish Audio S2.1 Pro Free (external)"
        lastError = nil
        speechProgress = 0
        mouthOpenness = 0
        state = .preparing
        let requestID = UUID()
        activeRequestID = requestID
        fishRequestTask = Task { [weak self] in
            guard let self else { return }
            defer { if self.activeRequestID == requestID { self.fishRequestTask = nil } }
            do {
                let key = try FishCredentialStore.loadKey()
                let body = try FishAudioRequestBuilder.ttsBody(text: text, originalVoiceID: self.fishVoiceID)
                var request = URLRequest(url: FishAudioRequestBuilder.ttsURL)
                request.httpMethod = "POST"
                request.timeoutInterval = 120
                request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                request.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
                request.setValue(FishAudioRequestBuilder.ttsModel, forHTTPHeaderField: "model")
                request.httpBody = body
                let (data, response) = try await URLSession.shared.data(for: request)
                try Task.checkCancellation()
                guard self.activeRequestID == requestID else { return }
                try self.validateFishResponse(data: data, response: response)
                guard data.count <= 20_000_000 else {
                    throw NSError(domain: "OracleFishVoice", code: 5, userInfo: [NSLocalizedDescriptionKey: "Fish Audio returned audio larger than the local playback limit."])
                }
                try self.playAudio(data)
            } catch {
                if !Task.isCancelled && self.activeRequestID == requestID {
                    self.finishWithError(error.localizedDescription)
                }
            }
        }
    }

    func designOriginalVoice(instruction: String, previewText: String, spendApproved: Bool) {
        guard !isMuted else { return }
        guard spendApproved else {
            state = .spendApprovalRequired
            lastError = "Voice Design makes a paid Fish Audio request. Fresh approval is required."
            return
        }
        guard fishDisclosureAccepted else {
            state = .disclosureRequired
            lastError = "Review and accept the external Fish Audio disclosure first."
            return
        }
        guard fishKeyConfigured else {
            state = .notConfigured
            lastError = "Fish Audio is not configured. No external request was made."
            return
        }
        stop()
        sourceLabel = "Fish Audio Voice Design (external, $0.01 per successful request)"
        lastError = nil
        state = .preparing
        let requestID = UUID()
        activeRequestID = requestID
        fishRequestTask = Task { [weak self] in
            guard let self else { return }
            defer { if self.activeRequestID == requestID { self.fishRequestTask = nil } }
            do {
                let key = try FishCredentialStore.loadKey()
                let body = try FishAudioRequestBuilder.voiceDesignBody(instruction: instruction, referenceText: previewText)
                var request = URLRequest(url: FishAudioRequestBuilder.voiceDesignURL)
                request.httpMethod = "POST"
                request.timeoutInterval = 120
                request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                request.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
                request.setValue(FishAudioRequestBuilder.voiceDesignModel, forHTTPHeaderField: "model")
                request.httpBody = body
                let (data, response) = try await URLSession.shared.data(for: request)
                try Task.checkCancellation()
                guard self.activeRequestID == requestID else { return }
                try self.validateFishResponse(data: data, response: response)
                let candidates = try FishAudioRequestBuilder.decodeVoiceCandidates(data)
                guard let first = candidates.first,
                      let audio = Data(base64Encoded: first.audio_base64),
                      audio.count <= 20_000_000 else {
                    throw NSError(domain: "OracleFishVoice", code: 6, userInfo: [NSLocalizedDescriptionKey: "Fish Audio returned no playable candidate audio."])
                }
                let directory = URL(fileURLWithPath: NSHomeDirectory()).appendingPathComponent("Documents/ORACLE/Agamemnon/Voice Auditions", isDirectory: true)
                try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
                let stamp = ISO8601DateFormatter().string(from: Date()).replacingOccurrences(of: ":", with: "-")
                let output = directory.appendingPathComponent("Oracle Original Voice Design \(stamp).wav")
                try audio.write(to: output, options: .atomic)
                try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: output.path)
                self.lastVoiceDesignPath = output.path
                try self.playAudio(audio)
            } catch {
                if !Task.isCancelled && self.activeRequestID == requestID {
                    self.finishWithError(error.localizedDescription)
                }
            }
        }
    }

    func stop() {
        localSpeechSessionID = nil
        activeRequestID = nil
        fishRequestTask?.cancel()
        fishRequestTask = nil
        activeSpeechUtterance = nil
        if synthesizer.isSpeaking || synthesizer.isPaused {
            synthesizer.stopSpeaking(at: .immediate)
        }
        player?.stop()
        player = nil
        stopTimers()
        mouthOpenness = 0
        measuredAmplitude = nil
        if state == .speaking || state == .preparing {
            state = .cancelled
        }
    }

    private func playAudio(_ data: Data) throws {
        let player = try AVAudioPlayer(data: data)
        player.delegate = self
        player.isMeteringEnabled = true
        player.prepareToPlay()
        self.player = player
        guard player.play() else {
            throw NSError(domain: "OracleFishVoice", code: 7, userInfo: [NSLocalizedDescriptionKey: "The Fish Audio audition could not be played."])
        }
        state = .speaking
        speechProgress = 0
        measuredAmplitude = nil
        meterTask?.cancel()
        meterTask = Task { @MainActor [weak self] in
            while !Task.isCancelled {
                guard let self, let player = self.player, player.isPlaying else { return }
                player.updateMeters()
                let power = Double(player.averagePower(forChannel: 0))
                let normalized = power.isFinite ? max(0, min(1, (power + 50) / 50)) : 0
                self.measuredAmplitude = normalized
                self.mouthOpenness = 0.08 + normalized * 0.92
                if player.duration > 0 {
                    self.speechProgress = min(1, player.currentTime / player.duration)
                }
                try? await Task.sleep(for: .milliseconds(33))
            }
        }
    }

    private func validateFishResponse(data: Data, response: URLResponse) throws {
        guard let http = response as? HTTPURLResponse else {
            throw NSError(domain: "OracleFishVoice", code: 8, userInfo: [NSLocalizedDescriptionKey: "Fish Audio returned an unreadable response."])
        }
        guard http.statusCode == 200 else {
            var detail = ""
            if let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
               let message = object["message"] as? String {
                detail = " \(String(message.prefix(240)))"
            }
            throw NSError(domain: "OracleFishVoice", code: http.statusCode, userInfo: [NSLocalizedDescriptionKey: "Fish Audio request failed (HTTP \(http.statusCode)).\(detail)"])
        }
    }

    private func finishWithError(_ message: String) {
        stopTimers()
        mouthOpenness = 0
        measuredAmplitude = nil
        state = .failed
        lastError = message
    }

    private func stopTimers() {
        speechAnimationTask?.cancel()
        speechAnimationTask = nil
        meterTask?.cancel()
        meterTask = nil
    }

    nonisolated func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didStart utterance: AVSpeechUtterance) {
        Task { @MainActor [weak self] in self?.handleSpeechStarted(utterance) }
    }

    private func handleSpeechStarted(_ utterance: AVSpeechUtterance) {
        guard activeSpeechUtterance === utterance else { return }
        state = .speaking
        mouthOpenness = 0.06
        measuredAmplitude = nil
    }

    nonisolated func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, willSpeakRangeOfSpeechString characterRange: NSRange, utterance: AVSpeechUtterance) {
        Task { @MainActor [weak self] in self?.handleSpeechRange(characterRange, utterance: utterance) }
    }

    private func handleSpeechRange(_ characterRange: NSRange, utterance: AVSpeechUtterance) {
        guard activeSpeechUtterance === utterance else { return }
        let total = max(1, currentSpeech.utf16.count)
        speechProgress = min(1, Double(characterRange.location + characterRange.length) / Double(total))
        mouthOpenness = OracleSpeechMotion.openness(text: currentSpeech, range: characterRange)
        speechAnimationTask?.cancel()
        let delay = OracleSpeechMotion.durationMilliseconds(range: characterRange)
        speechAnimationTask = Task { @MainActor [weak self] in
            try? await Task.sleep(for: .milliseconds(delay))
            guard !Task.isCancelled, let self, self.state == .speaking else { return }
            self.mouthOpenness = 0.06
        }
    }

    nonisolated func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        Task { @MainActor [weak self] in self?.handleSpeechFinished(utterance) }
    }

    private func handleSpeechFinished(_ utterance: AVSpeechUtterance) {
        guard activeSpeechUtterance === utterance else { return }
        activeSpeechUtterance = nil
        stopTimers()
        mouthOpenness = 0
        measuredAmplitude = nil
        speechProgress = 1
        state = .finished
    }

    nonisolated func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didCancel utterance: AVSpeechUtterance) {
        Task { @MainActor [weak self] in self?.handleSpeechCancelled(utterance) }
    }

    private func handleSpeechCancelled(_ utterance: AVSpeechUtterance) {
        guard activeSpeechUtterance === utterance else { return }
        activeSpeechUtterance = nil
        stopTimers()
        mouthOpenness = 0
        measuredAmplitude = nil
        state = .cancelled
    }

    nonisolated func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        Task { @MainActor [weak self] in self?.handleAudioFinished(successfully: flag) }
    }

    private func handleAudioFinished(successfully flag: Bool) {
        stopTimers()
        mouthOpenness = 0
        measuredAmplitude = nil
        speechProgress = flag ? 1 : speechProgress
        state = flag ? .finished : .failed
        if !flag { lastError = "\(sourceLabel) playback did not complete." }
    }
}

struct OraclePermissionObservation: Hashable {
    let name: String
    let detail: String
    let status: String
    let confidence: String
}

@MainActor
final class OracleDictationController: NSObject, ObservableObject, SFSpeechRecognizerDelegate {
    @Published private(set) var isListening = false
    @Published private(set) var isStarting = false
    @Published private(set) var transcript = ""
    @Published private(set) var statusDetail = "Microphone off; on-device dictation has not been requested."
    @Published private(set) var lastError: String?

    private let recognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
    private let audioEngine = AVAudioEngine()
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private var authorizationID: UUID?
    private var authorizationTimeoutTask: Task<Void, Never>?

    func start(onTranscript: @escaping (String) -> Void) {
        guard !isListening, !isStarting else { return }
        lastError = nil
        guard let recognizer else {
            lastError = "Speech recognition is unavailable for the configured locale."
            statusDetail = "Dictation unavailable."
            return
        }
        let id = UUID()
        authorizationID = id
        isStarting = true
        statusDetail = "Checking on-device dictation capability."
        authorizationTimeoutTask = Task { [weak self] in
            try? await Task.sleep(for: .seconds(20))
            guard !Task.isCancelled, let self, self.authorizationID == id else { return }
            self.authorizationID = nil
            self.isStarting = false
            self.authorizationTimeoutTask = nil
            self.lastError = "On-device speech or microphone authorization did not respond within 20 seconds. No audio was captured."
            self.statusDetail = "Microphone off; permission check timed out. Try Listen again."
        }
        switch SFSpeechRecognizer.authorizationStatus() {
        case .authorized:
            requestMicrophoneAccess(recognizer: recognizer, id: id, onTranscript: onTranscript)
        case .notDetermined:
            statusDetail = "Waiting for macOS speech recognition permission. Microphone off."
            SFSpeechRecognizer.requestAuthorization { [weak self] speechStatus in
                DispatchQueue.main.async {
                    guard let self, self.authorizationID == id else { return }
                    guard speechStatus == .authorized else {
                        self.failAuthorization(id: id,
                            error: "Speech recognition permission is \(Self.speechLabel(speechStatus)). No audio was captured.",
                            status: "Microphone off; speech permission not granted.")
                        return
                    }
                    self.requestMicrophoneAccess(recognizer: recognizer, id: id, onTranscript: onTranscript)
                }
            }
        default:
            failAuthorization(id: id,
                error: "Speech recognition permission is \(Self.speechLabel(SFSpeechRecognizer.authorizationStatus())). No audio was captured.",
                status: "Microphone off; speech permission not granted.")
        }
    }

    private func requestMicrophoneAccess(recognizer: SFSpeechRecognizer, id: UUID,
                                         onTranscript: @escaping (String) -> Void) {
        guard authorizationID == id else { return }
        switch AVCaptureDevice.authorizationStatus(for: .audio) {
        case .authorized:
            statusDetail = "Starting on-device recognition."
            startAuthorizedRecognition(recognizer: recognizer, id: id, onTranscript: onTranscript)
        case .notDetermined:
            statusDetail = "Waiting for macOS microphone permission. No audio captured yet."
            AVCaptureDevice.requestAccess(for: .audio) { [weak self] granted in
                DispatchQueue.main.async {
                    guard let self, self.authorizationID == id else { return }
                    guard granted else {
                        self.failAuthorization(id: id, error: "Microphone permission was denied. No audio was captured.",
                            status: "Microphone off; permission not granted.")
                        return
                    }
                    self.startAuthorizedRecognition(recognizer: recognizer, id: id, onTranscript: onTranscript)
                }
            }
        default:
            failAuthorization(id: id, error: "Microphone permission is denied or restricted. No audio was captured.",
                status: "Microphone off; permission not granted.")
        }
    }

    private func startAuthorizedRecognition(recognizer: SFSpeechRecognizer, id: UUID,
                                            onTranscript: @escaping (String) -> Void) {
        guard authorizationID == id else { return }
        guard recognizer.supportsOnDeviceRecognition else {
            failAuthorization(id: id, error: "This locale does not support on-device recognition. Oracle will not fall back to a server recognizer.",
                status: "Dictation unavailable without server fallback.")
            return
        }
        authorizationTimeoutTask?.cancel()
        authorizationTimeoutTask = nil
        authorizationID = nil
        isStarting = false
        beginOnDeviceRecognition(recognizer: recognizer, onTranscript: onTranscript)
    }

    private func failAuthorization(id: UUID, error: String, status: String) {
        guard authorizationID == id else { return }
        authorizationTimeoutTask?.cancel()
        authorizationTimeoutTask = nil
        authorizationID = nil
        isStarting = false
        lastError = error
        statusDetail = status
    }

    private func beginOnDeviceRecognition(recognizer: SFSpeechRecognizer, onTranscript: @escaping (String) -> Void) {
        stop()
        let request = SFSpeechAudioBufferRecognitionRequest()
        request.requiresOnDeviceRecognition = true
        request.shouldReportPartialResults = true
        recognitionRequest = request
        let input = audioEngine.inputNode
        let format = input.outputFormat(forBus: 0)
        input.removeTap(onBus: 0)
        input.installTap(onBus: 0, bufferSize: 1_024, format: format) { [weak request] buffer, _ in
            request?.append(buffer)
        }
        audioEngine.prepare()
        do {
            try audioEngine.start()
        } catch {
            stop()
            lastError = "On-device audio input could not start."
            statusDetail = "Microphone off after an audio-engine error."
            return
        }
        isListening = true
        transcript = ""
        statusDetail = "Listening with on-device recognition. Nothing is auto-sent."
        recognitionTask = recognizer.recognitionTask(with: request) { [weak self] result, error in
            DispatchQueue.main.async {
                guard let self else { return }
                if let result {
                    self.transcript = result.bestTranscription.formattedString
                    onTranscript(self.transcript)
                }
                if let error, self.isListening {
                    self.lastError = "On-device recognition stopped: \(error.localizedDescription)"
                    self.stop()
                }
            }
        }
    }

    func stop() {
        authorizationID = nil
        authorizationTimeoutTask?.cancel()
        authorizationTimeoutTask = nil
        isStarting = false
        if audioEngine.isRunning {
            audioEngine.stop()
            audioEngine.inputNode.removeTap(onBus: 0)
        }
        recognitionRequest?.endAudio()
        recognitionTask?.cancel()
        recognitionRequest = nil
        recognitionTask = nil
        isListening = false
        statusDetail = "Microphone off; typed input remains available."
    }

    func permissionObservations() -> [OraclePermissionObservation] {
        let microphone: (String, String) = {
            switch AVCaptureDevice.authorizationStatus(for: .audio) {
            case .authorized: return ("AUTHORIZED", "Authorized")
            case .denied: return ("DENIED", "Denied")
            case .restricted: return ("RESTRICTED", "Restricted")
            case .notDetermined: return ("NOT_REQUESTED", "Not requested")
            @unknown default: return ("UNKNOWN", "Unknown")
            }
        }()
        let speech: (String, String) = {
            switch SFSpeechRecognizer.authorizationStatus() {
            case .authorized: return ("AUTHORIZED", "Authorized")
            case .denied: return ("DENIED", "Denied")
            case .restricted: return ("RESTRICTED", "Restricted")
            case .notDetermined: return ("NOT_REQUESTED", "Not requested")
            @unknown default: return ("UNKNOWN", "Unknown")
            }
        }()
        return [
            OraclePermissionObservation(name: "Microphone", detail: microphone.1, status: microphone.0, confidence: microphone.0 == "UNKNOWN" ? "unknown" : "high"),
            OraclePermissionObservation(name: "Speech recognition", detail: speech.1, status: speech.0, confidence: speech.0 == "UNKNOWN" ? "unknown" : "high")
        ]
    }

    private static func speechLabel(_ status: SFSpeechRecognizerAuthorizationStatus) -> String {
        switch status {
        case .authorized: return "authorized"
        case .denied: return "denied"
        case .restricted: return "restricted"
        case .notDetermined: return "not requested"
        @unknown default: return "unknown"
        }
    }
}
