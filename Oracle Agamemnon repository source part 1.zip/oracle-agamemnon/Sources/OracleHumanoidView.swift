import SwiftUI

/// Canonical Oracle identity supplied by the owner on 2026-11-09. The visual
/// anatomy is never procedurally reinvented: the app presents the approved
/// front, three-quarter, side and back references as a draggable turntable.
/// Voice and gesture states add only transient energy at the existing anatomy.
enum OracleHumanoidPose: String, CaseIterable {
    case idle = "Idle"
    case greeting = "Greeting"
    case listening = "Listening"
    case thinking = "Thinking"
    case speaking = "Speaking"

    var accessibilityDescription: String {
        switch self {
        case .idle: return "standing in the approved front reference"
        case .greeting: return "turned slightly with a greeting energy pulse at the hand"
        case .listening: return "facing forward with listening energy at the mask"
        case .thinking: return "shown in profile while considering"
        case .speaking: return "facing forward with audio-reactive energy at the mask"
        }
    }

    fileprivate var turnBias: Double {
        switch self {
        case .idle: return 0
        case .greeting: return -0.25
        case .listening: return 0.08
        case .thinking: return 0.64
        case .speaking: return 0.12
        }
    }
}

struct OracleHumanoidView: View {
    var pose: OracleHumanoidPose = .idle
    /// Actual metered playback level, when available. The system voice offers
    /// word timing but no output meter; nil keeps its mask light steady.
    var measuredVoiceAmplitude: Double?
    var speechProgress: Double = 0
    var motionMode: OracleMotionMode = .idle
    var gesture: OracleGestureCue = .none
    var expressionOverride: OracleMaskExpression?

    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @Environment(\.colorSchemeContrast) private var contrast
    @Environment(\.scenePhase) private var scenePhase
    @State private var dragTurn: Double = 0
    @State private var dragStartTurn: Double = 0

    private var animationEnabled: Bool { !reduceMotion && scenePhase == .active }
    private var turn: Double { min(max(dragTurn + pose.turnBias, -1), 1) }
    private var effectiveMode: OracleMotionMode {
        switch pose {
        case .greeting: return .greeting
        case .listening: return .listening
        case .thinking: return .thinking
        case .speaking: return .speaking
        case .idle: return motionMode
        }
    }

    var body: some View {
        GeometryReader { proxy in
            ZStack {
                LinearGradient(colors: [Color.black, OraclePalette.deepPurple.opacity(0.90), OraclePalette.void], startPoint: .top, endPoint: .bottom)

                if animationEnabled {
                    SwiftUI.TimelineView(.periodic(from: .now, by: 1.0 / 30.0)) { timeline in
                        turntable(size: proxy.size, phase: timeline.date.timeIntervalSinceReferenceDate, frame: motionFrame(phase: timeline.date.timeIntervalSinceReferenceDate))
                    }
                } else {
                    turntable(size: proxy.size, phase: 2.4, frame: motionFrame(phase: 2.4))
                }

                VStack {
                    HStack {
                        Text("ORACLE • CANONICAL FORM")
                            .font(.caption2.weight(.bold))
                            .tracking(1.3)
                            .foregroundStyle(OraclePalette.magenta)
                        Spacer()
                        Text(effectiveMode.rawValue.uppercased())
                            .font(.caption2.monospaced().weight(.bold))
                            .foregroundStyle(OraclePalette.gold)
                    }
                    Spacer()
                    HStack(spacing: 7) {
                        Image(systemName: effectiveMode == .speaking ? "waveform" : "sparkles")
                            .foregroundStyle(OraclePalette.gold)
                        Text(statusLine)
                            .font(.caption2)
                            .foregroundStyle(OraclePalette.coolText.opacity(contrast == .increased ? 1 : 0.78))
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding(13)
                .allowsHitTesting(false)
            }
            .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .strokeBorder(
                        LinearGradient(colors: [OraclePalette.lavender.opacity(0.30), OraclePalette.magenta.opacity(0.26), OraclePalette.gold.opacity(0.22)], startPoint: .topLeading, endPoint: .bottomTrailing),
                        lineWidth: contrast == .increased ? 1.5 : 1
                    )
            }
            .shadow(color: OraclePalette.violet.opacity(reduceTransparency ? 0.05 : 0.28), radius: 26, y: 10)
            .contentShape(Rectangle())
            .gesture(
                DragGesture(minimumDistance: 8)
                    .onChanged { value in
                        dragTurn = min(max(dragStartTurn + value.translation.width / 260, -1), 1)
                    }
                    .onEnded { _ in dragStartTurn = dragTurn }
            )
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Oracle in the owner-approved luminous energy body")
        .accessibilityValue("Canonical front, three-quarter, side and back reference preview. Oracle is \(pose.accessibilityDescription). Image motion study is \(effectiveMode.rawValue), hand light cue is \(gesture.rawValue), mask light cue is \((expressionOverride ?? OracleMotionEngine.expression(for: effectiveMode)).rawValue). Drag left or right to turn the reference. Speech progress is \(Int(speechProgress * 100)) percent. Output amplitude is \(measuredVoiceAmplitude == nil ? "unavailable" : "metered from playback"). This is not facial lip sync or articulated 3D motion.")
    }

    @ViewBuilder
    private func turntable(size: CGSize, phase: TimeInterval, frame: OracleMotionFrame) -> some View {
        let amount = abs(turn)
        ZStack {
            catwalkFloor(size: size, frame: frame)
                .allowsHitTesting(false)

            ZStack {
                referenceImage("OracleCanonicalFront", opacity: weight(center: 0, amount: amount))
                referenceImage("OracleCanonicalThreeQuarter", opacity: weight(center: 0.33, amount: amount))
                referenceImage("OracleCanonicalSide", opacity: weight(center: 0.66, amount: amount))
                referenceImage("OracleCanonicalBack", opacity: weight(center: 1.0, amount: amount))

                energyOverlay(size: size, phase: phase, frame: frame)
                    .blendMode(.screen)
                    .allowsHitTesting(false)
            }
            .scaleEffect(frame.bodyScale * frame.cameraPush, anchor: .bottom)
            .scaleEffect(x: 1 + frame.hipSway * 0.012, y: 1 + frame.shoulderRoll * 0.005, anchor: .bottom)
            .rotationEffect(.degrees(frame.bodyRotation), anchor: .bottom)
            .rotation3DEffect(.degrees(frame.perspective), axis: (x: 0, y: 1, z: 0), anchor: .bottom, perspective: 0.72)
            .offset(x: frame.bodyOffsetX, y: frame.bodyOffsetY)

            LinearGradient(colors: [.clear, Color.black.opacity(0.04), Color.black.opacity(0.62)], startPoint: .center, endPoint: .bottom)
                .allowsHitTesting(false)
        }
        .scaleEffect(turn < 0 ? -1 : 1, anchor: .center)
        .animation(reduceMotion ? nil : .easeOut(duration: 0.22), value: pose)
    }

    private var statusLine: String {
        if effectiveMode == .speaking {
            return measuredVoiceAmplitude == nil
                ? "Output level unavailable • steady mask light • no lip sync"
                : "Metered playback drives mask light • no lip sync"
        }
        if effectiveMode == .runway {
            return "Reference image sway study • no gait • drag to rotate"
        }
        return "Approved multi-view reference • \(gesture.rawValue) cue • drag to rotate"
    }

    private func motionFrame(phase: TimeInterval) -> OracleMotionFrame {
        OracleMotionEngine.frame(
            mode: effectiveMode,
            phase: phase,
            mouthOpenness: measuredVoiceAmplitude ?? 0,
            speechProgress: speechProgress,
            gesture: gesture,
            reduceMotion: reduceMotion,
            sceneActive: scenePhase == .active
        )
    }

    private func referenceImage(_ resource: String, opacity: Double) -> some View {
        OracleBundleImage(resourceName: resource, fileExtension: "jpg")
            .scaledToFit()
            .opacity(max(0, min(1, opacity)))
            .allowsHitTesting(false)
    }

    private func weight(center: Double, amount: Double) -> Double {
        max(0, 1 - abs(amount - center) / 0.34)
    }

    private func catwalkFloor(size: CGSize, frame: OracleMotionFrame) -> some View {
        Canvas { context, canvasSize in
            let floorY = canvasSize.height * 0.69
            let pulse = frame.catwalkPulse
            var horizon = Path()
            horizon.move(to: CGPoint(x: 0, y: floorY))
            horizon.addQuadCurve(to: CGPoint(x: canvasSize.width, y: floorY), control: CGPoint(x: canvasSize.width * 0.5, y: floorY - 4))
            context.stroke(horizon, with: .color(OraclePalette.magenta.opacity(0.10 + pulse * 0.18)), style: StrokeStyle(lineWidth: 1))
            for index in 0..<5 {
                let fraction = Double(index) / 4.0
                var runway = Path()
                runway.move(to: CGPoint(x: canvasSize.width * (0.34 + fraction * 0.08), y: floorY))
                runway.addLine(to: CGPoint(x: canvasSize.width * (-0.15 + fraction * 1.30), y: canvasSize.height))
                context.stroke(runway, with: .color(OraclePalette.violet.opacity(0.08 + pulse * 0.12)), style: StrokeStyle(lineWidth: 1))
            }
            let spot = CGRect(x: canvasSize.width * 0.22, y: floorY + 12, width: canvasSize.width * 0.56, height: canvasSize.height * 0.22)
            context.fill(Path(ellipseIn: spot), with: .radialGradient(Gradient(colors: [OraclePalette.lavender.opacity(0.10 + pulse * 0.08), .clear]), center: CGPoint(x: spot.midX, y: spot.midY), startRadius: 1, endRadius: spot.width * 0.5))
        }
        .opacity(effectiveMode == .runway || gesture != .none ? 1 : 0)
    }

    private func energyOverlay(size: CGSize, phase: TimeInterval, frame: OracleMotionFrame) -> some View {
        Canvas { context, canvasSize in
            let faceCenter = CGPoint(x: canvasSize.width * 0.5, y: canvasSize.height * 0.105)
            let expression = expressionOverride ?? frame.expression

            if effectiveMode == .listening || expression == .attentive {
                for index in 0..<3 {
                    let radius = 18 + Double(index) * 10 + (animationEnabled ? sin(phase * 2.4 + Double(index)) * 3 : 0)
                    let rect = CGRect(x: faceCenter.x - radius, y: faceCenter.y - radius, width: radius * 2, height: radius * 2)
                    context.stroke(Path(ellipseIn: rect), with: .color(OraclePalette.magenta.opacity(0.18 - Double(index) * 0.03)), style: StrokeStyle(lineWidth: 1))
                }
            }

            let expressionColor: Color = {
                switch expression {
                case .calm: return OraclePalette.lavender
                case .warm: return OraclePalette.ember
                case .attentive: return OraclePalette.magenta
                case .curious: return OraclePalette.gold
                case .confident: return OraclePalette.gold
                case .delighted: return OraclePalette.magenta
                case .speaking: return OraclePalette.gold
                }
            }()
            let maskGlow = CGRect(x: faceCenter.x - 28, y: faceCenter.y - 34, width: 56, height: 72)
            context.fill(Path(ellipseIn: maskGlow), with: .radialGradient(Gradient(colors: [expressionColor.opacity(0.05 + frame.maskPulse * 0.16), .clear]), center: faceCenter, startRadius: 1, endRadius: 38))

            let leftHand = CGPoint(x: canvasSize.width * 0.23, y: canvasSize.height * 0.51)
            let rightHand = CGPoint(x: canvasSize.width * 0.77, y: canvasSize.height * 0.51)
            if frame.leftHandPulse > 0 {
                drawHandEnergy(context: &context, center: leftHand, pulse: frame.leftHandPulse, phase: phase, color: expressionColor)
            }
            if frame.rightHandPulse > 0 {
                drawHandEnergy(context: &context, center: rightHand, pulse: frame.rightHandPulse, phase: phase, color: expressionColor)
            }

            if gesture == .point {
                var beam = Path()
                beam.move(to: CGPoint(x: rightHand.x + 10, y: rightHand.y))
                beam.addLine(to: CGPoint(x: canvasSize.width * 0.93, y: rightHand.y - 28))
                context.stroke(beam, with: .linearGradient(Gradient(colors: [OraclePalette.gold.opacity(0.8), .clear]), startPoint: rightHand, endPoint: CGPoint(x: canvasSize.width * 0.93, y: rightHand.y - 28)), style: StrokeStyle(lineWidth: 2, lineCap: .round))
            }

            if gesture == .handToHeart {
                var connection = Path()
                connection.move(to: leftHand)
                connection.addQuadCurve(to: CGPoint(x: canvasSize.width * 0.5, y: canvasSize.height * 0.31), control: CGPoint(x: canvasSize.width * 0.34, y: canvasSize.height * 0.38))
                context.stroke(connection, with: .linearGradient(Gradient(colors: [OraclePalette.gold.opacity(0.18), OraclePalette.magenta.opacity(0.62), OraclePalette.gold.opacity(0.15)]), startPoint: leftHand, endPoint: CGPoint(x: canvasSize.width * 0.5, y: canvasSize.height * 0.31)), style: StrokeStyle(lineWidth: 1.5, lineCap: .round))
            }

            if gesture == .hairSweep {
                for index in 0..<4 {
                    let width = 34.0 + Double(index) * 14.0
                    let rect = CGRect(x: faceCenter.x - width / 2, y: faceCenter.y - width * 0.7, width: width, height: width * 1.25)
                    context.stroke(Path(ellipseIn: rect), with: .color(OraclePalette.lavender.opacity(0.16 - Double(index) * 0.025)), style: StrokeStyle(lineWidth: 1))
                }
            }

            if gesture == .wave || gesture == .openPalm {
                let hand = rightHand
                for index in 0..<3 {
                    let radius = 8 + Double(index) * 6 + (animationEnabled ? sin(phase * 3.0 + Double(index)) * 2 : 0)
                    let rect = CGRect(x: hand.x - radius, y: hand.y - radius, width: radius * 2, height: radius * 2)
                    context.stroke(Path(ellipseIn: rect), with: .color(OraclePalette.gold.opacity(0.42 - Double(index) * 0.08)), style: StrokeStyle(lineWidth: 1.2))
                }
            }

            for index in 0..<12 {
                let seed = Double(index)
                let x = canvasSize.width * (0.12 + (seed * 0.173).truncatingRemainder(dividingBy: 0.76))
                let y = canvasSize.height * (0.12 + (seed * 0.293).truncatingRemainder(dividingBy: 0.76))
                let drift = animationEnabled ? sin(phase * 0.8 + seed) * 6 : 0
                let dot = CGRect(x: x, y: y + drift, width: index.isMultiple(of: 3) ? 2.2 : 1.2, height: index.isMultiple(of: 3) ? 2.2 : 1.2)
                context.fill(Path(ellipseIn: dot), with: .color(index.isMultiple(of: 3) ? OraclePalette.gold.opacity(0.46) : OraclePalette.lavender.opacity(0.36)))
            }
        }
    }

    private func drawHandEnergy(context: inout GraphicsContext, center: CGPoint, pulse: Double, phase: TimeInterval, color: Color) {
        for index in 0..<3 {
            let radius = 7 + Double(index) * 7 + pulse * 7 + (animationEnabled ? sin(phase * 4.0 + Double(index)) * 1.5 : 0)
            let rect = CGRect(x: center.x - radius, y: center.y - radius, width: radius * 2, height: radius * 2)
            context.stroke(Path(ellipseIn: rect), with: .color(color.opacity((0.42 - Double(index) * 0.09) * pulse)), style: StrokeStyle(lineWidth: 1.1))
        }
    }
}
