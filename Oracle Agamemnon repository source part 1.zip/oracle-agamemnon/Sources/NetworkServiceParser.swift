import Foundation

struct ParsedNetworkService: Equatable {
    let name: String
    let state: String
}

enum NetworkServiceParser {
    static func parse(_ text: String) -> [ParsedNetworkService] {
        text.components(separatedBy: .newlines).compactMap { rawLine in
            let line = rawLine.trimmingCharacters(in: .whitespaces)
            guard line.contains("[VPN:") else { return nil }

            let state: String
            if line.contains("(Connected)") {
                state = "Connected"
            } else if line.contains("(Disconnected)") {
                state = "Disconnected"
            } else {
                state = "Unknown"
            }

            let quotedFields = line.components(separatedBy: "\"")
            guard quotedFields.count >= 3 else { return nil }
            let name = quotedFields[1].trimmingCharacters(in: .whitespaces)
            guard !name.isEmpty else { return nil }
            return ParsedNetworkService(name: name, state: state)
        }
    }

    static func defaultInterface(from routeText: String) -> String? {
        for rawLine in routeText.components(separatedBy: .newlines) {
            let parts = rawLine.split(separator: ":", maxSplits: 1).map { $0.trimmingCharacters(in: .whitespaces) }
            if parts.count == 2, parts[0] == "interface", !parts[1].isEmpty {
                return parts[1]
            }
        }
        return nil
    }

    static func resolverCount(from dnsText: String) -> Int? {
        guard dnsText.contains("resolver #") else { return nil }
        let count = dnsText.components(separatedBy: .newlines).filter { line in
            line.contains("resolver #") && line.contains("flags") == false
        }.count
        return count > 0 ? count : nil
    }
}
