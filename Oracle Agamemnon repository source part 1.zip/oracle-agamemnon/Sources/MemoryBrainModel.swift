import Foundation

struct MemoryBrainPosition: Hashable, Sendable {
    let x: Double
    let y: Double
    let z: Double
    static let origin = MemoryBrainPosition(x: 0, y: 0, z: 0)
}

enum MemoryBrainNodeKind: String, Hashable, Sendable {
    case memoryHub
    case note
}

struct MemoryBrainNode: Identifiable, Hashable, Sendable {
    let id: String
    let title: String
    let relativePath: String?
    let folder: String?
    let kind: MemoryBrainNodeKind
    let linkCount: Int
    let weight: Double
    let position: MemoryBrainPosition
}

enum MemoryBrainEdgeKind: String, Hashable, Sendable {
    case hubConnection
    case noteLink
}

struct MemoryBrainEdge: Identifiable, Hashable, Sendable {
    let id: String
    let from: String
    let to: String
    let kind: MemoryBrainEdgeKind
}

struct MemoryBrainGraph: Hashable, Sendable {
    let generatedAt: Date
    let nodes: [MemoryBrainNode]
    let edges: [MemoryBrainEdge]
}

struct ObsidianMemorySource: Hashable, Sendable {
    let relativePath: String
    let title: String
    let text: String
    let modifiedAt: Date?
}

enum MemoryBrainBuilder {
    static func build(
        sources: [ObsidianMemorySource],
        generatedAt: Date,
        maxNotes: Int = 160,
        maxEdges: Int = 420
    ) -> MemoryBrainGraph {
        let limitedSources = Array(sources.sorted {
            $0.relativePath.localizedLowercase < $1.relativePath.localizedLowercase
        }.prefix(max(0, maxNotes)))

        var lookup: [String: Set<String>] = [:]
        func register(_ key: String, nodeID: String) {
            lookup[key.lowercased(), default: []].insert(nodeID)
        }
        for source in limitedSources {
            let nodeID = "note:\(source.relativePath)"
            register(source.relativePath, nodeID: nodeID)
            register((source.relativePath as NSString).deletingPathExtension, nodeID: nodeID)
            register(((source.relativePath as NSString).lastPathComponent as NSString).deletingPathExtension, nodeID: nodeID)
            register(source.title, nodeID: nodeID)
        }

        var outgoing: [String: Set<String>] = [:]
        for source in limitedSources {
            let sourceID = "note:\(source.relativePath)"
            var targets: Set<String> = []
            for target in wikilinks(in: source.text) {
                let candidates = lookup[target.lowercased()] ?? []
                if candidates.count == 1, let resolved = candidates.first, resolved != sourceID {
                    targets.insert(resolved)
                }
            }
            outgoing[sourceID] = targets
        }

        let count = max(1, limitedSources.count)
        var nodes: [MemoryBrainNode] = [
            MemoryBrainNode(
                id: "memory-hub",
                title: "Obsidian Memory",
                relativePath: nil,
                folder: nil,
                kind: .memoryHub,
                linkCount: limitedSources.count,
                weight: 1.8,
                position: .origin
            )
        ]

        for (index, source) in limitedSources.enumerated() {
            let nodeID = "note:\(source.relativePath)"
            let position = orbitalPosition(index: index, count: count)
            let pathComponents = source.relativePath.split(separator: "/").map(String.init)
            let folder = pathComponents.count > 1 ? pathComponents.dropLast().joined(separator: "/") : "Vault root"
            let links = outgoing[nodeID]?.count ?? 0
            let headingCount = source.text.split(separator: "\n").filter { $0.hasPrefix("#") }.count
            let weight = min(1.7, 0.62 + Double(links) * 0.16 + Double(headingCount) * 0.04)
            nodes.append(MemoryBrainNode(
                id: nodeID,
                title: source.title,
                relativePath: source.relativePath,
                folder: folder,
                kind: .note,
                linkCount: links,
                weight: weight,
                position: position
            ))
        }

        var edges: [MemoryBrainEdge] = []
        for node in nodes where node.kind == .note {
            edges.append(MemoryBrainEdge(
                id: "hub|\(node.id)",
                from: "memory-hub",
                to: node.id,
                kind: .hubConnection
            ))
        }

        var seen = Set<String>()
        for source in limitedSources {
            let from = "note:\(source.relativePath)"
            for target in (outgoing[from] ?? []).sorted() {
                let pair = [from, target].sorted()
                let edgeID = "link|\(pair[0])|\(pair[1])"
                guard seen.insert(edgeID).inserted else { continue }
                edges.append(MemoryBrainEdge(id: edgeID, from: pair[0], to: pair[1], kind: .noteLink))
            }
        }

        if edges.count > maxEdges {
            edges = Array(edges.prefix(max(0, maxEdges)))
        }
        return MemoryBrainGraph(generatedAt: generatedAt, nodes: nodes, edges: edges)
    }

    private static func wikilinks(in text: String) -> [String] {
        let pattern = #"\[\[([^\]|#]+)"#
        guard let regex = try? NSRegularExpression(pattern: pattern) else { return [] }
        let range = NSRange(text.startIndex..<text.endIndex, in: text)
        return regex.matches(in: text, range: range).compactMap { match in
            guard let targetRange = Range(match.range(at: 1), in: text) else { return nil }
            let target = String(text[targetRange]).trimmingCharacters(in: .whitespacesAndNewlines)
            return target.isEmpty ? nil : target
        }
    }

    private static func orbitalPosition(index: Int, count: Int) -> MemoryBrainPosition {
        guard count > 0 else { return .origin }
        let y = 1.0 - 2.0 * (Double(index) + 0.5) / Double(count)
        let radiusAtY = sqrt(max(0, 1.0 - y * y))
        let theta = Double(index) * 2.399963229728653
        let radius = 2.35
        return MemoryBrainPosition(
            x: cos(theta) * radiusAtY * radius,
            y: y * radius,
            z: sin(theta) * radiusAtY * radius
        )
    }
}
