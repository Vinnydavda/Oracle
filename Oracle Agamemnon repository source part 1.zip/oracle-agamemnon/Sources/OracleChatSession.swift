import Foundation

struct OracleChatStoredMessage: Codable, Equatable {
    let id: UUID
    let createdAt: Date
    let role: String
    let text: String
    let state: String
    let providerID: String?
    let modelID: String?
}

struct OracleChatSession: Codable, Equatable {
    var draft: String
    var messages: [OracleChatStoredMessage]
    var savedAt: Date
    var schema: Int = 1
}

enum OracleChatSessionStore {
    static func load(from url: URL) throws -> OracleChatSession {
        let data = try Data(contentsOf: url)
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return try decoder.decode(OracleChatSession.self, from: data)
    }

    static func save(_ session: OracleChatSession, to url: URL) throws {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        let data = try encoder.encode(session)
        try data.write(to: url, options: .atomic)
        try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: url.path)
    }
}
