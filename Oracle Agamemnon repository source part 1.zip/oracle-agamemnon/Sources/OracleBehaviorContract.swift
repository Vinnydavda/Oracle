import Foundation

/// A bounded suggestion from the local model. It is data, never executable
/// animation code. A proposal is inactive until its emphasis phrase is found
/// in the final reply and real speech progress reaches that phrase.
struct OracleBehaviorProposal: Equatable {
    enum Gesture: String, CaseIterable {
        case none
        case openPalm
        case handToHeart
    }

    enum Expression: String, CaseIterable {
        case calm
        case warm
        case curious
        case confident
    }

    enum Gaze: String, CaseIterable {
        case center
        case left
        case right
    }

    let gesture: Gesture
    let expression: Expression
    let gaze: Gaze
    let intensity: Double
    let emphasisText: String

    static let maximumEmphasisCharacters = 64
    static let maximumIntensity = 0.65

    static func parse(_ raw: [String: Any]) throws -> Self {
        let expected: Set<String> = ["gesture", "expression", "gaze", "intensity", "emphasis_text"]
        guard Set(raw.keys) == expected,
              let gestureName = raw["gesture"] as? String,
              let expressionName = raw["expression"] as? String,
              let gazeName = raw["gaze"] as? String,
              let gesture = Gesture(rawValue: gestureName),
              let expression = Expression(rawValue: expressionName),
              let gaze = Gaze(rawValue: gazeName), gaze == .center,
              let intensity = raw["intensity"] as? Double,
              intensity.isFinite, intensity >= 0, intensity <= maximumIntensity,
              let phrase = raw["emphasis_text"] as? String else {
            throw NSError(domain: "OracleBehavior", code: 1,
                          userInfo: [NSLocalizedDescriptionKey: "Oracle rejected an unsupported or malformed behavior proposal."])
        }
        let emphasis = phrase.trimmingCharacters(in: .whitespacesAndNewlines)
        guard emphasis.count <= maximumEmphasisCharacters,
              (gesture == .none || !emphasis.isEmpty) else {
            throw NSError(domain: "OracleBehavior", code: 2,
                          userInfo: [NSLocalizedDescriptionKey: "Oracle rejected an unanchored behavior proposal."])
        }
        return Self(gesture: gesture, expression: expression, gaze: gaze,
                    intensity: intensity, emphasisText: emphasis)
    }

    /// macOS speech progress is measured in UTF-16 code units. A missing phrase
    /// is not guessed from elapsed time: the gesture is discarded.
    func emphasisFraction(in finalReply: String) -> Double? {
        guard !emphasisText.isEmpty else { return gesture == .none ? 0 : nil }
        let reply = finalReply as NSString
        let range = reply.range(of: emphasisText, options: [.caseInsensitive, .diacriticInsensitive])
        guard range.location != NSNotFound, reply.length > 0 else { return nil }
        // Require a nonzero speech callback even when the phrase begins the reply.
        return Double(range.location + 1) / Double(reply.length)
    }

    var supportedGestureCue: OracleGestureCue {
        switch gesture {
        case .none: return .none
        case .openPalm: return .openPalm
        case .handToHeart: return .handToHeart
        }
    }

    var supportedMaskExpression: OracleMaskExpression {
        switch expression {
        case .calm: return .calm
        case .warm: return .warm
        case .curious: return .curious
        case .confident: return .confident
        }
    }
}
