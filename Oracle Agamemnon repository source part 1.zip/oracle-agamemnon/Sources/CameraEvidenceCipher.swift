import CryptoKit
import Foundation
import Security

enum CameraEvidenceCipher {
    private static let service = "app.oracle.agamemnon.security.camera-evidence"
    private static let account = "local-aes-256"

    static func loadOrCreateKey() throws -> SymmetricKey {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var item: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &item)
        if status == errSecSuccess, let data = item as? Data, data.count == 32 {
            return SymmetricKey(data: data)
        }
        guard status == errSecItemNotFound else {
            throw NSError(domain: "OracleCameraCipher", code: Int(status), userInfo: [NSLocalizedDescriptionKey: "The camera evidence key could not be read from Keychain."])
        }
        var bytes = [UInt8](repeating: 0, count: 32)
        guard SecRandomCopyBytes(kSecRandomDefault, bytes.count, &bytes) == errSecSuccess else {
            throw NSError(domain: "OracleCameraCipher", code: 1, userInfo: [NSLocalizedDescriptionKey: "A secure random camera evidence key could not be created."])
        }
        let data = Data(bytes)
        let add: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        ]
        let addStatus = SecItemAdd(add as CFDictionary, nil)
        guard addStatus == errSecSuccess else {
            throw NSError(domain: "OracleCameraCipher", code: Int(addStatus), userInfo: [NSLocalizedDescriptionKey: "The camera evidence key could not be stored in Keychain."])
        }
        return SymmetricKey(data: data)
    }

    static func encrypt(_ data: Data, key: SymmetricKey) throws -> Data {
        let sealed = try AES.GCM.seal(data, using: key)
        guard let combined = sealed.combined else {
            throw NSError(domain: "OracleCameraCipher", code: 2, userInfo: [NSLocalizedDescriptionKey: "Encrypted camera evidence could not be serialized."])
        }
        return combined
    }

    static func decrypt(_ data: Data, key: SymmetricKey) throws -> Data {
        let box = try AES.GCM.SealedBox(combined: data)
        return try AES.GCM.open(box, using: key)
    }

    static func encryptFile(at source: URL, to destination: URL, maximumBytes: UInt64 = 250_000_000) throws -> String {
        let values = try source.resourceValues(forKeys: [.fileSizeKey])
        guard UInt64(values.fileSize ?? 0) <= maximumBytes else {
            throw NSError(domain: "OracleCameraCipher", code: 3, userInfo: [NSLocalizedDescriptionKey: "Camera evidence exceeds the local encryption size limit."])
        }
        let plaintext = try Data(contentsOf: source)
        let ciphertext = try encrypt(plaintext, key: try loadOrCreateKey())
        try ciphertext.write(to: destination, options: .atomic)
        try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: destination.path)
        return ProtectionEngine.sha256(data: ciphertext)
    }

    static func expiredEvidence(in root: URL, olderThanDays days: Int, now: Date = Date()) -> [URL] {
        guard days > 0,
              let enumerator = FileManager.default.enumerator(at: root, includingPropertiesForKeys: [.contentModificationDateKey, .isRegularFileKey], options: [.skipsHiddenFiles]) else { return [] }
        let cutoff = now.addingTimeInterval(-Double(days) * 86_400)
        var rows: [URL] = []
        for case let url as URL in enumerator {
            guard url.pathExtension.lowercased() == "enc",
                  let values = try? url.resourceValues(forKeys: [.contentModificationDateKey, .isRegularFileKey]),
                  values.isRegularFile == true,
                  let modified = values.contentModificationDate,
                  modified < cutoff else { continue }
            rows.append(url)
        }
        return rows
    }
}
