#!/bin/sh
set -eu

cd "$(dirname "$0")/.."
mkdir -p .build/ModuleCache .build/Oracle\ Agamemnon.app/Contents/MacOS .build/Oracle\ Agamemnon.app/Contents/Resources

swiftc -O \
  -module-cache-path "$PWD/.build/ModuleCache" \
  -framework AppKit -framework SwiftUI -framework AVFoundation \
  -framework Speech -framework CoreImage -framework CoreVideo \
  -framework IOKit -framework Vision -framework Security \
  Sources/*.swift \
  -o ".build/Oracle Agamemnon.app/Contents/MacOS/Agamemnon"

cp Resources/Info.plist ".build/Oracle Agamemnon.app/Contents/Info.plist"
ditto Resources ".build/Oracle Agamemnon.app/Contents/Resources"
rm ".build/Oracle Agamemnon.app/Contents/Resources/Info.plist"

echo "Built .build/Oracle Agamemnon.app"
